from urllib import request
import uuid
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.core.mail import EmailMultiAlternatives
from configuration import constants,message,template, config
from django.core import serializers
import json
from datetime import datetime, date, timedelta
from pytz import timezone
from datetime import time
import sys, os, requests, json
from leave_requests.models import *

# METHOD: return_response_func
# DESCRIPTION: This method return result based request type
# AUTHOR: Mayur Bhujbal
# Date: 02/02/2023
def return_response_func(request, result):
    try:
        if isinstance(request, dict):
            return result
        else:
            return JsonResponse(result, safe = False)
    except Exception as error:
        print_error_v1("return_response", error)


# METHOD: leave_application_mail
# DESCRIPTION: This is used to send the leave mail template
# AUTHOR: Vikas Tomar
# Date: 27/10/2022
@csrf_exempt
def leave_application_mail(request_body):
    try:
        print("request body for mail template",request_body)
        request_body_for_mail_template = request_body
        sender = constants.SYSTEM_APPROVER_MAIL
        leave_request_title = ""
        leave_request_content = ""
        mail_salutation = ""
        subject = ""
        leave_categpory_mail = request_body_for_mail_template['leave_categpory_mail']
        emp_id = request_body_for_mail_template['emp_id']
        emp_name = request_body_for_mail_template['emp_name']
        leave_type = request_body_for_mail_template['leave_type']
        absence_type = request_body_for_mail_template['absence_type']
        start_date = request_body_for_mail_template['start_date']
        end_date = request_body_for_mail_template['end_date']
        reason = request_body_for_mail_template['reason']
        emp_role = request_body_for_mail_template['emp_role']
        to_mail_address = request_body_for_mail_template['to_mail_address']
        cc_mail_address = request_body_for_mail_template['cc_mail_address']
        company = constants.CV_COMPANY
        print("Leave Reason",reason)

        # To create email subject
        current_datetime_ist = datetime.now() + timedelta(hours=5, minutes=30)
        current_date_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).date()

        #Replace the mail template salutation.
        if emp_role == constants.MANAGER_ROLE:
            mail_salutation = constants.DEAR_MSG + " " + emp_role
        else:
            mail_salutation = constants.DEAR_MSG + " " + emp_name

        #Leave Application mail template
        leave_application_mail_template = template.LEAVE_APPLICATION_MAIL_TEMPLATE
        leave_application_mail_template = leave_application_mail_template.replace('drishti_heading', constants.drishti_heading)
        leave_application_mail_template = leave_application_mail_template.replace('tata_logo', constants.tata_logo)
        
        if leave_categpory_mail == constants.LEAVE_REQUEST:
            subject = emp_id + " - " + emp_name + " - " + constants.LEAVE_REQUEST_SUBJECT+ " - " + date_format_conversion(str(current_datetime_ist.date()))
            leave_request_title = constants.LEAVE_REQUEST_TITLE
            leave_request_content = constants.LEAVE_REQUEST_CONTENT
            leave_application_mail_template = leave_application_mail_template.replace('leave_status_color',constants.PENDING_LEAVE_STATUS_COLOR)
            # leave_application_mail_template = leave_application_mail_template.replace('status_log', '"data:image/png;base64,'+constants.leave_request_logo+'"')
            leave_application_mail_template = leave_application_mail_template.replace('status_log', constants.leave_request_logo)
        elif leave_categpory_mail == constants.LEAVE_APPROVAL_NOTIFICATION:
            subject =  constants.LEAVE_APPROVED_SUBJECT + " - " + date_format_conversion(str(current_datetime_ist.date()))
            leave_request_title = constants.LEAVE_APPROVED_TITLE
            cc_mail_address = ''
            leave_request_content = constants.LEAVE_APPROVED_CONTENT
            leave_application_mail_template = leave_application_mail_template.replace('leave_status_color',constants.APPROVED_LEAVE_STATUS_COLOR)
            # leave_application_mail_template = leave_application_mail_template.replace('status_log', '"data:image/png;base64,'+constants.leave_approved_logo+'"')
            leave_application_mail_template = leave_application_mail_template.replace('status_log', constants.leave_approved_logo)
        elif leave_categpory_mail == constants.LEAVE_DELETE_APPROVE:
            subject = constants.LEAVE_DELETE_APPROVED_SUBJECT + " - " + date_format_conversion(str(current_datetime_ist.date()))
            leave_request_title = constants.LEAVE_DELETE_APPROVED_TITLE
            leave_request_content = constants.LEAVE_DELETE_APPROVED_CONTENT
            leave_application_mail_template = leave_application_mail_template.replace('leave_status_color',constants.DELETE_APPROVED_STATUS_COLOR)
            # leave_application_mail_template = leave_application_mail_template.replace('status_log', '"data:image/png;base64,'+constants.delete_approve_leave+'"')
            leave_application_mail_template = leave_application_mail_template.replace('status_log', constants.delete_approve_leave)
        elif leave_categpory_mail == constants.LEAVE_DELETE:
            subject =  emp_id + " - " + emp_name + " - " + constants.LEAVE_DELETE_SUBJECT + " - " + date_format_conversion(str(current_datetime_ist.date()))
            leave_request_title = constants.LEAVE_DELETE_TITLE
            leave_request_content = constants.LEAVE_DELETE_CONTENT
            leave_application_mail_template = leave_application_mail_template.replace('leave_status_color',constants.DELETE_PENDING_STATUS_COLOR)
            # leave_application_mail_template = leave_application_mail_template.replace('status_log', '"data:image/png;base64,'+constants.delete_approve_leave+'"')
            leave_application_mail_template = leave_application_mail_template.replace('status_log', constants.delete_approve_leave)
        elif leave_categpory_mail == constants.LEAVE_REJECT:
            subject = constants.LEAVE_REJECT_SUBJECT + " - " + date_format_conversion(str(current_datetime_ist.date()))
            leave_request_title = constants.LEAVE_REJECT_TITLE
            leave_request_content = constants.LEAVE_REJECT_CONTENT
            leave_application_mail_template = leave_application_mail_template.replace('leave_status_color',constants.DELETE_REJECT_STATUS_COLOR)
            # leave_application_mail_template = leave_application_mail_template.replace('status_log', '"data:image/png;base64,'+constants.leave_reject_logo+'"')
            leave_application_mail_template = leave_application_mail_template.replace('status_log', constants.leave_reject_logo)

        leave_application_mail_template = leave_application_mail_template.replace('leave_mail_header', constants.leave_mail_header)
        leave_application_mail_template = leave_application_mail_template.replace('leave_request_title', leave_request_title)
        leave_application_mail_template = leave_application_mail_template.replace('leave_request_content', leave_request_content)
        leave_application_mail_template = leave_application_mail_template.replace('mail_salutation', mail_salutation)
        leave_application_mail_template = leave_application_mail_template.replace('emp_id', emp_id)
        leave_application_mail_template = leave_application_mail_template.replace('emp_name',emp_name)
        leave_application_mail_template = leave_application_mail_template.replace('leave_type', leave_type)
        leave_application_mail_template = leave_application_mail_template.replace('absence_type', absence_type)
        leave_application_mail_template = leave_application_mail_template.replace('start_date', date_format_conversion(start_date))
        leave_application_mail_template = leave_application_mail_template.replace('end_date', date_format_conversion(end_date))
        leave_application_mail_template = leave_application_mail_template.replace('leave_reason',reason)
        leave_application_mail_template = leave_application_mail_template.replace('company', company)

        if cc_mail_address != '':
            msg = EmailMultiAlternatives(subject,leave_application_mail_template,sender,[to_mail_address],cc=[cc_mail_address])
        else:
            msg = EmailMultiAlternatives(subject,leave_application_mail_template,sender,[to_mail_address])
        msg.attach_alternative(leave_application_mail_template, "text/html")
        msg.send()
        print("leave application mail sent successsfully")
        return JsonResponse(message.SUCCESSFULLY_WORKING,safe=False)
    except Exception as error:
        print("Exception during the send leave mail",error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE,safe=False)

#This is used to serializadt the dict object into json format
def get_serialize_data(data):
    data = serializers.serialize("json", data)
    data = json.loads(data)
    result = []
    for i in range(len(data)):
        detail_data = data[i]['fields']
        result.append(detail_data)
    return result


# METHOD: date_format_conversion
# DESCRIPTION: 
# AUTHOR: Vikas Tomar
# Date: 04/11/2022
def date_format_conversion(date):
    today_date = date.split(" ")[0]
    date_month_year = today_date.split("-")
    formatted_date_time = "-".join(date_month_year[::-1])
    print(formatted_date_time)
    return formatted_date_time

# METHOD: return_object_func
# DESCRIPTION: This is common function for return success  
# AUTHOR: Vikas Tomar
# Date: 04/11/2022
def return_object_func(status_code,response_message,param_dict={}):
    data = {}
    if param_dict:
        if type(param_dict) ==list:
            data = param_dict
        else:
            for key in param_dict:
                data[key] = param_dict[key]
    return_object = {
        message.STATUS_CODE: str(status_code),
        message.MESSAGE: response_message,
        message.DATA: data
    }
    return return_object

# METHOD: print_error_v1
# DESCRIPTION: This is common function for return error name and line number
def print_error_v1(func_name,error=''):
    exc_type, exc_obj, exc_tb = sys.exc_info()
    fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
    print(func_name + " : " + str(error), " in ", fname," at ", exc_tb.tb_lineno)

# METHOD: is_employee_valid
# DESCRIPTION: This function is used to check employee of type White Collar
# AUTHOR: Mayur Bhujbal
# Date: 06/04/2023
def is_employee_valid(request, token):
    is_valid = False
    try:
        emp_id, emp_type = extract_emp_details(request)
        # The APIs that are common for Blue Collar need to be added in the BLUE_COLLAR_PATHS constants
        if emp_type == constants.BLUE_COLLAR and request.path in constants.BLUE_COLLAR_PATHS:
            is_valid = is_type_valid(emp_id, emp_type)
        elif not emp_type or emp_type == constants.WHITE_COLLAR:
            is_valid = is_type_valid(emp_id, constants.WHITE_COLLAR) and is_token_valid(token)
        else:
            is_valid = False
            print("Error occured while validating employee")
        if not emp_id:
            is_valid = True
    except Exception as error:
        print_error_v1("is_employee_valid", error)
    return is_valid

# METHOD: is_token_valid
# DESCRIPTION: This function is used to check token of employee
# AUTHOR: Mayur Bhujbal
# Date: 07/04/2023
def extract_emp_details(request):
    emp_id, emp_type, request_body = "", "", {}
    try:
        if request and request.body:
            request_body = json.loads(request.body)
        if request_body:
            if 'emp_id' in request_body and request_body['emp_id']:
                emp_id = request_body['emp_id']
            if 'empId' in request_body and request_body['empId']:
                emp_id = request_body['empId']
            if 'employee_id' in request_body and request_body['employee_id']:
                emp_id = request_body['employee_id']
            if 'login_emp_id' in request_body and request_body['login_emp_id']:
                emp_id = request_body['login_emp_id']
            if 'logged_in_emp_id' in request_body and request_body['logged_in_emp_id']:
                emp_id = request_body['logged_in_emp_id']
            if 'employee_type' in request_body and request_body['employee_type']:
                emp_type = request_body['employee_type']
    except Exception as error:
        print_error_v1("extract_emp_details", error)
    return emp_id, emp_type

# METHOD: is_token_valid
# DESCRIPTION: This function is used to check token of employee
# AUTHOR: Mayur Bhujbal
# Date: 07/04/2023
def is_token_valid(token):
    is_valid = False
    try:
        if 'azp' in token and token['azp'] == config.CLIENT_ID:
            is_valid = True
        else:
            print("Error occured while validating token")
    except Exception as error:
        print_error_v1("is_token_valid", error)
    return is_valid

# METHOD: is_type_valid
# DESCRIPTION: This function is used to check token of employee
# AUTHOR: Mayur Bhujbal
# Date: 07/04/2023
def is_type_valid(emp_id, emp_type):
    is_valid = False
    try:
        employee_type_resp = ""
        employee_type_resp = requests.post(url = config.FETCH_EMPLOYEE_TYPE, data = json.dumps({"emp_id": emp_id}))
        if employee_type_resp and employee_type_resp.status_code == constants.HTTP_200_OK:
            employee_type_resp = json.loads(employee_type_resp.content.decode('utf-8'))
        if employee_type_resp and employee_type_resp[constants.STATUS_CODE] == str(constants.HTTP_200_OK) \
            and employee_type_resp[constants.DATA]['employee_type'] == emp_type:
            is_valid = True
        else:
            print("Error occured while fetching the employee details from edp: ", employee_type_resp)
    except Exception as error:
        print_error_v1("is_type_valid", error)
    return is_valid

# METHOD: leave_scheduler_logs
# DESCRIPTION: This Method will store Leave scheduler logs
# AUTHOR: Smeet Yelve
# Date: 21/08/2023
def leave_scheduler_logs(scheduler_name='',status='', description = '', leave_request_details = LeaveRequestsEDP(),**kwargs):
    try:
        store_scheduler_logs = LeaveSchedulerLogs(
            unique_id = uuid.uuid4(),
            scheduler_name = scheduler_name,
            status = status,
            description = description,
            status_code = kwargs.get('status_code'),
            status_number = kwargs.get('status_number'),
            status_message = kwargs.get('status_message'),
            sap_leave_post_type = kwargs.get('sap_leave_post_type'),
            created_date_time = datetime.now(),
            modified_date_time = datetime.now(),
            leave_request_id = leave_request_details.leave_request_id if leave_request_details else None,
            requestor_emp_id = leave_request_details.requestor_emp_id if leave_request_details else None,
            requestor_email = leave_request_details.requestor_email if leave_request_details else None,
            leave_category = leave_request_details.leave_category if leave_request_details else None,
            leave_type = leave_request_details.leave_type if leave_request_details else None,
            from_date = leave_request_details.from_date if leave_request_details else None,
            to_date = leave_request_details.to_date if leave_request_details else None,
            total_days = leave_request_details.total_days if leave_request_details else None,
            leave_status = leave_request_details.leave_status if leave_request_details else None,
            applied_date = leave_request_details.applied_date if leave_request_details else None,
            approver_emp_id = leave_request_details.approver_emp_id if leave_request_details else None,
            approver_email = leave_request_details.approver_email if leave_request_details else None,
            is_deleted = leave_request_details.is_deleted if leave_request_details else None,
            leave_created_datetime = leave_request_details.created_date_time if leave_request_details else None,
            leave_modified_datetime = leave_request_details.modified_date_time if leave_request_details else None,
            leave_created_by = leave_request_details.created_by if leave_request_details else None,
            leave_modified_by = leave_request_details.modified_by if leave_request_details else None
        )
        store_scheduler_logs.save()
    except Exception as error:
        print_error_v1("Leave Scheduler Logs", error)
        return None
    

# METHOD: leave_error_logs
# DESCRIPTION: This Method will store leave api action logs.
# AUTHOR: Smeet Yelve
# Date: 21/08/2023
def leave_error_logs(api_name='',action='',status = '', description = '', leave_request_details = LeaveRequestsEDP(),**kwargs):
    try:
        store_error_logs = LeaveErrorLogs(
            unique_id = uuid.uuid4(),
            api_name = api_name,
            action = action,
            status = status,
            description = description,
            leave_request_id = leave_request_details.leave_request_id if leave_request_details else None,
            requestor_emp_id = kwargs.get('requestor_emp_id'),
            requestor_email = leave_request_details.requestor_email if leave_request_details else None,
            leave_category = leave_request_details.leave_category if leave_request_details else None,
            leave_type = leave_request_details.leave_type if leave_request_details else None,
            from_date = leave_request_details.from_date if leave_request_details else None,
            to_date = leave_request_details.to_date if leave_request_details else None,
            total_days = leave_request_details.total_days if leave_request_details else None,
            leave_status = kwargs.get('leave_status'),
            applied_date = leave_request_details.applied_date if leave_request_details else None,
            approver_emp_id = leave_request_details.approver_emp_id if leave_request_details else None,
            approver_email = leave_request_details.approver_email if leave_request_details else None,
            is_deleted = leave_request_details.is_deleted if leave_request_details else None,
            leave_created_datetime = leave_request_details.created_date_time if leave_request_details else None,
            leave_modified_datetime = leave_request_details.modified_date_time if leave_request_details else None,
            leave_created_by = leave_request_details.created_by if leave_request_details else None,
            leave_modified_by = leave_request_details.modified_by if leave_request_details else None,
            created_date_time = datetime.now(),
            modified_date_time = datetime.now()
        )
        store_error_logs.save()
    except Exception as error:
        print_error_v1("Leave Error Logs", error)
        return None