LEAVE_APPLICATION_MAIL_TEMPLATE = """
<!DOCTYPE html>
<html lang="en" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:v="urn:schemas-microsoft-com:vml">

<head>
	<title></title>
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
	<meta content="width=device-width, initial-scale=1.0" name="viewport" />
	<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css" />
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet" type="text/css" />
	<style>
		* {
			box-sizing: border-box;
		}

		body {
			margin: 0;
			padding: 0;
		}

		a[x-apple-data-detectors] {
			color: inherit !important;
			text-decoration: inherit !important;
		}

		#MessageViewBody a {
			color: inherit;
			text-decoration: none;
		}

		p {
			line-height: inherit
		}

		.desktop_hide,
		.desktop_hide table {
			mso-hide: all;
			display: none;
			max-height: 0px;
			overflow: hidden;
		}

		.mso_lr {
			mso-table-lspace: 0pt;
			mso-table-rspace: 0pt
		}
	</style>
</head>

<body style="background-color: #f7f7f7; margin: 0; padding: 0; -webkit-text-size-adjust: none; text-size-adjust: none;">
	<table border="0" cellpadding="0" cellspacing="0" class="nl-container" role="presentation"
		style="mso-table-lspace: 0pt;mso-table-rspace:0pt; background-color: #f7f7f7;" width="100%">
		<tbody>
			<tr>
				<td>
					<table border="0" cellpadding="0" cellspacing="0" class="row row-1 mso_lr" role="presentation"
						width="100%">
						<tbody>
							<tr>
								<td>
									<table border="0" cellpadding="0" cellspacing="0" class="row-content mso_lr"
										role="presentation"
										style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #fff; border-radius: 0; width: 100%;"
										width="100">
										<tbody>
											<tr>
												<td class="container"
													style="font-family:'Calibri', Times, serif; font-size: 14px; vertical-align: top; display: block; max-width: 100%; padding: 1px; width: 100%; Margin: 0 auto;"
													width="100%" valign="top">
													<div class="header" style="padding: 0px;">
														<table role="presentation" border="0" cellpadding="0"
															cellspacing="0" width="100%"
															style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt;">
															<tr style="height:80px;">
																<td
																	style="font-family:'Calibri', Times, serif;background: #6f42c1;  border-top-left-radius: 24px; text-align:start;">
																	<table border="0" cellpadding="0" cellspacing="0"
																		class="heading_block block-2"
																		role="presentation"
																		style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"
																		width="100%">
																		<tr>
																			<td>
																				&nbsp;
																			</td>
																			<td class="pad"
																				style="padding-right:10px; padding-top:5px; padding-bottom:5px;">
																				<div align="left"
																					style="line-height:10px">

																					<img src=drishti_heading
																						style="display: block; height: 18px; border: 0;"></img>
																				</div>
																			</td>
																		</tr>
																	</table>
																</td>

																<td
																	style="font-family:'Calibri', Times, serif; font-size: 28px; background:#6f42c1 ; border-top-right-radius: 24px; text-align: end; align-items:end ">
																	<table border="0" cellpadding="0" cellspacing="0"
																		class="image_block block-2"
																		style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"
																		width="100%">
																		<tr>
																			<td class="pad"
																				style="padding-right:10px; padding-top:5px; padding-bottom:5px; ">
																				<div align="right"
																					style="line-height:10px">
																					<img src=tata_logo
																						style="display: block; height: 30px; border: 0;"></img>

																				</div>
																			</td>
																		</tr>

																	</table>
																</td>
															</tr>
															<tr
																style=" height: 10px;width: 100%;background:leave_status_color">
																<td>
																	<div style=" height: 10px;width: 100%;background:leave_status_color">
																	</div>
																</td>
																<td>
																	<div
																		style=" height: 10px;width: 100%;background:leave_status_color">
																	</div>
																</td>
															</tr>

															<tr>
														</table>
													</div>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
						</tbody>
					</table>
					<table border="0" cellpadding="0" cellspacing="0" class="row row-2" role="presentation"
						style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
						<tbody>
							<tr>
								<td>
									<table border="0" cellpadding="0" cellspacing="0" class="row-content stack"
										role="presentation"
										style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; border-radius: 0; width: 100%;"
										width="600">
										<tbody>
											<tr>
												<td class="column column-1"
													style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; padding-top: 5px; padding-bottom: 5px; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;"
													width="100%">
													<table border="0" cellpadding="0" cellspacing="0"
														class="paragraph_block block-2" role="presentation"
														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; word-break: break-word;"
														width="100%">
														<tr>
															<td class="pad" style="padding-top:50px;">
																<div
																	style="color:#8a3c90;font-size:20px;font-family:'Calibri', Times, serif;font-weight:400;line-height:120%;text-align:center;direction:ltr;letter-spacing:0px;mso-line-height-alt:19.2px;">
																	<p style="margin: 0;">&nbsp;
																		<b>leave_request_title</b>&nbsp;
																	</p>
																</div>
															</td>
														</tr>
													</table>
													<table border="0" cellpadding="0" cellspacing="0"
														class="image_block block-4" role="presentation"
														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"
														width="100%">
														<tr>
															<td class="pad"
																style="width:100%;padding-right:0px;padding-left:0px;padding-top:50px;">
																<div align="center" class="alignment"
																	style="line-height:10px"><img
																		src=status_log
																		style="display: block; height: auto; border: 0; width: 210px; max-width: 100%;"
																		width="210" /></div>
															</td>
														</tr>
													</table>
													<table border="0" cellpadding="0" cellspacing="0"
														class="paragraph_block block-6" role="presentation"
														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; word-break: break-word;"
														width="100%">
														<tr>
															<td class="pad" style="padding-top:60px;text-align: start;">
																<table>
																	<tr>
																		<td>
																			<p>&nbsp;&nbsp;&nbsp;&nbsp;</p>
																		</td>
																		<td>
																			<div
																				style="color:#101112;font-size:16px;font-family:'Calibri', Times, serif;font-weight:400;line-height:120%;text-align:left;direction:ltr;letter-spacing:0px;mso-line-height-alt:19.2px;">
																				<p
																					style="margin: 0; margin-bottom: 16px;">
																					mail_salutation,
																				</p>
																				<p
																					style="margin: 0; margin-bottom: 16px;">
																					leave_request_content
																				</p>
																				<p style="margin: 0;">
																					Details are as below -
																				</p>
																			</div>
																		</td>
																	</tr>
																</table>
															</td>
														</tr>
													</table>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
						</tbody>
					</table>
					<table border="0" cellpadding="0" cellspacing="0" class="row row-3" role="presentation"
						style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
						<tbody>
							<tr>
								<td>
									<table border="0" cellpadding="0" cellspacing="0" class="row-content"
										role="presentation"
										style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; border-radius: 0; width: 100%;"
										width="100">
										<tbody>
											<tr>
												<td class="column column-1"
													style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;"
													width="50%">
													<table border="0" cellpadding="0" cellspacing="0"
														class="html_block block-2" role="presentation"
														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"
														width="100%">
														<tr>
															<td class="pad" style="padding-top:5px;padding-bottom:5px;">
																<div
																	style="font-family:'Calibri', Times, serif;text-align:start;">
																	<div
																		style="border-radius: 8px; margin: 10px; border: 0.1px solid #EAEAEA; font-family: 'Calibri', Times, serif;padding-top: 10px;padding-bottom: 5px;">
																		<span
																			style=" font-family: 'Calibri', Times, serif;font-size: 12px;color: #3B3B3B;">&nbsp;&nbsp;&nbsp;&nbsp;Company
																		</span><br /><br />
																		<table>
																			<tr>
																				<td>&nbsp;&nbsp;</td>
																				<td><span
																						style="color: rgba(59, 59, 59, 1);font-family:'Calibri', Times, serif;font-weight: Bold;">
																						company </span>
																				</td>
																			</tr>
																		</table>
																	</div>
																</div>
															</td>
														</tr>
													</table>
												</td>
												<td class="column column-2"
													style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;"
													width="50%">
													<table border="0" cellpadding="0" cellspacing="0"
														class="html_block block-2" role="presentation"
														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"
														width="100%">
														<tr>
															<td class="pad" style="padding-top:5px;padding-bottom:5px;">
																<div
																	style="font-family:'Calibri', Times, serif;text-align:start;">
																	<div
																		style="border-radius: 8px; margin: 10px; border: 0.1px solid #EAEAEA;font-family:'Calibri', Times, serif;padding-top: 10px;padding-bottom: 5px;">
																		<span
																			style=" font-family:'Calibri', Times, serif;font-size: 12px;color: #3B3B3B;">&nbsp;&nbsp;&nbsp;&nbsp;Employee
																			ID</span><br /><br />
																		<div> <span
																				style="color: rgba(59, 59, 59, 1);font-family: 'Calibri', Times, serif;font-weight: Bold;">&nbsp;&nbsp;&nbsp;emp_id
																			</span></div>
																	</div>
																</div>
															</td>
														</tr>
													</table>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
						</tbody>
					</table>
					<table border="0" cellpadding="0" cellspacing="0" class="row row-4" role="presentation"
						style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
						<tbody>
							<tr>
								<td>
									<table border="0" cellpadding="0" cellspacing="0" class="row-content"
										role="presentation"
										style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; border-radius: 0; width: 100%;"
										width="600">
										<tbody>
											<tr>
												<td class="column column-1"
													style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;"
													width="50%">
													<table border="0" cellpadding="0" cellspacing="0"
														class="html_block block-2" role="presentation"
														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"
														width="100%">
														<tr>
															<td class="pad" style="padding-top:5px;padding-bottom:5px;">
																<div
																	style="font-family:'Calibri', Times, serif;text-align:start;">
																	<div
																		style="border-radius: 8px; margin: 10px; border: 0.1px solid #EAEAEA; font-family: 'Calibri', Times, serif;padding-top: 10px;padding-bottom: 5px;">
																		<span
																			style=" font-family: 'Calibri', Times, serif;font-size: 12px;color: #3B3B3B;">&nbsp;&nbsp;&nbsp;&nbsp;Absence
																			Type</span><br /><br />
																		<span
																			style="color: rgba(59, 59, 59, 1);font-family:'Calibri', Times, serif;font-weight: Bold;">&nbsp;&nbsp;&nbsp;absence_type</span>
																	</div>
																</div>
															</td>
														</tr>
													</table>
												</td>
												<td class="column column-2"
													style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;"
													width="50%">
													<table border="0" cellpadding="0" cellspacing="0"
														class="html_block block-2" role="presentation"
														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"
														width="100%">
														<tr>
															<td class="pad" style="padding-top:5px;padding-bottom:5px;">
																<div
																	style="font-family:'Calibri', Times, serif;text-align:start;">
																	<div
																		style="border-radius: 8px; margin: 10px; border: 0.1px solid #EAEAEA;font-family: 'Calibri', Times, serif;padding-top: 10px;padding-bottom: 5px;">
																		<span
																			style="font-family:'Calibri', Times, serif;font-size: 12px;color: #3B3B3B;">&nbsp;&nbsp;&nbsp;&nbsp;Leave
																			Type</span><br /><br />
																		<table>
																			<tr>
																				<td>&nbsp;&nbsp;</td>
																				<td><span
																						style="color: rgba(59, 59, 59, 1);font-family:'Calibri', Times, serif;font-weight: Bold;">
																						leave_type </span>
																				</td>
																			</tr>
																		</table>
																	</div>
																</div>
															</td>
														</tr>
													</table>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
						</tbody>
					</table>
					<table border="0" cellpadding="0" cellspacing="0" class="row row-5" role="presentation"
						style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
						<tbody>
							<tr>
								<td>
									<table border="0" cellpadding="0" cellspacing="0" class="row-content"
										role="presentation"
										style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; border-radius: 0; width: 100%;"
										width="600">
										<tbody>
											<tr>
												<td class="column column-1"
													style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;"
													width="50%">
													<table border="0" cellpadding="0" cellspacing="0"
														class="html_block block-2" role="presentation"
														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"
														width="100%">
														<tr>
															<td class="pad" style="padding-top:5px;padding-bottom:5px;">
																<div
																	style="font-family:'Calibri', Times, serif;text-align:start;">
																	<div
																		style="border-radius: 8px; margin: 10px; border: 0.1px solid #EAEAEA; font-family:'Calibri', Times, serif;padding-top: 10px;padding-bottom: 5px;">
																		<span
																			style=" font-family:'Calibri', Times, serif;font-size: 12px;color: #3B3B3B;">&nbsp;&nbsp;&nbsp;&nbsp;Start
																			Date</span><br /><br />
																		<span
																			style="color: rgba(59, 59, 59, 1);font-family: 'Calibri', Times, serif;font-weight: Bold;">&nbsp;&nbsp;&nbsp;start_date</span>
																	</div>
																</div>
															</td>
														</tr>
													</table>
												</td>
												<td class="column column-2"
													style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;"
													width="50%">
													<table border="0" cellpadding="0" cellspacing="0"
														class="html_block block-2" role="presentation"
														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"
														width="100%">
														<tr>
															<td class="pad" style="padding-top:5px;padding-bottom:5px;">
																<div
																	style="font-family:'Calibri', Times, serif;text-align:start;">
																	<div
																		style="border-radius: 8px; margin:10px; border: 0.1px solid #EAEAEA;font-family: 'Calibri', Times, serif;padding-top: 10px;padding-bottom: 5px;">
																		<span
																			style=" font-family:'Calibri', Times, serif;font-size: 12px;color: #3B3B3B;">&nbsp;&nbsp;&nbsp;&nbsp;End
																			Date</span><br /><br />
																		<span
																			style="color: #070505;font-family: 'Calibri', Times, serif;font-weight: Bold;">&nbsp;&nbsp;&nbsp;end_date</span>
																	</div>
																</div>
															</td>
														</tr>
													</table>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
						</tbody>
					</table>
					<table border="0" cellpadding="0" cellspacing="0" class="row row-6" role="presentation"
						style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
						<tbody>
							<tr>
								<td>
									<table border="0" cellpadding="0" cellspacing="0" class="row-content stack"
										role="presentation"
										style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; border-radius: 0; width: 100%;"
										width="600">
										<tbody>
											<tr>
												<td class="column column-1"
													style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; padding-top: 5px; padding-bottom: 5px; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;"
													width="100%">
													<table border="0" cellpadding="0" cellspacing="0"
														class="html_block block-1" role="presentation"
														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"
														width="100%">
														<tr>
															<td class="pad">
																<div
																	style="font-family:'Calibri', Times, serif;text-align:start;">
																	<div
																		style="border-radius: 8px; margin: 10px; border: 0.1px solid #EAEAEA; font-family:'Calibri', Times, serif;padding-top: 10px;padding-bottom: 5px;">
																		<span
																			style=" font-family: 'Calibri', Times, serif;font-size: 12px;color: #3B3B3B;">&nbsp;&nbsp;&nbsp;Reason
																			For Leave</span><br /><br />
																		<table>
																			<tr>
																				<td>&nbsp;&nbsp;</td>
																				<td><span
																						style="color: rgba(59, 59, 59, 1);font-family: 'Calibri', Times, serif;font-weight: Bold;">leave_reason</span>
																				</td>
																			</tr>
																		</table>
																	</div>
																</div>
															</td>
														</tr>
													</table>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
						</tbody>
					</table>
					<table border="0" cellpadding="0" cellspacing="0" class="row row-7" role="presentation"
						style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
						<tbody>
							<tr>
								<td>
									<table border="0" cellpadding="0" cellspacing="0" class="row-content stack"
										role="presentation"
										style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; border-radius: 0; width: 100%;"
										width="600">
										<tbody>
											<tr>
												<td class="column column-1"
													style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; padding-top: 5px; padding-bottom: 5px; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;"
													width="100%">
													<table border="0" cellpadding="0" cellspacing="0"
														class="paragraph_block block-2" role="presentation"
														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; word-break: break-word;"
														width="100%">
														<tr>
															<td class="pad" align="start"
																style="padding-top:50px;text-align: start;">
																<table>
																	<tr>
																		<td>
																			<p>&nbsp;&nbsp;&nbsp;&nbsp;</p>
																		</td>
																		<td>
																			<div
																				style="color:#101112;font-size:16px;font-family:'Calibri', Times, serif;font-weight:400;line-height:120%;text-align:left;direction:ltr;letter-spacing:0px;mso-line-height-alt:19.2px;align-items:left;">
																				<p
																					style="margin: 0; margin-bottom: 16px;">
																					Regards,
																				</p>
																				<p
																					style="margin: 0; margin-bottom: 16px;">
																					<strong>Team Drishti</strong>
																				</p>
																				<p style="margin: 0;">
																					<strong>P.S.</strong> This is
																					a system generated mail, please do
																					not reply.
																				</p>
																		</td>
																	</tr>
																</table>
																</div>
															</td>
														</tr>
														<tr>
															<td>
																<p>&nbsp;&nbsp;&nbsp;&nbsp;</p>
															</td>
														</tr>
													</table>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
						</tbody>
					</table>

					<table align="center" border="0" cellpadding="0" cellspacing="0" class="row row-9"
						role="presentation"
						style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #6f42c1;border-bottom-left-radius: 24px; border-bottom-right-radius: 24px;"
						width="100%" height="80">
						<tbody>
							<tr style=" height: 10px;width: 100%;background: leave_status_color">
								<td>
									<div style=" height: 10px;width: 100%;background: leave_status_color">
									</div>
								</td>
							</tr>
							<tr>
								<td>
									<table align="center" border="0" cellpadding="0" cellspacing="0" class="row-content"
										role="presentation"
										style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000;  width: 100%;"
										width="100">
										<tbody>
											<tr>
												<td class="column column-2"
													style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;align-items:end;margin-left: 0px;margin-right: 0px;">
													<table border="0" cellpadding="0" cellspacing="0"
														class="image_block block-2" role="presentation"
														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"
														width="100%">
														<tr>
															<td class="pad"
																style="padding-right:10px; padding-top:5px; padding-bottom:5px; ">
																<div align="right" style="line-height:10px">
																	<img src=leave_mail_header
																		style="display: block; height: 50px; border: 0;"></img>
																</div>
															</td>
														</tr>
													</table>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
			</tr>
		</tbody>
	</table><!-- End -->
</body>

</html>
"""

leave_request_email_template = """ <div>
                                            <span>Dear Sir/Ma’am,</span>
                                        </div>
                                        <div>
                                            <br>This is to notify you that """ + "emp_id" + """ - """ +"emp_name"+ """ has submitted leave requests for your approval.</br>
                                            <br><br>Details are as below:</br></br>
                                        </div>
                                        <table style="padding:5px;width:800px" border="1" cellpadding="0" cellspacing="0">
                                            <tbody style="font-family: Calibri;font-size: 15px;width:800px"> 
                                                <tr>
                                                    <td><b>Company</b></td>
                                                    <td>Tata Motors Limited</td>
                                                </tr>
                                                <tr>
                                                    <td><b>Employee ID</b></td>
                                                    <td>"""+"emp_id"+"""</td>
                                                </tr>
                                                <tr>
                                                    <td><b>Leave Type</b></td>
                                                    <td>"""+"leave_type"+"""</td>
                                                </tr>
                                                <tr>
                                                    <td><b>Absence Type</b></td>
                                                    <td>"""+"absence_type"+"""</td>
                                                </tr>
                                                    <tr>
                                                    <td><b>Start Date</b></td>
                                                    <td>"""+"start_date"+"""</td>
                                                </tr>
                                                <tr>
                                                    <td><b>End Date</b></td>
                                                    <td>"""+"end_date"+"""</td>
                                                </tr>
                                                <tr>
                                                    <td><b>Reason</b></td>
                                                    <td>"""+"leave_reason"+"""</td>
                                                </tr>
                                            <tbody>
                                        </table>
                                        <div>
                                            <br><b>This will be auto approved in next 3 days in absence of any action from your end.</b></br>	
                                        </div>
                                        <div>
                                            <br><b>P.S:</b> This is a system generated mail, please do not reply</br>	
                                        </div>
                                        <div>
                                            <br><b>From,</b></br>	
                                            <br>Employee Mobile App</br>
                                        </div> """

# leave approval email template
leave_approval_email_template = """ <div>
                                            <span>Dear Sir/Ma’am,</span>
                                        </div>
                                        <div>
                                            <br>This is to notify you that your leave request has been approved.</br>
                                            <br><br>Details are as below:</br></br>
                                        </div>
                                        <table style="padding:5px;width:800px" border="1" cellpadding="0" cellspacing="0">
                                            <tbody style="font-family: Calibri;font-size: 15px;width:800px"> 
                                                <tr>
                                                    <td><b>Company</b></td>
                                                    <td>Tata Motors Limited</td>
                                                </tr>
                                                <tr>
                                                    <td><b>Employee ID</b></td>
                                                    <td>"""+"emp_id"+"""</td>
                                                </tr>
                                                <tr>
                                                    <td><b>Leave Type</b></td>
                                                    <td>"""+"leave_type"+"""</td>
                                                </tr>
                                                <tr>
                                                    <td><b>Absence Type</b></td>
                                                    <td>"""+"absence_type"+"""</td>
                                                </tr>
                                                <tr>
                                                    <td><b>Start Date</b></td>
                                                    <td>"""+"start_date"+"""</td>
                                                </tr>
                                                <tr>
                                                    <td><b>End Date</b></td>
                                                    <td>"""+"end_date"+"""</td>
                                                </tr>
                                                <tr>
                                                    <td><b>Reason</b></td>
                                                    <td>"""+"leave_reason"+"""</td>
                                                </tr>
                                            <tbody>
                                        </table>
                                        <div>
                                            <br><b>P.S:</b> This is a system generated mail, please do not reply</br>	
                                        </div>
                                        <div>
                                            <br><b>From,</b></br>	
                                            <br>Employee Mobile App</br>
                                        </div> """

# delete leave request email template
delete_leave_request_email_template = """ <div>
                                        <span>Dear Sir/Ma’am,</span>
                                    </div>
                                    <div>
                                        <br>This is to notify you that """ + "emp_id" + """ - """ +"emp_name"+ """ has submitted the delete leave requests for your approval.</br>
                                        <br><br>Details are as below:</br></br>
                                    </div>
                                    <table style="padding:5px;width:800px" border="1" cellpadding="0" cellspacing="0">
                                        <tbody style="font-family: Calibri;font-size: 15px;width:800px"> 
                                            <tr>
                                                <td><b>Company</b></td>
                                                <td>Tata Motors Limited</td>
                                            </tr>
                                            <tr>
                                                <td><b>Employee ID</b></td>
                                                <td>"""+"emp_id"+"""</td>
                                            </tr>
                                            <tr>
                                                <td><b>Leave Type</b></td>
                                                <td>"""+"leave_type"+"""</td>
                                            </tr>
                                            <tr>
                                                <td><b>Absence Type</b></td>
                                                <td>"""+"absence_type"+"""</td>
                                            </tr>
                                            <tr>
                                                <td><b>Start Date</b></td>
                                                <td>"""+"start_date"+"""</td>
                                            </tr>
                                            <tr>
                                                <td><b>End Date</b></td>
                                                <td>"""+"end_date"+"""</td>
                                            </tr>
                                            <tr>
                                                <td><b>Reason</b></td>
                                                <td>"""+"leave_reason"+"""</td>
                                            </tr>
                                        <tbody>
                                    </table>
                                    <div>
                                        <br><b>This will be auto approved in next 3 days in absence of any action from your end.</b></br>	
                                    </div>
                                    <div>
                                        <br><b>P.S:</b> This is a system generated mail, please do not reply</br>	
                                    </div>
                                    <div>
                                        <br><b>From,</b></br>	
                                        <br>Employee Mobile App</br>
                                    </div> """

# leave approval email template
delete_leave_approval_email_template = """ <div>
                                            <span>Dear Sir/Ma’am,</span>
                                        </div>
                                        <div>
                                            <br>This is to notify you that your delete leave request has been approved.</br>
                                            <br><br>Details are as below:</br></br>
                                        </div>
                                        <table style="padding:5px;width:800px" border="1" cellpadding="0" cellspacing="0">
                                            <tbody style="font-family: Calibri;font-size: 15px;width:800px"> 
                                                <tr>
                                                    <td><b>Company</b></td>
                                                    <td>Tata Motors Limited</td>
                                                </tr>
                                                <tr>
                                                    <td><b>Employee ID</b></td>
                                                    <td>"""+"emp_id"+"""</td>
                                                </tr>
                                                <tr>
                                                    <td><b>Leave Type</b></td>
                                                    <td>"""+"leave_type"+"""</td>
                                                </tr>
                                                <tr>
                                                    <td><b>Absence Type</b></td>
                                                    <td>"""+"absence_type"+"""</td>
                                                </tr>
                                                <tr>
                                                    <td><b>Start Date</b></td>
                                                    <td>"""+"start_date"+"""</td>
                                                </tr>
                                                <tr>
                                                    <td><b>End Date</b></td>
                                                    <td>"""+"end_date"+"""</td>
                                                </tr>
                                                <tr>
                                                    <td><b>Reason</b></td>
                                                    <td>"""+"leave_reason"+"""</td>
                                                </tr>
                                            <tbody>
                                        </table>
                                        <div>
                                            <br><b>P.S:</b> This is a system generated mail, please do not reply</br>	
                                        </div>
                                        <div>
                                            <br><b>From,</b></br>	
                                            <br>Employee Mobile App</br>
                                        </div> """
BODY_OF_ERROR_POSTING_LEAVE_TEMPLATE = """

##Testing Mail
Hi Giftson,

We're sharing with you the CV System "Error in Posting" leave case. PFA

Let me know in case of any queries.

Regards,
Drishti App 
"""



nudge_for_leave_template =  """
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Happy Birthday!</title>
    <style>
        .body {
            width: 100%;height: 100%;background: #F0F0F0;font-family: 'Calibri', Times, serif;
        }
        .bg {
            background: #F0F0F0;
        }
        .wishes {
            font-size: 20px;color: #512C92;font-family: 'Calibri', Times, serif;
        }
        .cakeimg {
            height: 87px;
        }
        .content {
            font-size: 18px;color: #000000;
        }
        .uptdleft {
            background: #512C92;border-top-left-radius: 24px;width: 2%;
        }
        .uptdright {
            background: #512C92;border-top-right-radius: 24px;width: 5%;
        }
        .downtdleft {
            background: #512C92;border-bottom-left-radius: 24px;width: 2%;
        }
        .downtdright {
            background: #512C92;border-bottom-right-radius: 24px;width: 5%;
        }
        .alignstart {
            align-items: start;background: #512C92;
        }
        .alignend {
            align-items: end;background: #512C92;
        }
        .headfootheight{
            height: 80px;
        }
        .blueline{
            height:10px;width: 100%;background:#248AF8
        }
        .header1{
           height: 16px;display: block;border: 0;width: 90px;
        }
        .header2{
            height:20px;display: block;border: 0;width: 90px;
        }
        .footer{
            height:38px;border: 0; display: block;width: 90px;
        }
        .margindiv{
            color:#101112;font-size:16px;font-family:'Calibri', Times, serif;font-weight:400;line-height:120%;text-align:left;direction:ltr;letter-spacing:0px;mso-line-height-alt:19.2px;
        }
        .margin-bottom{
            margin: 0; margin-bottom: 16px;
        }
    </style>
</head>

<body>
    <table class="body" cellspacing="0" cellpadding="0">
        <tr class="headfootheight">
            <td class="uptdleft">
                &nbsp;
            </td>
            <td class="alignstart">
                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                    <tr>
                        <td>
                            &nbsp;
                        </td>
                        <td>
                            <div align="left">

                                <img src=https://di0zifa10d7yc.cloudfront.net/EDP/TML/image/drishti_log.png
                                  class="header1"></img>
                            </div>
                        </td>
                    </tr>
                </table>
            </td>

            <td class="alignend">
                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                    <tr>
                        <td>
                            <div align="right">
                                <img src=https://di0zifa10d7yc.cloudfront.net/EDP/TML/leaveMailPicture/tata_motor_logo.png
                                   class="header2"></img>

                            </div>
                    </tr>
                </table>
            </td>
            <td class="uptdright">
                &nbsp;
            </td>
        <tr class="blueline">
            <td colspan="2">
                <div class="blueline">
                </div>
            </td>
            <td colspan="2">
                <div class="blueline">
                </div>
            </td>
        </tr>
        </tr>

        <tr>
            <td colspan="4" class="bg">&nbsp;</td>
        </tr>

        <tr>
            <td align="center" colspan="4" class="bg">
                <span class="wishes"><strong>Don’t forget to take your time-off!</strong></span>
            </td>
        </tr>
        <tr>
            <td colspan="4" class="bg">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="4" class="bg">&nbsp;</td>
        </tr>
        <tr align="center">

            <td colspan="4">
                <span><img class="cakeimg"
                        src="https://di0zifa10d7yc.cloudfront.net/EDP/TML/image/custom_message.png "></span>
            </td>
        </tr>
          
        <tr>
            <td colspan="4" class="bg">&nbsp;</td>
        </tr>
         <tr>
            <td colspan="4" class="bg">&nbsp;</td>
        </tr>
        <tr>
            <td>
                <p>&nbsp;&nbsp;&nbsp;&nbsp;</p>
            </td>
            <td colspan="3">
                <div class="margindiv">
                    <p class="margin-bottom">
                        mail_salutation,
                    </p>
                    <p class="margin-bottom">
                        Emotional and physical wellbeing is key for your health and safety.
                    </p>
                    <p class="margin-bottom">
                        Please plan time off from your work to relax and reenergize yourself.
                    </p>
                </div>
            </td>
        </tr>
        <tr>
            <td>
                <p>&nbsp;&nbsp;&nbsp;&nbsp;</p>
            </td>
            <td colspan="3">
                <div class="margindiv">
                    <p class="margin-bottom">
                        Regards,
                    </p>
                    <p class="margin-bottom">
                        <strong>manager_name</strong>
                    </p>
            </td>
        </tr>

        <tr>
            <td colspan="4" class="bg">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="4" class="bg">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="4" class="bg">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="4" class="bg">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="4" class="bg">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="4" class="bg">&nbsp;</td>
        </tr>
        <tr class="blueline">
            <td colspan="2">
                <div class="blueline">
                </div>
            </td>
            <td colspan="2">
                <div class="blueline">
                </div>
            </td>
        </tr>
        <tr class="headfootheight">
            <td class="downtdleft">
                &nbsp;
            </td>
            <td class="alignstart">
                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                    <tr>
                        <td>
                            <div align="left">
                            </div>
                        </td>
                    </tr>
                </table>
            </td>

            <td class="alignend">
                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                    <tr>

                        <td>
                            <div align="right">
                                <img src=https://di0zifa10d7yc.cloudfront.net/EDP/TML/leaveMailPicture/header_logo.png
                                   class="footer"></img>

                            </div>

                    </tr>

                </table>
            </td>
            <td class="downtdright">
                &nbsp;
            </td>
        </tr>
    </table>
</body>

</html>

"""