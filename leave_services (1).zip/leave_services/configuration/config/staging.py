import os

################################## KEYCLOAK START ##################################################################################################
KEYCLOAK_URL = "https://qa.sso.tatamotors.com/auth/"
CLIENT_ID = os.getenv('CLIENT_ID','')
CLIENT_SECRET_KEY = os.getenv('CLIENT_SECRET_KEY','')
REALM_NAME = os.getenv('REALM_NAME','')

PREFERRED_USERNAME = "service-account-tml-edp"
TOKEN_EXPIRED_ERROR = "session timeout"
INVALID_TOKEN = "Session Timeout"
GRANT_TYPE = "password"
EDP_CLIENT_ID = os.getenv('CLIENT_ID','')
ISS = "https://qa.sso.tatamotors.com/auth/realms/udyog"
######################################## KEYCLOAK END ###############################################################################################

##################################### CLOUDFRONT START ##############################################################################################
CLOUDFRONT_CDN_URL= "https://di0zifa10d7yc.cloudfront.net/"
############################### CLOUDFRONT END ######################################################################################################

###################################### AWS S3 START #################################################################################################
CLOUDFRONT_USERNAME = os.getenv('CLOUDFRONT_USERNAME','')
CLOUDFRONT_AWS_ACCESS_KEY_ID = os.getenv('CLOUDFRONT_AWS_ACCESS_KEY_ID','')
CLOUDFRONT_AWS_SECRET_KEY = os.getenv('CLOUDFRONT_AWS_SECRET_KEY','')
CLOUDFRONT_BUCKET_KEY = os.getenv('CLOUDFRONT_BUCKET_KEY','')
CLOUDFRONT_PROFILE_PICTURE= "EDP/TML/profilePictures/"
###################################### AWS S3 END ###################################################################################################

############################################# DRIHSTI WEB SERVICE SECTION START######################################################################
#LEAVE SCHEDULER TIME
auto_approval_days = 0
time_minutes = 30

#GATEWAY Basic CONFIGUARATION
KONG_BASE_URL = "https://empapidev.tatamotors.com/"
CV_DOCUMENT = "cv/documents/"
CV_PROFILE = "cv/profile/"
CV_LEAVE= "cv/leave/"
# This is create leave request notification 
create_leave_request_notification_url = KONG_BASE_URL + CV_PROFILE +  "attendance_marking/create_leave_request_notification/"

# This is create leave approval notification
create_leave_approval_notification_url = KONG_BASE_URL + CV_PROFILE + "attendance_marking/create_leave_approval_notification/"

#This is send inapp notification
add_inapp_notification = KONG_BASE_URL + CV_PROFILE + "attendance_marking/add_inapp_notification/"

#This is used to store employee activity logs
create_activity_log_url =  KONG_BASE_URL + CV_DOCUMENT + "document/create_activity_log/"
 
#Get employee employee details
get_edp_employee_details = KONG_BASE_URL + 'authentication/get_edp_employee_details/'

#Get the employee user detail by success factor web services
GET_SF_USER_DETAILS = KONG_BASE_URL + 'success_factor/get_success_factor_user_details/'
GET_LEAVE_QUOTA = KONG_BASE_URL + CV_LEAVE + 'leave_requests/get_leave_quota/'

#Get employee profile pictures
get_profile_picture = KONG_BASE_URL + 'ms_todo/get_bulk_profile_image/'

# get active employee list
get_active_employee_list = KONG_BASE_URL + "authentication/get_active_employee_list/"
# ...
producer_leave_notification=KONG_BASE_URL+'drishti_kafka/producer_leave_notification/'

# Fetch employee type
FETCH_EMPLOYEE_TYPE = KONG_BASE_URL + "authentication/fetch_employee_type/"

#Team Chatbot Notification - for staging.
team_bot_url="https://tml-drishti-lx-bot.azurewebsites.net/api/approve-reject/notify"
team_chatbot_notification = "https://tml-drishti-lx-bot.azurewebsites.net//api/notify-activity"
################################################ DRIHSTI WEB SERVICE END #############################################################################

######################################### SAP HR WEB SERVICES START ##################################################################################
#CV SAP HR WEBSERVICES
CV_SAP_HR_HOST_NAME = ""
CV_SAP_HR_HOST_IP = os.getenv('CV_SAP_HR_HOST_IP','')
CV_CLIENT = os.getenv('CV_CLIENT','')
CV_PORT = os.getenv('CV_PORT','')

# SAP HR WEBSERVICES AUTHENTICATION
cv_sap_webservice_id = os.getenv('cv_sap_webservice_id','')
cv_sap_webservice_password = os.getenv('cv_sap_webservice_password','')

leave_quota_request_url = CV_SAP_HR_HOST_IP + ":" + CV_PORT +  "/sap/bc/srt/rfc/sap/zw_zftm0014/"  + CV_CLIENT + "/zw_zftm0014/zw_zftm0014"
leave_validate_update_request_url = CV_SAP_HR_HOST_IP + ":" + CV_PORT +  "/sap/bc/srt/rfc/sap/zw_zftm0015/"  + CV_CLIENT + "/zw_zftm0015/zw_zftm0015"
attendance_enquiry_request_url = CV_SAP_HR_HOST_IP + ":" + CV_PORT +  "/sap/bc/srt/rfc/sap/zw_zftm0016/"  + CV_CLIENT + "/zw_zftm0016/zw_zftm0016"
leave_history_request_url = CV_SAP_HR_HOST_IP + ":" + CV_PORT +  "/sap/bc/srt/rfc/sap/zw_zftm0017/"  + CV_CLIENT + "/zw_zftm0017/zw_zftm0017"
################################################ SAP HR WEB SERVICE END ##############################################################################

#Error in Posting Mail Receivers
TML_EDP_MAIL_RECIVER = ['tml-drishti@sankeysolutions.com']




