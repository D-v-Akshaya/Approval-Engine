
#Configuration setting for staging and production. 
#Access for particular environment, Pls do the uncomment according you need and for others do commnented.
from .staging import *

#from .production import *