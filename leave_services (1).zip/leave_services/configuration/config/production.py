import os
###################################### KEYCLOAK START ############################################################################################
CLIENT_SECRET_KEY = os.getenv('CLIENT_SECRET_KEY','')
KEYCLOAK_URL = "https://sso.tatamotors.com/auth/"
REALM_NAME = os.getenv('REALM_NAME','')
CLIENT_ID = os.getenv('CLIENT_ID','')
PREFERRED_USERNAME = "service-account-tml-edp"
TOKEN_EXPIRED_ERROR = "session timeout"
INVALID_TOKEN = "Session Timeout"
GRANT_TYPE = "password"
EDP_CLIENT_ID = os.getenv('CLIENT_ID','')
ISS = "https://sso.tatamotors.com/auth/realms/udyog"
###################################### KEYCLOAK END ###############################################################################################

####################################### CLOUDFRONT START ##########################################################################################
CLOUDFRONT_CDN_URL = "https://dige2fljfurh1.cloudfront.net/"
###################################### CLOUDFRONT END #############################################################################################

######################################## AWS S3 START #############################################################################################
CLOUDFRONT_USERNAME = os.getenv('CLOUDFRONT_USERNAME','')
CLOUDFRONT_AWS_ACCESS_KEY_ID = os.getenv('CLOUDFRONT_AWS_ACCESS_KEY_ID','')
CLOUDFRONT_AWS_SECRET_KEY = os.getenv('CLOUDFRONT_AWS_SECRET_KEY','')
CLOUDFRONT_BUCKET_KEY = os.getenv('CLOUDFRONT_BUCKET_KEY','')
CLOUDFRONT_PROFILE_PICTURE = "EDP/TML/profilePictures/"
######################################## AWS S3 END ###############################################################################################

############################################## DRIHSTI WEB SERVICE SECTION START###################################################################
KONG_BASE_URL = "https://empapi.tatamotors.com/"
CV_DOCUMENT = "cv/documents/"
CV_PROFILE = "cv/profile/"
CV_LEAVE= "cv/leave/"

#LEAVE SCHEDULER TIME
auto_approval_days = 3
time_minutes=30

# This is create leave request notification 
create_leave_request_notification_url = KONG_BASE_URL + CV_PROFILE +  "attendance_marking/create_leave_request_notification/"

# This is create leave approval notification
create_leave_approval_notification_url = KONG_BASE_URL + CV_PROFILE + "attendance_marking/create_leave_approval_notification/"
add_inapp_notification = KONG_BASE_URL + CV_PROFILE + "attendance_marking/add_inapp_notification/"

#This is used to store employee activity logs
create_activity_log_url =  KONG_BASE_URL + CV_DOCUMENT + "document/create_activity_log/"

# get active employee list
get_active_employee_list = KONG_BASE_URL + "authentication/get_active_employee_list/"

#Get employee employee details
get_edp_employee_details = KONG_BASE_URL + 'authentication/get_edp_employee_details/'
get_success_factor_user_details = KONG_BASE_URL + 'success_factor/get_success_factor_user_details/'
get_profile_picture = KONG_BASE_URL + 'ms_todo/get_bulk_profile_image/'
producer_leave_notification=KONG_BASE_URL+'drishti_kafka/producer_leave_notification/'

# Get SF details
GET_SF_USER_DETAILS = KONG_BASE_URL + 'success_factor/get_success_factor_user_details/'
GET_LEAVE_QUOTA = KONG_BASE_URL + CV_LEAVE + 'leave_requests/get_leave_quota/'

# Team Chatbot Notification - for prod.
team_bot_url="https://tml-drishti-bot.azurewebsites.net/api/approve-reject/notify"
team_chatbot_notification = "https://tml-drishti-bot.azurewebsites.net/api/notify-activity"

# Fetch employee type
FETCH_EMPLOYEE_TYPE = KONG_BASE_URL + "authentication/fetch_employee_type/"
############################################## DRIHSTI WEB SERVICE END #############################################################################

######################################### SAP HR WEB SERVICES START ################################################################################
#CV SAP HR WEBSERVICES
CV_SAP_HR_HOST_NAME = ""
CV_SAP_HR_HOST_IP = os.getenv('CV_SAP_HR_HOST_IP','')
CV_CLIENT = os.getenv('CV_CLIENT','')
CV_PORT = os.getenv('CV_PORT','')

#CV SAP WEBSERVICE AUTHENTICATION
cv_sap_webservice_id = os.getenv('cv_sap_webservice_id','')
cv_sap_webservice_password = os.getenv('cv_sap_webservice_password','')

leave_quota_request_url = CV_SAP_HR_HOST_IP + ":" + CV_PORT +  "/sap/bc/srt/rfc/sap/zw_zftm0014/"  + CV_CLIENT + "/zw_zftm0014/zw_zftm0014"
leave_validate_update_request_url = CV_SAP_HR_HOST_IP + ":" + CV_PORT +  "/sap/bc/srt/rfc/sap/zw_zftm0015/"  + CV_CLIENT + "/zw_zftm0015/zw_zftm0015"
attendance_enquiry_request_url = CV_SAP_HR_HOST_IP + ":" + CV_PORT +  "/sap/bc/srt/rfc/sap/zw_zftm0016/"  + CV_CLIENT + "/zw_zftm0016/zw_zftm0016"
leave_history_request_url = CV_SAP_HR_HOST_IP + ":" + CV_PORT +  "/sap/bc/srt/rfc/sap/zw_zftm0017/"  + CV_CLIENT + "/zw_zftm0017/zw_zftm0017"
############################################## SAP HR WEB SERVICE END ###############################################################################

#Error in Posting Mail Receivers
TML_EDP_MAIL_RECIVER = ['Giftson.Jeyakumar@tatamotors.com','skk524309@tatamotors.com','tml-drishti@sankeysolutions.com']
