STATUS_CODE = "status_code"
MESSAGE = "message"
DATA = "data"
FAILURE = "Something Went Wrong"
ADD_CORRECT_LEAVE_STATUS = "Kindly Add the Correct Leave Status"
LEAVE_REQUEST = "Leave Requests"
DELETE_LEAVE_REQUEST = "Delete Leave Request"
GET_CET_DATA_FAILED = "Unable to fetch cet details"
GET_SF_DATA_FAILED = "Unable to fetch success factor user details"
SERVER_ERROR_MESSAGE = {
    "status_code": "500",
    "message": "Unable to contact server. please try again later",
}
SUCCESSFULLY_WORKING = {
    "status_code": "200",
    "message": "Leave delete successfully",
}
INVALID_REQUEST_BODY = {
    "status_code": "500",
    "message": "Something went wrong",
}
DELETE_LEAVE_REQUEST = {
    "status_code": "200",
    "message": "Leave delete successfully",
}
UNABLE_TO_DELETE_LEAVE = {
    "status_code": "500",
    "message": "Unable to delete leave request"
}
DELETE_LEAVE_ACCESS_ERROR = {
    "status_code": "200",
    "message": "You are not allowed to delete this leave request."
}
SUCCESSFULLY_ACTIVITY_LOG =  {
                    "status_code":"200",
                    "message":"Create logs created successfully",
                }
SUCCESS = {
    "status_code": "200",
    "message": "Detail retrived Successfully",
}
NUDGE_SUCCESS = {
    "status_code": "200",
    "message": "Nudge request successfully sent!",
}
ERROR = {
    "status_code": "500",
    "message": "Unable to contact server. please try again later",
}
FAIL= {
    "status_code": "500",
    "message": "Something went wrong",
}
EMPTY_DATA =  {
    "status_code": "500",
    "message": "No data found",
}
INVALID_INCIDENT_ID = {
     "status_code": "500",
    "message": "Invalid incident id",
}

KEYCLOAK_UNAUTHORIZED_ACCESS = {
                "status" : "401",
                "message" : "Unauthorized access"
            }
LEAVE_REQUEST="New approval requests are here"
LEAVE_DELETE="New leave delete requests are here"
LEAVE_APPROVAL_NOTIFICATION="Your leave was approved"
LEAVE_AUTO_APPROVED ="Your leave was auto approved"
LEAVE_REJECT ="Your leave was rejected by your manager"
LEAVE_DELETE_APPROVE ="Your leave deletion request was approved"
LEAVE_DELETE_AUTO_APPROVE="Your leave deletion request was auto approved"
LEAVE_DELETE_REJECT ="Your leave deletion request was rejected"
ADD_ANOTHER_LEAVE_WARNING_MESSAGE = "Please ensure that sufficient quota is available before submitting multiple leave request"
LEAVE_ANOTHER_LEVAE_WARNING = {
    "status_code": "500",
    "message": "Please ensure that sufficient quota is available before submitting multiple leave request",
}
NO_DATA_FOUND = "Data not found"
INVALID_REQUEST_BODY =  "Something went wrong",
SUCCESS_RETIVED_DATA = "Data retrived successfully"
DATA_UPDATED = "Data Updated Successfully"
NO_DATA_TO_UPDATE = "No Data to Update"
WFH_LEAVE_ERROR = "WFH cannot be applied on Tuesday and Thursday."
WFH_LEAVE_ERROR_ERCU = "WFH cannot be applied on Tuesday, Wednesday and Thursday."
INTERNAL_SERVER_ERROR = "Internal Server Error"
#Success Wrapper Status Code
SUCCESS_STATUS_CODE="200"
ERROR_STATUS_CODE="500"

KEYCLOAK_UNAUTHORIZED_ACCESS_V1 = {
    "status": "401",
    "message": "Unauthorized access",
    "info": "URLs does not exists in allowed BLUE_COLLAR_PATHS list"
}
REPORTING_MANAGER_NOT_FOUND="Reporting data issue. Kindly reach out to BHR to correct reporting manager details in SAP HR"
SOMETHING_WENT_WRONG = "Something went wrong"
INVALID_REQUEST_BODY_V1 = "Some required fields are missing"
SAP_RESPONSE_ERROR = "Error occured while retrieving response from SAP webservice"
TO_DATE_ERROR = "To date should be greater than from date or less than today"
FROM_DATE_ERROR = "From date should be greater than date before 3 months or less than today's date"

NOT_SAME_COMP = "Employee is not from the Same company"
UPDATE_STOPPED_DUE_TO_LWOP = "Updation Stop due to LWOP"
ERROR_IN_POSTING_LWOP = "Updation Stop due to LWOP - Error in Posting"
ERROR_IN_POSTING = "Unable to Update Leave in SAP - Error in Posting"
ERROR_IN_DELETION = "Unable to Update Leave in SAP - Error in Deletion"
ADD_LWOP_LEAVE= "Adding an LWOP Leave"
LEAVE_ALREADY_POSTED = "Leave Deletion Already Posting in SAP"
LEAVE_POSTED_IN_SAP = "Leave Posting Successful in SAP"
LEAVE_POSTING_SUCCESSFUL = "Leave Posting Program Run Sucessfully"
LEAVE_NOT_POSTED_IN_SAP = "Unable to Post Leave in SAP"
WEBSERVICE_FAILED = "SAP Webservice Failed"
WEBSERVICE_ERROR = "SAP Webservice Error"
POSTING_ERROR = "Error Posting Leave in SAP"
NO_DATA_EDP = "Leave Request is not present in Leave Request EDP table"
SCHEDULER_STOPPED = "Leave Scheduler (Old): Leave Scheduler(Old) has been stopped"
SCHEDULER_STOPPED_V1 = "Leave Scheduler V1 (New): Leave Scheduler stopped due to executing Leave without pay program"
ERROR_SCHEDULER_STOPPED = "Export to Excel Scheduler has been stopped."
LEAVES_SYNCED = "Leaves Synced Successfully"
