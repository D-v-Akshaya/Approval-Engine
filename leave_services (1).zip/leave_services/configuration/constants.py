# Drishti Internal Status code & message series - 6XX
SYNC_LEAVES = ['leave_status']
SYNC_EMP_LEAVES = ['emp_id']
LEAVE_STATUS = ["1","2","5","6","7","8","9"]
EARLY_LATE_ATTENDANCE = ['E0','V0']
SUCCESS = 'Success'
FAILURE = 'Failure'
VIEW = 'VIEW'
EDIT = 'EDIT'
DEL_LEAVE_REQ = "DEL leave request"
ERROR_IN_POSTING = "Leave Error in Posting"
LWOP_LEAVE = "LWOP Leave"
POSTING = "Posting"
POSTED = "Leave Posted"
NOT_POSTED = "Leave Not Posted"
STOPPED = "Stopped"
INTERNAL_SERVER_ERROR = "Internal Server Error"
ERROR = "Error"

#API names
GET_LEAVE_HISTORY_SAP_V1 = "get_leave_history_sap_v1"
SYNC_LEAVE_REQUEST_SAP = "sync_leave_requests_sap"
ERROR_IN_POSTING_FORCE_RUN_V1 = "error_in_posting_force_run_v1"
ERROR_IN_DELETION_FORCE_RUN_V1 = "error_in_deletion_force_run_v1"

#Scheduler Names
UPDATE_LEAVE_REQUEST_SAP = "update_leave_request_sap"
UPDATE_LEAVE_REQUEST_SAP_V1 = "update_leave_request_sap_v1"
LEAVE_REQUEST_AUTO_APPROVAL = "leave_request_auto_approval"
FORCE_ERROR_IN_POSTING_SAP_UPDATE = "force_error_in_posting_sap_update"
FORCE_ERROR_IN_POSTING_SAP_UPDATE_V1 = "force_error_in_posting_sap_update_v1"
EXPORT_TO_EXCEL_ERROR_IN_POSTING = "export_to_excel_error_in_posting"
EXPORT_TO_EXCEL_ERROR_IN_POSTING_V1 = "export_to_excel_error_in_posting_v1"
# 600 – Bad gateway(Invalid request body).
# 601 – Unauthorized Access
# 602 - Success Message(Optional).
# 603 – Interval server error
# 604 -
# 605 – Invalid/Inactive employee ID
# 606 – Wrong credential.
# 607 -
# 608 -
# 609-
import base64
# with open("./leave_requests/images/leave_mail_footer.png", "rb") as img_file:
#     leave_mail_footer = base64.b64encode(img_file.read()).decode('utf-8')
# with open("./leave_requests/images/leave_mail_header.png", "rb") as img_file:
#     leave_mail_header = base64.b64encode(img_file.read()).decode('utf-8')

# import base64
# with open("./leave_requests/images/leave_request_logo.png", "rb") as img_file:
#     leave_request_logo = base64.b64encode(img_file.read()).decode('utf-8')
# with open("./leave_requests/images/leave_approved_logo.png", "rb") as img_file:
#     leave_approved_logo = base64.b64encode(img_file.read()).decode('utf-8')
# with open("./leave_requests/images/leave_mail_header.png", "rb") as img_file:
#     leave_mail_header = base64.b64encode(img_file.read()).decode('utf-8')
# with open("./leave_requests/images/delete_approve_leave.png", "rb") as img_file:
#     delete_approve_leave = base64.b64encode(img_file.read()).decode('utf-8')
with open("./page.png", "rb") as img_file:
    central_image = base64.b64encode(img_file.read()).decode('utf-8')

leave_approved_logo = "https://di0zifa10d7yc.cloudfront.net/EDP/TML/leaveMailPicture/leave_approval.png"
leave_request_logo = "https://di0zifa10d7yc.cloudfront.net/EDP/TML/leaveMailPicture/leave_request.png"
leave_mail_header = "https://di0zifa10d7yc.cloudfront.net/EDP/TML/leaveMailPicture/header_logo.png"
delete_approve_leave = "https://di0zifa10d7yc.cloudfront.net/EDP/TML/leaveMailPicture/delete_approve.png"
leave_reject_logo = "https://di0zifa10d7yc.cloudfront.net/EDP/TML/leaveMailPicture/leave_reject.png"
drishti_heading = "https://di0zifa10d7yc.cloudfront.net/EDP/TML/image/drishti_log.png"
tata_logo = "https://di0zifa10d7yc.cloudfront.net/EDP/TML/leaveMailPicture/tata_motor_logo.png"
nudge_for_leave = "https://di0zifa10d7yc.cloudfront.net/EDP/TML/image/custom_message.png"


#HTTP STANDARD STATUS CODE
HTTP_100_CONTINUE = 100 
HTTP_200_OK = 200 
HTTP_201_CREATED = 201 
HTTP_202_ACCEPTED = 202 
HTTP_204_NO_CONTENT = 204 
HTTP_400_BAD_REQUEST = 400 
HTTP_401_UNAUTHORIZED = 401 
HTTP_403_FORBIDDED = 403 
HTTP_404_NOT_FOUND = 404 
HTTP_405_METHOD_NOT_ALLOWED = 405 
HTTP_408_REQUEST_TIMEOUT = 408 
HTTP_423_LOCKED = 423 
HTTP_429_RATE_LIMITING = 429 
HTTP_500_INTERNAL_SERVER_ERROR = 500 
HTTP_501_NOT_IMPLEMENTED = 501 
HTTP_502_BAD_GATEWAY = 502 
HTTP_503_SERVICE_UNAVAILABLE = 503 
HTTP_504_GATEWAT_TIMEOUT = 504 


# NOTIFICATION TYPE
NUDLE_FOR_LEAVE = "Nudge for leave"
EMPTY_ATTENDANCE_COLOR = "#ffffff"
FROM_MAIL = 'drishti-alerts@tatamotors.com'
# NOTIFICATION_REASON
NUDGE_FOR_LEAVE_DESCRIBITION = "Reminder from reporting_manager to take your leaves!"
ADD_ANOTHER_LEAVE_WARNING_MESSAGE = "Please ensure that sufficient quota is available before submitting multiple leave request"
LEAVE_SUCCESS = "Leave requests submitted successfully "
time_minutes = 5
WEEKLY_OFF_TEXT = "Weekly Offs"
WEEKLY_OFF_COLOR = "#8D4DF1"
PUBLIC_HOLIDAY_TEXT = "Public Holidays"
PUBLIC_HOLIDAY_COLOR = "#6A3399"
All_MONTH = "All"
APPORVED_LEAVE = "2"
PA = "ERCU"
DATE_FORMAT = "%Y-%m-%d"
COMP_CODE = "0100"
PLATFORM = "platform"
SUBJECT_OF_ERROR_POSTING_LEAVE_MAIL = "Error In Posting Job - CV System"
#NUDGE FOR LEAVE MAIL
nudge_for_leave_text_1 = "Emotional and physical wellbeing is key for your health and safety."
nudge_for_leave_text_2 = "Please plan time off from your work to relax and reenergize yourself."
nudge_for_leave_heading = "Don’t forget to take your time-off!"
NUDGE_FOR_LEAVE_SUBJECT = "Reminder from reporting_manager to take your leaves!"

# PLANNED_LEAVE_CATEGORY
PLANNED_LEAVE_CATEGORY = ['L0', 'M0', 'P0']

# default approval email
system_approver_email = "drishti-alerts@tatamotors.com"

# Client Side firebase secret key
ANDROID_FIREBASE_SECRET_KEY = "AAAAuUm_SpE:APA91bHr7vvDc5sDORRHbdtlh8acLJLSkmCNkaieRhdrhFn959UcFRe614tVfHoXW0COtoYZQkrlCNjz1rlEky35WUvexZ-1g_-nC8Hkr9rRuYadLxsrp0DdItRr22lMP7Kv9n5X9jme"

# IOS_FIREBASE_SECRET_KEY
IOS_FIREBASE_SECRET_KEY = "AAAApFWcpvo:APA91bFxRPLw22kM1mTcHpydk03QCMj1vjWlQJe8-iR3Zjdhb7tqALlVf3Bs0O9kWlX2UgUpbxMIaCgttd359GgdViWdDOFFpBQjA_3-hjF-2wz89B2mM3SbCzR6m-m8jHkBcmFHQb72"

# personal firebase account
# FIREBASE_SECRET_KEY = "AAAAcVbGyQg:APA91bEu_msGT3EEwsnMwV-ESac7YrWl3yZTe0lNizi2yCDTaL6eA9Yd3dHTgTIDYTBUPeJ149f0FtZNWytAh2_aTp8w0HGvrjrCHYKZuPnV3Lwb8Zkl7AEzHbo2bb7bnIMiK8MViX3W"

# push notification url
PUSH_NOTIFICATION_URL = "https://fcm.googleapis.com/fcm/send"

# reporting manager emp_id
# reporting_manager_emp_id = ["00139052", "00530557","00531081", "00531377", "00532135", "00664891"]

# unauthorized leave category status IN sap
sap_leave_category_status = ['X0', "Z0", "Z0P", "X0P"]
YES = "YES"
NO = "NO"

# default approval email
SYSTEM_APPROVER_MAIL = "drishti-alerts@tatamotors.com"
CV_COMPANY = "Tata Motors Limited"

# ##################### KAFKA CONSTANTS START #####################
eventSource = "DRISHTI"
channel = "TEAMS"
adaptiveCardType = ["TASK_MODULE", "TEXT_CARD", "IMAGE_WITH_TEXT_CARD"]
LEAVE_REQUEST = "leave_request"
LEAVE_APPROVAL_NOTIFICATION = "leave_approval_notification"
LEAVE_AUTO_APPROVED = "leave_auto_approved"
LEAVE_REJECT = "leave_reject"
LEAVE_DELETE = "leave_delete"
LEAVE_DELETE_APPROVE = "leave_delete_approve"
LEAVE_DELETE_AUTO_APPROVE = "leave_delete_auto_approve"
LEAVE_DELETE_REJECT = "leave_delete_reject"
TEXT_CARD = "TEXT_CARD"
TASK_MODULE = "TASK_MODULE"

LEAVE_SUCCESS = "Leave requests submitted successfully"
LEAVE_CATEGORY_MAIL = "leave_categpory_mail"
EMP_ID = "emp_id"
EMP_NAME = "emp_name"
LEAVE_TYPE = "leave_type"
ABSENCE_TYPE = "absence_type"
START_DATE = "start_date"
END_DATE = "end_date"
LEAVE_REASON = "reason"
TO_MAIL_ADDRESS = "to_mail_address"
CC_MAIL_ADDRESS = "cc_mail_address"
LEAVE_REQUESTOR_ROLE = "emp_role"
EMPLOYEE_ROLE = "Employee"
MANAGER_ROLE = "Manager"
APPROVED_LEAVE_STATUS_COLOR = "#047857"
PENDING_LEAVE_STATUS_COLOR = "#F59E0B"
DELETE_APPROVED_STATUS_COLOR = "#248AF8"
DELETE_PENDING_STATUS_COLOR = "#248AF8"
DELETE_REJECT_STATUS_COLOR = "#475569"
DEAR_MSG = "Dear"
LEAVE_REQUEST_UNIQUE_ID = "leave_request_id"
LEAVE_REQUEST_TITLE="You have a new leave/regularization request!"
LEAVE_APPROVED_TITLE="Your leave/regularization request has been approved!"
LEAVE_DELETE_APPROVED_TITLE =  "Your leave/regularization request for deletion has been auto-approved!"
LEAVE_DELETE_TITLE = "You have a new delete approved leave/regularization request!"
LEAVE_REJECT_TITLE = "Your leave/regularization request has been rejected!"
LEAVE_REQUEST_CONTENT="Your team member <b> emp_name </b> has requested approval for leave &/or attendance regularization."
LEAVE_APPROVED_CONTENT="Your leave &/or attendance regularization request has been approved."
LEAVE_DELETE_APPROVED_CONTENT="Your leave &/or attendance regularization deletion request has been approved."
LEAVE_DELETE_CONTENT = "Your team member <b> emp_name </b> has requested approval to delete approved leave &/or attendance regularization."
LEAVE_REJECT_CONTENT = "Your leave &/or attendance regularization request has been rejected."
LEAVE_DELETE_SUBJECT="Delete Leave Request Notification"
LEAVE_APPROVED_SUBJECT="Leave Approval Notification"
LEAVE_REQUEST_SUBJECT=" Leave Request Notification"
LEAVE_DELETE_APPROVED_SUBJECT="Delete Leave Approval Notification"
LEAVE_REJECT_SUBJECT=" Leave Rejected Notification"

WORK_FROM_HOME = "WFH"

# LEAVE APPLICATION CONSTANTS
CASUAL_LEAVE_CODE = "L0"
SICK_LEAVE_CODE = "M0"
PRIVILEGE_LEAVE = "P0"
APPROVED_LEAVE_STATUS = '2'
ALL_LEAVE_MONTH = "All"
# ##################### KAFKA CONSTANTS END #####################


# NOTIFICATION TYPE
NUDLE_FOR_LEAVE = "Nudge for leave"
SELF_FEEDBACK_GOAL = "Self feedback goal"
SELF_FEEDBACK_LEADERSHIP_BEHAVIOR = "Self feedback leadership behavior"
MANAGER_FEEDBACK_GOAL = "Manager feedback goal"
MANAGER_FEEDBACK_LEADERSHIP_BEHAVIOR = "Manager feedback leadership behavior"
TO_DO_TASK_ADDITION = "To Do Task addition"
ANNOUNCEMENT_ADDITION = "Announcement addition"
TRANSFER_REQUEST = "Transfer request"
TRANSFER_APPROVAL = "Transfer approval"
NUDLE_FOR_FEEDBACK = "Nudge for feedback"
PUSH_FOR_FEEDBACK = "Push for feedback"

# NOTIFICATION_REASON
NUDGE_FOR_LEAVE_DESCRIPTION = "Reminder from reporting_manager to take your leaves!"
SELF_FEEDBACK_GOAL_DESCRIPTION = "You have received a feedback on your goal"
SELF_FEEDBACK_LEADERSHIP_BEHAVIOR_DESCRIPTION = "You have received a feedback on your leadership behavior"
MANAGER_FEEDBACK_GOAL_DESCRIPTION = "Feedback received on goal from <Employee Name>"
MANAGER_FEEDBACK_LEADERSHIP_BEHAVIOR_DESCRIPTION = "Feedback received on leadership behavior from <Employee Name>"
TO_DO_TASK_ADDITION_DESCRIPTION = "New task added to your task list!"
ANNOUNCEMENT_ADDITION_DESCRIPTION = "New announcement! <Announcement Title>"
TRANSFER_REQUEST_DESCRIPTION = "New transfer request received for <Employee name>!"
TRANSFER_APPROVAL_DESCRIPTION = "Your transfer request for <Employee name> has been approved"
NUDLE_FOR_FEEDBACK_DESCRIPTION = "Reminder from <Employee> to connect on performance feedbacks!"
PUSH_FOR_FEEDBACK_DESCRIPTION = "Reminder from <Reporting manager> to update your feedbacks!"

READ_TYPE_INAPP_NOTIFICATION = [
    {"key": "All", "value": "all"},
    {"key": "Read", "value": "read"},
    {"key": "Unread", "value": "unread"},
]
APPROVAL_TYPE_INAPP_NOTIFICATION = [
    {"key": "All", "value": "all"},
    {"key": "Leave", "value": "leave"},
    {"key": "Transfer", "value": "transfer"},
    {"key": "Digital Signing", "value": "digitalSigning"},
    {"key": "Delete Leave", "value": "deleteLeave"},
]
FEEDBACK_INAPP_NOTIFICATION = [
    {"key": "Goal", "value": "goal"},
    {"key": "Leadership Behaviour", "value": "leadershipBehaviour"},
]
OTHER_TYPE_INAPP_NOTIFICATION = [
    {"key": "Announcements", "value": "announcements"},
    {"key": "Marking Attendance", "value": "markingAttendance"},
]

# companty code
TMCV = "0100"
TMPVL = "0550"
TPEML = "0650"

WHITE_COLLAR = "White Collar"
BLUE_COLLAR = "Blue Collar"

# Common response
STATUS_CODE = "status_code"
DATA = "data"

# Exceptional paths for Blue Collar
BLUE_COLLAR_PATHS = ['']
REPORTEE_ID = ['emp_id', 'comp_code']
ATTENDANCE_ENQUIRY = ['emp_id','from_date','to_date','date_of_joining']

SUCCESS_STATUS_CODE=200
ERROR_STATUS_CODE=500
STATUS_CODE_419 = 419
STATUS_CODE_401 = 401
STATUS_CODE_403 = 403
STATUS_CODE_404 = 404

PL_LEAVE_QUOTA = "40"
SL_LEAVE_QUOTA = "50"
CL_LEAVE_QUOTA = "30"

CL_QUOTA = "cl_quota"
PL_QUOTA = "pl_quota"
SL_QUOTA = "sl_quota"

CL_QUOTA_AVAILED = "cl_quota_availed"
PL_QUOTA_AVAILED = "pl_quota_availed"
SL_QUOTA_AVAILED = "sl_quota_availed"

EMPLOYEE_NAME = "employee_name"
EMPLOYEE_ID = "employee_id"
LEAVE_MAIL = """
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Happy Birthday!</title>
    <style>
        * {
            margin: 0;
            padding: 0;
        }

        .body {
            width: 100%;
            height: 100%;
            background: #F0F0F0;
            font-family: 'Times New Roman', Times, serif;
        }

        .bg {
            background: #F0F0F0;
        }

        .wishes {
            font-size: 40px;
            color: #1A83CF;
            font-family: 'Times New Roman', Times, serif;
        }

        .cakeimg {
            height: 50vh;
        }

        .content {
            font-size: 18px;
            color: #000000;
        }

        .uptdleft {
            background: #512C92;
            border-top-left-radius: 24px;
            width: 5%;
        }

        .uptdright {
            background: #512C92;
            border-top-right-radius: 24px;
            width: 5%;
        }

        .downtdleft {
            background: #512C92;
            border-bottom-left-radius: 24px;
            width: 5%;
        }

        .downtdright {
            background: #512C92;
            border-bottom-right-radius: 24px;
            width: 5%;
        }

        .alignstart {
            align-items: start;
            background: #512C92;
        }

        .alignend {
            align-items: end;
            background: #512C92;
        }

        .headfootheight {
            height: 80px;
        }

        .header1 {
            height: 16px;
            ;
            border: 0;
            display: block;
            width: 90px;
        }

        .header2 {
            height: 20px;
            border: 0;
            display: block;
            width: 90px;
        }

        .footer {
            height: 38px;
            border: 0;
            display: block;
            width: 90px;
        }
    </style>
</head>

<body>
    <table class="body" cellspacing="0" cellpadding="0">
        <tr class="headfootheight">
            <td class="uptdleft">
                &nbsp;
            </td>
            <td class="alignstart">
                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                    <tr>

                        <td>
                            <div align="left">

                                <img src=https://di0zifa10d7yc.cloudfront.net/EDP/TML/image/drishti_log.png
                                    class="header1"></img>
                            </div>
                        </td>
                    </tr>
                </table>
            </td>
            <td class="alignend">
                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                    <tr>
                        <td>
                            <div align="right">
                                <img src=https://di0zifa10d7yc.cloudfront.net/EDP/TML/leaveMailPicture/tata_motor_logo.png
                                    class="header2"></img>

                            </div>

                    </tr>

                </table>
            </td>
            <td class="uptdright">
                &nbsp;
            </td>
        </tr>
        <tr>
            <td colspan="4" class="bg">&nbsp;</td>
        </tr>
        <tr>
            <td align="center" colspan="4" class="bg">
                <span class="wishes">Happy
                    Birthday</span><br>
                <span class="wishes"><strong>Ruchika!</strong></span>
            </td>
        </tr>
        <tr>
            <td colspan="4" class="bg">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="4" class="bg">&nbsp;</td>
        </tr>
        <tr align="center">

            <td colspan="4">
                <span><img class="cakeimg"
                        src="https://di0zifa10d7yc.cloudfront.net/EDP/TML/birthday/birthday.png"></span>
            </td>
        </tr>
        <tr>
            <td colspan="4" class="bg">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="4" class="bg">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="4" class="bg">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="4" class="bg">&nbsp;</td>
        </tr>
        <tr align="center">
            <td colspan="4">
                <span class="content">With each passing year, you are achieving greater heights. We are so grateful to
                    have a family member like you, dedicated, hard-working,innovative, hustler, winner.</span>
            </td>
        </tr>
        <tr>
            <td colspan="4" class="bg">&nbsp;</td>
        </tr>
        <tr align="center">
            <td>&nbsp;</td>
            <td colspan="2">
                <span class="content">We want you to grow and be a better version of yourself than yesterday.</span>
                <span class="content"> Happy Birthday!</span>
            </td>
        </tr>
        <tr>
            <td colspan="4" class="bg">&nbsp;</td>
        </tr>
        <tr align="center">
            <td>&nbsp;</td>
            <td colspan="4">
                <span class="content"><strong>From</strong></span>
            </td>
        </tr>
        <tr align="center">
            <td>&nbsp;</td>
            <td colspan="4">
                <span class="content"><strong>TATA Motors Family</strong></span>
            </td>
        </tr>
        <tr align="center">
            <!-- <td>&nbsp;</td> -->
            <td colspan="4">
                <table style="text-align:center; justify-content: center; width: 100%; border-collapse: collapse; ">
                    <tr>
                        <th style="border: 1px solid gray; padding: 8px; text-align: left; ">Name</th>
                        <th style="border: 1px solid gray; padding: 8px; text-align: left;  ">Goal/Leadership Behavior
                        </th>
                        <th style="border: 1px solid gray; padding: 8px; text-align: left; ">Goal Title/Leadership
                            Behavior
                            Title</th>
                        <th style="border: 1px solid gray; padding: 8px; text-align: left; ">Feedback</th>
                    </tr>
                    <!-- employee_goals
                    employee_competency -->
                </table>

                <table border="0" cellpadding="0" cellspacing="0" class="row row-3" role="presentation"
                    style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
                    <tbody>
                        <tr>
                            <td>
                                <table border="0" cellpadding="0" cellspacing="0" class="row-content"
                                    role="presentation"
                                    style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; border-radius: 0; width: 100%;"
                                    width="100%">
                                    <tbody>
                                        <tr>
                                            <td class="column column-1"
                                                style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;"
                                                width="25%">
                                                <table border="0" cellpadding="0" cellspacing="0"
                                                    class="html_block block-2" role="presentation"
                                                    style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
                                                    <tr>
                                                        <td class="pad" style="padding-top:5px;padding-bottom:5px;">
                                                            <div
                                                                style="font-family:'Signika', sans-serif;text-align:start;">
                                                                <div
                                                                    style="border-radius: 8px; margin: 10px; border: 0.1px solid #EAEAEA; font-family: 'Signika', sans-serif;padding-top: 10px;padding-bottom: 5px;">
                                                                    <span
                                                                        style=" font-family: 'Signika', sans-serif;font-size: 12px;color: #3B3B3B;">&nbsp;&nbsp;&nbsp;&nbsp;Name
                                                                    </span>
                                                                    <br><br>
                                                                    <table border="0" cellspacing="0" cellpadding="0">
                                                                        <tr>
                                                                            <td>&nbsp;&nbsp;</td>
                                                                            <td><span
                                                                                    style="color: rgba(59, 59, 59, 1);font-family:'Signika', sans-serif;font-weight: Bold;">
                                                                                    #A0000- Ahmadabad Samand </span>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                            <td class="column column-1"
                                                style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;"
                                                width="25%">
                                                <table border="0" cellpadding="0" cellspacing="0"
                                                    class="html_block block-2" role="presentation"
                                                    style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
                                                    <tr>
                                                        <td class="pad" style="padding-top:5px;padding-bottom:5px;">
                                                            <div
                                                                style="font-family:'Signika', sans-serif;text-align:start;">
                                                                <div
                                                                    style="border-radius: 8px; margin: 10px; border: 0.1px solid #EAEAEA; font-family: 'Signika', sans-serif;padding-top: 10px;padding-bottom: 5px;">
                                                                    <span
                                                                        style=" font-family: 'Signika', sans-serif;font-size: 12px;color: #3B3B3B;">&nbsp;&nbsp;&nbsp;&nbsp;Goal/Leadership
                                                                        Behavior
                                                                    </span>
                                                                    <br><br>
                                                                    <table border="0" cellspacing="0" cellpadding="0">
                                                                        <tr>
                                                                            <td>&nbsp;&nbsp;</td>
                                                                            <td><span
                                                                                    style="color: rgba(59, 59, 59, 1);font-family:'Signika', sans-serif;font-weight: Bold;">
                                                                                    #A0000- Ahmadabad Samand </span>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                            <td class="column column-1"
                                                style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;"
                                                width="25%">
                                                <table border="0" cellpadding="0" cellspacing="0"
                                                    class="html_block block-2" role="presentation"
                                                    style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
                                                    <tr>
                                                        <td class="pad" style="padding-top:5px;padding-bottom:5px;">
                                                            <div
                                                                style="font-family:'Signika', sans-serif;text-align:start;">
                                                                <div
                                                                    style="border-radius: 8px; margin: 10px; border: 0.1px solid #EAEAEA; font-family: 'Signika', sans-serif;padding-top: 10px;padding-bottom: 5px;">
                                                                    <span
                                                                        style=" font-family: 'Signika', sans-serif;font-size: 12px;color: #3B3B3B;">&nbsp;&nbsp;&nbsp;&nbsp;Goal
                                                                        Title/Leadership Behavior Title
                                                                    </span>
                                                                    <br><br>
                                                                    <table border="0" cellspacing="0" cellpadding="0">
                                                                        <tr>
                                                                            <td>&nbsp;&nbsp;</td>
                                                                            <td><span
                                                                                    style="color: rgba(59, 59, 59, 1);font-family:'Signika', sans-serif;font-weight: Bold;">
                                                                                    #A0000- Ahmadabad Samand </span>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                            <td class="column column-2"
                                                style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;"
                                                width="25%">
                                                <table border="0" cellpadding="0" cellspacing="0"
                                                    class="html_block block-2" role="presentation"
                                                    style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
                                                    <tr>
                                                        <td class="pad" style="padding-top:5px;padding-bottom:5px;">
                                                            <div
                                                                style="font-family:'Signika', sans-serif;text-align:start;">
                                                                <div
                                                                    style="border-radius: 8px; margin: 10px; border: 0.1px solid #EAEAEA;font-family:'Signika', sans-serif;padding-top: 10px;padding-bottom: 5px;">
                                                                    <span
                                                                        style=" font-family:'Signika', sans-serif;font-size: 12px;color: #3B3B3B;">&nbsp;&nbsp;&nbsp;&nbsp;Feedback
                                                                    </span><br /><br />
                                                                    <table border="0" cellpadding="0" cellspacing="0">
                                                                        <tr>
                                                                            <td>&nbsp;&nbsp;</td>
                                                                            <td><span
                                                                                    style="color: rgba(59, 59, 59, 1);font-family:'Signika', sans-serif;font-weight: Bold;">
                                                                                    Dharwad Works </span>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
        <tr>
            <td colspan="4" class="bg">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="4" class="bg">&nbsp;</td>
        </tr>
        <tr class="headfootheight">
            <td class="downtdleft">
                &nbsp;
            </td>
            <td class="alignstart">
                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                    <tr>
                        <td>
                            <div align="left">
                            </div>
                        </td>
                    </tr>
                </table>
            </td>
            <td class="alignend">
                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                    <tr>

                        <td>
                            <div align="right">
                                <img src=https://di0zifa10d7yc.cloudfront.net/EDP/TML/leaveMailPicture/header_logo.png
                                    class="footer"></img>

                            </div>
                        </td>
                    </tr>

                </table>
            </td>
            <td class="downtdright">
                &nbsp;
            </td>
        </tr>
    </table>
</body>

</html>
"""


# LEAVE_MAIL = """
# <!DOCTYPE html>

# <html lang="en" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:v="urn:schemas-microsoft-com:vml">

# <head>
# 	<title></title>
# 	<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
# 	<meta content="width=device-width, initial-scale=1.0" name="viewport" />
# 	<!--[if mso]><xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch><o:AllowPNG/></o:OfficeDocumentSettings></xml><![endif]-->
# 	<!--[if !mso]><!-->
# 	<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css" />
# 	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet" type="text/css" />
# 	<!--<![endif]-->
# 	<style>
# 		* {
# 			box-sizing: border-box;
# 		}

# 		body {
# 			margin: 0;
# 			padding: 0;
# 		}

# 		a[x-apple-data-detectors] {
# 			color: inherit !important;
# 			text-decoration: inherit !important;
# 		}

# 		#MessageViewBody a {
# 			color: inherit;
# 			text-decoration: none;
# 		}

# 		p {
# 			line-height: inherit
# 		}

# 		.desktop_hide,
# 		.desktop_hide table {
# 			mso-hide: all;
# 			display: none;
# 			max-height: 0px;
# 			overflow: hidden;
# 		}

# 		@media (max-width:620px) {

# 			.desktop_hide table.icons-inner,
# 			.row-1 .column-2 .block-2.image_block img {
# 				display: inline-block !important;
# 			}

# 			.icons-inner {
# 				text-align: center;
# 			}

# 			.icons-inner td {
# 				margin: 0 auto;
# 			}

# 			.row-content {
# 				width: 100% !important;
# 			}

# 			.mobile_hide {
# 				display: none;
# 			}

# 			.stack .column {
# 				width: 100%;
# 				display: block;
# 			}

# 			.mobile_hide {
# 				min-height: 0;
# 				max-height: 0;
# 				max-width: 0;
# 				overflow: hidden;
# 				font-size: 0px;
# 			}

# 			.desktop_hide,
# 			.desktop_hide table {
# 				display: table !important;
# 				max-height: none !important;
# 			}

# 			.row-2 .column-1 .block-2.paragraph_block td.pad>div,
# 			.row-2 .column-1 .block-6.paragraph_block td.pad>div {
# 				text-align: center !important;
# 			}

# 			.row-1 .column-2 .block-2.image_block .alignment {
# 				text-align: right !important;
# 			}

# 			.row-1 .column-1 .block-2.heading_block h1 {
# 				font-size: 19px !important;
# 			}

# 			.row-7 .column-1 .block-2.paragraph_block td.pad>div {
# 				text-align: center !important;
# 				font-size: 13px !important;
# 			}

# 			.row-1 .column-1 {
# 				padding: 25px !important;
# 			}

# 			.row-8 .column-1 {
# 				padding: 0 0 5px !important;
# 			}
# 		}
# 	</style>
# </head>

# <body style="background-color: #f7f7f7; margin: 0; padding: 0; -webkit-text-size-adjust: none; text-size-adjust: none;">
# 	<table border="0" cellpadding="0" cellspacing="0" class="nl-container" role="presentation"
# 		style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #f7f7f7;" width="100%">
# 		<tbody>
# 			<tr>
# 				<td>
# 					<table align="center" border="0" cellpadding="0" cellspacing="0" class="row row-1"
# 						role="presentation"
# 						style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #6f42c1;" width="100%">
# 						<tbody>
# 							<tr>
# 								<td>
# 									<table align="center" border="0" cellpadding="0" cellspacing="0" class="row-content"
# 										role="presentation"
# 										style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; border-radius: 0; width: 600px;"
# 										width="600">
# 										<tbody>
# 											<tr>
# 												<td class="column column-1"
# 													style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; padding-left: 40px; padding-right: 40px; vertical-align: middle; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;"
# 													width="50%">
# 													<table border="0" cellpadding="0" cellspacing="0"
# 														class="heading_block block-2" role="presentation"
# 														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"
# 														width="100%">
# 														<tr>
# 															<td class="pad"
# 																style="width:100%;text-align:center;padding-top:40px;padding-bottom:40px;">
# 																<h1
# 																	style="margin: 0; color: #f8f8f8; font-size: 24px; font-family: TimesNewRoman, 'Times New Roman', Times, Beskerville, Georgia, serif; line-height: 120%; text-align: left; direction: ltr; font-weight: 700; letter-spacing: normal; margin-top: 0; margin-bottom: 0;">
# 																	<span class="tinyMce-placeholder">DRISHTI 2.0</span>
# 																</h1>
# 															</td>
# 														</tr>
# 													</table>
# 												</td>
# 												<td class="column column-2"
# 													style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: middle; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;"
# 													width="50%">
# 													<table border="0" cellpadding="0" cellspacing="0"
# 														class="image_block block-2" role="presentation"
# 														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"
# 														width="100%">
# 														<tr>
# 															<td class="pad"
# 																style="width:100%;padding-right:0px;padding-left:0px;padding-top:5px;padding-bottom:5px;">
# 																<div align="right" class="alignment"
# 																	style="line-height:10px"><img
# 																		src="https://di0zifa10d7yc.cloudfront.net/EDP/TML/leaveMailPicture/header_logo.png"
# 																		style="display: block; height: auto; border: 0; width: 120px; max-width: 100%;"
# 																		width="120" /></div>
# 															</td>
# 														</tr>
# 													</table>
# 												</td>
# 											</tr>
# 										</tbody>
# 									</table>
# 								</td>
# 							</tr>
# 						</tbody>
# 					</table>
# 					<table align="center" border="0" cellpadding="0" cellspacing="0" class="row row-2"
# 						role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
# 						<tbody>
# 							<tr>
# 								<td>
# 									<table align="center" border="0" cellpadding="0" cellspacing="0"
# 										class="row-content stack" role="presentation"
# 										style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; border-radius: 0; width: 600px;"
# 										width="600">
# 										<tbody>
# 											<tr>
# 												<td class="column column-1"
# 													style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; padding-top: 5px; padding-bottom: 5px; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;"
# 													width="100%">
# 													<table border="0" cellpadding="0" cellspacing="0"
# 														class="paragraph_block block-2" role="presentation"
# 														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; word-break: break-word;"
# 														width="100%">
# 														<tr>
# 															<td class="pad" style="padding-top:50px;">
# 																<div
# 																	style="color:#8a3c90;font-size:16px;font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;font-weight:400;line-height:120%;text-align:center;direction:ltr;letter-spacing:0px;mso-line-height-alt:19.2px;">
# 																	<p style="margin: 0;"><strong>You have a new
# 																			leave/regulatisation request !</strong></p>
# 																</div>
# 															</td>
# 														</tr>
# 													</table>
# 													<table border="0" cellpadding="0" cellspacing="0"
# 														class="image_block block-4" role="presentation"
# 														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"
# 														width="100%">
# 														<tr>
# 															<td class="pad"
# 																style="width:100%;padding-right:0px;padding-left:0px;padding-top:50px;">
# 																<div align="center" class="alignment"
# 																	style="line-height:10px"><img
# 																		src="https://di0zifa10d7yc.cloudfront.net/EDP/TML/leaveMailPicture/leave_request.png"
# 																		style="display: block; height: auto; border: 0; width: 210px; max-width: 100%;"
# 																		width="210" /></div>
# 															</td>
# 														</tr>
# 													</table>
# 													<table border="0" cellpadding="0" cellspacing="0"
# 														class="paragraph_block block-6" role="presentation"
# 														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; word-break: break-word;"
# 														width="100%">
# 														<tr>
# 															<td class="pad" style="padding-top:60px;">
# 																<div
# 																	style="color:#101112;font-size:16px;font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;font-weight:400;line-height:120%;text-align:left;direction:ltr;letter-spacing:0px;mso-line-height-alt:19.2px;">
# 																	<p style="margin: 0; margin-bottom: 16px;">Dear
# 																		Manager - emp_name ,</p>
# 																	<p style="margin: 0; margin-bottom: 16px;">Your team
# 																		member <strong>emp_name </strong>has requested
# 																		approval for leave &/or attendance
# 																		regularization.</p>
# 																	<p style="margin: 0;">Details are as below-</p>
# 																</div>
# 															</td>
# 														</tr>
# 													</table>
# 												</td>
# 											</tr>
# 										</tbody>
# 									</table>
# 								</td>
# 							</tr>
# 						</tbody>
# 					</table>
# 					<table align="center" border="0" cellpadding="0" cellspacing="0" class="row row-3"
# 						role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
# 						<tbody>
# 							<tr>
# 								<td>
# 									<table align="center" border="0" cellpadding="0" cellspacing="0" class="row-content"
# 										role="presentation"
# 										style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; border-radius: 0; width: 600px;"
# 										width="600">
# 										<tbody>
# 											<tr>
# 												<td class="column column-1"
# 													style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;"
# 													width="50%">
# 													<table border="0" cellpadding="0" cellspacing="0"
# 														class="html_block block-2" role="presentation"
# 														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"
# 														width="100%">
# 														<tr>
# 															<td class="pad" style="padding-top:5px;padding-bottom:5px;">
# 																<div align="center"
# 																	style="font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;text-align:center;">
# 																	<div
# 																		style="border-radius: 8px; margin: 10px; border: 0.1px solid #EAEAEA; font-family: Uni Neue;padding-top: 10px;padding-bottom: 5px;">
# 																		<span
# 																			style=" font-family: Uni Neue;font-size: 12px;color: #3B3B3B;">Employee
# 																			Name</span><br /><br />
# 																		<span
# 																			style="color: rgba(59, 59, 59, 1);font-family: Uni Neue;font-weight: Bold;">emp_name</span>
# 																	</div>
# 																</div>
# 															</td>
# 														</tr>
# 													</table>
# 												</td>
# 												<td class="column column-2"
# 													style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;"
# 													width="50%">
# 													<table border="0" cellpadding="0" cellspacing="0"
# 														class="html_block block-2" role="presentation"
# 														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"
# 														width="100%">
# 														<tr>
# 															<td class="pad" style="padding-top:5px;padding-bottom:5px;">
# 																<div align="center"
# 																	style="font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;text-align:center;">
# 																	<div
# 																		style="border-radius: 8px; margin: 10px; border: 0.1px solid #EAEAEA;font-family: Uni Neue;padding-top: 10px;">
# 																		<span
# 																			style=" font-family: Uni Neue;font-size: 12px;margin-left: 10px;color: #3B3B3B;">Employee
# 																			ID</span><br /><br />
# 																		<div> <span
# 																				style="color: rgba(59, 59, 59, 1);font-family: Uni Neue;font-weight: Bold;">emp_id
# 																			</span></div>
# 																	</div>
# 																</div>
# 															</td>
# 														</tr>
# 													</table>
# 												</td>
# 											</tr>
# 										</tbody>
# 									</table>
# 								</td>
# 							</tr>
# 						</tbody>
# 					</table>
# 					<table align="center" border="0" cellpadding="0" cellspacing="0" class="row row-4"
# 						role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
# 						<tbody>
# 							<tr>
# 								<td>
# 									<table align="center" border="0" cellpadding="0" cellspacing="0" class="row-content"
# 										role="presentation"
# 										style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; border-radius: 0; width: 600px;"
# 										width="600">
# 										<tbody>
# 											<tr>
# 												<td class="column column-1"
# 													style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;"
# 													width="50%">
# 													<table border="0" cellpadding="0" cellspacing="0"
# 														class="html_block block-2" role="presentation"
# 														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"
# 														width="100%">
# 														<tr>
# 															<td class="pad" style="padding-top:5px;padding-bottom:5px;">
# 																<div align="center"
# 																	style="font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;text-align:center;">
# 																	<div
# 																		style="border-radius: 8px; margin: 10px; border: 0.1px solid #EAEAEA; font-family: Uni Neue;padding-top: 10px;padding-bottom: 5px;">
# 																		<span
# 																			style=" font-family: Uni Neue;font-size: 12px;color: #3B3B3B;">Absence
# 																			Type</span><br /><br />
# 																		<span
# 																			style="color: rgba(59, 59, 59, 1);font-family: Uni Neue;font-weight: Bold;">absence_type</span>
# 																	</div>
# 																</div>
# 															</td>
# 														</tr>
# 													</table>
# 												</td>
# 												<td class="column column-2"
# 													style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;"
# 													width="50%">
# 													<table border="0" cellpadding="0" cellspacing="0"
# 														class="html_block block-2" role="presentation"
# 														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"
# 														width="100%">
# 														<tr>
# 															<td class="pad" style="padding-top:5px;padding-bottom:5px;">
# 																<div align="center"
# 																	style="font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;text-align:center;">
# 																	<div
# 																		style="border-radius: 8px; margin: 10px; border: 0.1px solid #EAEAEA;font-family: Uni Neue;padding-top: 10px;">
# 																		<span
# 																			style=" font-family: Uni Neue;font-size: 12px;color: #3B3B3B;">Leave
# 																			Type</span><br /><br />
# 																		<div> <span
# 																				style="color: rgba(59, 59, 59, 1);font-family: Uni Neue;font-weight: Bold;">leave_type
# 																			</span></div>
# 																	</div>
# 																</div>
# 															</td>
# 														</tr>
# 													</table>
# 												</td>
# 											</tr>
# 										</tbody>
# 									</table>
# 								</td>
# 							</tr>
# 						</tbody>
# 					</table>
# 					<table align="center" border="0" cellpadding="0" cellspacing="0" class="row row-5"
# 						role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
# 						<tbody>
# 							<tr>
# 								<td>
# 									<table align="center" border="0" cellpadding="0" cellspacing="0" class="row-content"
# 										role="presentation"
# 										style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; border-radius: 0; width: 600px;"
# 										width="600">
# 										<tbody>
# 											<tr>
# 												<td class="column column-1"
# 													style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;"
# 													width="50%">
# 													<table border="0" cellpadding="0" cellspacing="0"
# 														class="html_block block-2" role="presentation"
# 														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"
# 														width="100%">
# 														<tr>
# 															<td class="pad" style="padding-top:5px;padding-bottom:5px;">
# 																<div align="center"
# 																	style="font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;text-align:center;">
# 																	<div
# 																		style="border-radius: 8px; margin: 10px; border: 0.1px solid #EAEAEA; font-family: Uni Neue;padding-top: 10px;padding-bottom: 5px;">
# 																		<span
# 																			style=" font-family: Uni Neue;font-size: 12px;color: #3B3B3B;">Start
# 																			Date</span><br /><br />
# 																		<span
# 																			style="color: rgba(59, 59, 59, 1);font-family: Uni Neue;font-weight: Bold;">start_date</span>
# 																	</div>
# 																</div>
# 															</td>
# 														</tr>
# 													</table>
# 												</td>
# 												<td class="column column-2"
# 													style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;"
# 													width="50%">
# 													<table border="0" cellpadding="0" cellspacing="0"
# 														class="html_block block-2" role="presentation"
# 														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"
# 														width="100%">
# 														<tr>
# 															<td class="pad" style="padding-top:5px;padding-bottom:5px;">
# 																<div align="center"
# 																	style="font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;text-align:center;">
# 																	<div
# 																		style="border-radius: 8px; margin:10px; border: 0.1px solid #EAEAEA;font-family: Uni Neue;padding-top: 10px;padding-bottom: 5px;">
# 																		<span
# 																			style=" font-family: Uni Neue;font-size: 12px;color: #3B3B3B;">End
# 																			Date</span><br /><br />
# 																		<span
# 																			style="color: rgba(59, 59, 59, 1);font-family: Uni Neue;font-weight: Bold;">end_date</span>
# 																	</div>
# 																</div>
# 															</td>
# 														</tr>
# 													</table>
# 												</td>
# 											</tr>
# 										</tbody>
# 									</table>
# 								</td>
# 							</tr>
# 						</tbody>
# 					</table>
# 					<table align="center" border="0" cellpadding="0" cellspacing="0" class="row row-6"
# 						role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
# 						<tbody>
# 							<tr>
# 								<td>
# 									<table align="center" border="0" cellpadding="0" cellspacing="0"
# 										class="row-content stack" role="presentation"
# 										style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; border-radius: 0; width: 600px;"
# 										width="600">
# 										<tbody>
# 											<tr>
# 												<td class="column column-1"
# 													style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; padding-top: 5px; padding-bottom: 5px; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;"
# 													width="100%">
# 													<table border="0" cellpadding="0" cellspacing="0"
# 														class="html_block block-1" role="presentation"
# 														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"
# 														width="100%">
# 														<tr>
# 															<td class="pad">
# 																<div align="center"
# 																	style="font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;text-align:center;">
# 																	<div
# 																		style="border-radius: 8px; margin: 10px; border: 0.1px solid #EAEAEA; font-family: Uni Neue;padding-top: 10px;padding-bottom: 5px;">
# 																		<span
# 																			style=" font-family: Uni Neue;font-size: 12px;color: #3B3B3B;">Reason
# 																			For Leave</span><br /><br />
# 																		<span
# 																			style="color: rgba(59, 59, 59, 1);font-family: Uni Neue;font-weight: Bold;">leave_reason</span>
# 																	</div>
# 																</div>
# 															</td>
# 														</tr>
# 													</table>
# 												</td>
# 											</tr>
# 										</tbody>
# 									</table>
# 								</td>
# 							</tr>
# 						</tbody>
# 					</table>
# 					<table align="center" border="0" cellpadding="0" cellspacing="0" class="row row-7"
# 						role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;" width="100%">
# 						<tbody>
# 							<tr>
# 								<td>
# 									<table align="center" border="0" cellpadding="0" cellspacing="0"
# 										class="row-content stack" role="presentation"
# 										style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; border-radius: 0; width: 600px;"
# 										width="600">
# 										<tbody>
# 											<tr>
# 												<td class="column column-1"
# 													style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; padding-top: 5px; padding-bottom: 5px; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;"
# 													width="100%">
# 													<table border="0" cellpadding="0" cellspacing="0"
# 														class="paragraph_block block-2" role="presentation"
# 														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; word-break: break-word;"
# 														width="100%">
# 														<tr>
# 															<td class="pad" style="padding-top:50px;">
# 																<div
# 																	style="color:#101112;font-size:16px;font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;font-weight:400;line-height:120%;text-align:left;direction:ltr;letter-spacing:0px;mso-line-height-alt:19.2px;">
# 																	<p style="margin: 0; margin-bottom: 16px;">Regards,
# 																	</p>
# 																	<p style="margin: 0; margin-bottom: 16px;">
# 																		<strong>Team Drishti</strong></p>
# 																	<p style="margin: 0;"><strong>P.S.</strong> This is
# 																		a system generated mail, please do not reply.
# 																	</p>
# 																</div>
# 															</td>
# 														</tr>
# 													</table>
# 												</td>
# 											</tr>
# 										</tbody>
# 									</table>
# 								</td>
# 							</tr>
# 						</tbody>
# 					</table>
# 					<table align="center" border="0" cellpadding="0" cellspacing="0" class="row row-8"
# 						role="presentation"
# 						style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #f59e0b;" width="100%">
# 						<tbody>
# 							<tr>
# 								<td>
# 									<table align="center" border="0" cellpadding="0" cellspacing="0"
# 										class="row-content stack" role="presentation"
# 										style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; border-radius: 0; width: 600px;"
# 										width="600">
# 										<tbody>
# 											<tr>
# 												<td class="column column-1"
# 													style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; padding-top: 5px; padding-bottom: 5px; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;"
# 													width="100%">
# 													<table border="0" cellpadding="0" cellspacing="0"
# 														class="html_block block-1" role="presentation"
# 														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"
# 														width="100%">
# 														<tr>
# 															<td class="pad">
# 																<div align="center"
# 																	style="font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;text-align:center;">
# 																	<div
# 																		style=" height: 10px;width: 100%;background-color: #F59E0B">
# 																	</div>
# 																</div>
# 															</td>
# 														</tr>
# 													</table>
# 												</td>
# 											</tr>
# 										</tbody>
# 									</table>
# 								</td>
# 							</tr>
# 						</tbody>
# 					</table>
# 					<table align="center" border="0" cellpadding="0" cellspacing="0" class="row row-9"
# 						role="presentation"
# 						style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #6f42c1;" width="100%">
# 						<tbody>
# 							<tr>
# 								<td>
# 									<table align="center" border="0" cellpadding="0" cellspacing="0" class="row-content"
# 										role="presentation"
# 										style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; color: #000000; border-radius: 0; width: 600px;"
# 										width="600">
# 										<tbody>
# 											<tr>
# 												<td class="column column-1"
# 													style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;"
# 													width="66.66666666666667%">
# 													<table border="0" cellpadding="0" cellspacing="0"
# 														class="html_block block-2" role="presentation"
# 														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"
# 														width="100%">
# 														<tr>
# 															<td class="pad" style="padding-top:5px;padding-bottom:5px;">
# 																<div align="center"
# 																	style="font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;text-align:center;">
# 																	<div class="our-class"></div>
# 																</div>
# 															</td>
# 														</tr>
# 													</table>
# 												</td>
# 												<td class="column column-2"
# 													style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; font-weight: 400; text-align: left; vertical-align: top; border-top: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px;"
# 													width="33.333333333333336%">
# 													<table border="0" cellpadding="0" cellspacing="0"
# 														class="image_block block-2" role="presentation"
# 														style="mso-table-lspace: 0pt; mso-table-rspace: 0pt;"
# 														width="100%">
# 														<tr>
# 															<td class="pad"
# 																style="width:100%;padding-right:0px;padding-left:0px;padding-top:5px;padding-bottom:5px;">
# 																<div align="center" class="alignment"
# 																	style="line-height:10px"><img
# 																		src="https://di0zifa10d7yc.cloudfront.net/EDP/TML/leaveMailPicture/header_logo.png"
# 																		style="display: block; height: auto; border: 0; width: 177px; max-width: 100%;"
# 																		width="177" /></div>
# 															</td>
# 														</tr>
# 													</table>
# 												</td>
# 											</tr>
# 										</tbody>
# 									</table>
# 								</td>
# 							</tr>
# 						</tbody>
# 					</table>
# 				</td>
# 			</tr>
# 		</tbody>
# 	</table><!-- End -->
# </body>

# </html>
# """

TEMP_IMAGE = """
<tr align="center" style="background: transparent;">
     <td colspan="3">
        <span style="position:absolute;background-color: #F0F0F0">
        <img src="https://di0zifa10d7yc.cloudfront.net/EDP/TML/leaveMailPicture/custom_anniversary.png" style="background-color: transparent;">
        <p style="font-size:90px; position:absolute; top:10%; left:42%; color: #4D4D80"> 10 </p>
    </span></td>
</tr>
"""

VIKAS_LEAVE_SANITY = """
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Signika&display=swap" rel="stylesheet">
    <title>Happy Birthday!</title>
    <style>
        .body {
            width: 100%;
            height: 100%;
            background: #F0F0F0;
            font-family: 'Signika', sans-serif;
        }

        .bg {
            background: #F0F0F0;
        }

        .wid-100 {
            width: 100%;
        }

        .wishes {
            font-size: 40px;
            color: #512C92;
            font-family: 'Signika', sans-serif;
        }

        .cakeimg {
           
            position: absolute;
            left: 20px;
            top: 0px;
            z-index: 1;
        }

        .content {
            font-size: 18px;
            color: #000000;
        }

        .uptdleft {
            background: #6f42c1;
            border-top-left-radius: 24px;
            width: 1%;
        }

        .uptdright {
            background: #6f42c1;
            border-top-right-radius: 24px;
            width: 2%;
        }

        .downtdleft {
            background: #6f42c1;
            border-bottom-left-radius: 24px;
            width: 1%;
        }

        .downtdright {
            background: #6f42c1;
            border-bottom-right-radius: 24px;
            width: 2%;
        }

        .alignstart {
            align-items: start;
            background: #6f42c1;
        }

        .alignend {
            align-items: end;
            background: #6f42c1;
        }
    </style>
</head>

<body>
    <table class="body" cellspacing="0" cellpadding="0">
        <tr style="height: 80px;">
            <td class="uptdleft">
                &nbsp;
            </td>
            <td class="alignstart">
                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                    <tr>
                        <td>
                            &nbsp;
                        </td>
                        <td>
                            <div align="left">
                                <img src=https://di0zifa10d7yc.cloudfront.net/EDP/TML/leaveMailPicture/drishti_200px.png
                                    style="display: block; height: 15px; border: 0;"></img>
                            </div>
                        </td>
                    </tr>
                </table>
            </td>

            <td class="alignend">
                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                    <tr>
                        <td>
                            <div align="right">
                                <img src=https://di0zifa10d7yc.cloudfront.net/EDP/TML/leaveMailPicture/tata_motor_logo.png
                                    style="display: block; height: 30px; border: 0;"></img>

                            </div>

                    </tr>

                </table>
            </td>
            <td class="uptdright">
                &nbsp;
            </td>
        </tr>
        <tr>
            <td colspan="3" class="bg">&nbsp;</td>
        </tr>
        <tr>
            <td align="center" colspan="3" class="bg">
                <span class="wishes" style="font-size:30px;">Happy
                    Work Anniversary</span><br>
                <span class="wishes"><strong>Vikas Tomar</strong></span>
            </td>
        </tr>
        <tr>
            <td colspan="3" class="bg">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="3" class="bg">&nbsp;</td>
        </tr>
        <tr align="center">
            <td colspan="3">
                <span style="position: relative;">
                    <img style ="width: 372px; height: 236px;"src=center_image>
                </span>
            </td>
        </tr>
        <tr>
            <td colspan="3" class="bg">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="3" class="bg">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="3" class="bg">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="3" class="bg">&nbsp;</td>
        </tr>


        <tr align="center">
            <td colspan="3">
                <span class="content">Here’s wishing the happiest of work anniversary to someone who’s more than just a
                    committed employee,
                    but also a cherished member of our team.</span>
            </td>
        </tr>
        <tr>
            <td colspan="3" class="bg">&nbsp;</td>
        </tr>
        <tr align="center">
            <td>&nbsp;</td>
            <td colspan="3">
                <span class="content">Congratulations on your work anniversary this year. Thank you for your hard work
                    and dedication as a valued person at the organisation.</span>
                <span class="content"> HAPPY ANNIVERSARY! </span>
            </td>
        </tr>
        <tr>
            <td colspan="3" class="bg">&nbsp;</td>
        </tr>
        <tr align="center">
            <td>&nbsp;</td>
            <td colspan="3">
                <span class="content"><strong>From</strong></span>
            </td>
        </tr>
        <tr align="center">
            <td>&nbsp;</td>
            <td colspan="3">
                <span class="content"><strong>TATA Motors Family</strong></span>
            </td>
        </tr>
        <tr>
            <td colspan="3" class="bg">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="3" class="bg">&nbsp;</td>
        </tr>

        <tr style="height: 80px;">
            <td class="downtdleft">
                &nbsp;
            </td>
            <td class="alignstart">
                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                    <tr>
                        <td>
                            <div align="left">
                            </div>
                        </td>
                    </tr>
                </table>
            </td>

            <td class="alignend">
                <table border="0" cellpadding="0" cellspacing="0" width="100%">
                    <tr>

                        <td>
                            <div align="right">
                                <img src=https://di0zifa10d7yc.cloudfront.net/EDP/TML/leaveMailPicture/header_logo.png
                                    style="display: block; height: 40px; border: 0;"></img>

                            </div>

                    </tr>

                </table>
            </td>
            <td class="downtdright">
                &nbsp;
            </td>
        </tr>
    </table>
</body>

</html>
"""
