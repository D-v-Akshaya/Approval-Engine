leave_quota_request_body = """<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">
                                <soapenv:Header/>
                                <soapenv:Body>
                                    <urn:ZFTM0014>
                                        <!--Optional:-->
                                        <ABSQTATYP></ABSQTATYP>
                                        <EMPID>"""+"emp_id"+"""</EMPID>
                                        <FROMDT>"""+"valid_from"+"""</FROMDT>                                       
                                        <QUOTA_OVERVIEW>
                                            <!--Zero or more repetitions:-->
                                            <item>
                                            <KTEXT></KTEXT>
                                            <BEGDA></BEGDA>
                                            <ENDDA></ENDDA>
                                            <ANZHL></ANZHL>
                                            <KVERB></KVERB>
                                            <ANZHL_CLOSE></ANZHL_CLOSE>
                                            </item>
                                        </QUOTA_OVERVIEW>
                                        <TODT>"""+"valid_to"+"""</TODT>                     
                                    </urn:ZFTM0014>
                                </soapenv:Body>
                                </soapenv:Envelope>"""

# This is to get leave history 
leave_history_request_body = """<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">
                                    <soapenv:Header/>
                                    <soapenv:Body>
                                        <urn:ZFTM0017>
                                            <FROMDT>"""+"valid_from"+"""</FROMDT>
                                            <OUTPUT>
                                                <!--Zero or more repetitions:-->
                                                <item>
                                                <LEAVE_CODE></LEAVE_CODE>
                                                <APPLIED_DATE></APPLIED_DATE>
                                                <BEGDA></BEGDA>
                                                <ENDDA></ENDDA>
                                                <LEAVE_TYPE></LEAVE_TYPE>
                                                <TOT_LEAVES></TOT_LEAVES>
                                                <SUBMITTED_BY></SUBMITTED_BY>
                                                <APPROVER></APPROVER>
                                                <STATUS></STATUS>
                                                <SAP_STATUS></SAP_STATUS>
                                                <ERROR_MESSAGE></ERROR_MESSAGE>
                                                </item>
                                            </OUTPUT>
                                            <PERNR>"""+"emp_id"+"""</PERNR>
                                            <TODT>"""+"valid_to"+"""</TODT>
                                        </urn:ZFTM0017>
                                    </soapenv:Body>
                                </soapenv:Envelope>"""

# # This is to validate leave
leave_validate_update_requst_body = """<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">
                                        <soapenv:Header/>
                                        <soapenv:Body>
                                            <urn:ZFTM0015>
                                                <ABS_ATT_TYP>"""+"leave_category"+"""</ABS_ATT_TYP>
                                                <DAY>"""+"leave_type"+"""</DAY>
                                                <EMPLOYEENUMBER>"""+"emp_id"+"""</EMPLOYEENUMBER>
                                                <!--Optional:-->
                                                <END></END>
                                                <IT>"""+"info_type"+"""</IT>
                                                <LVREQNO></LVREQNO>
                                                <OPERATION>"""+"operation"+"""</OPERATION>
                                                <RETURN1>
                                                    <TYPE></TYPE>
                                                    <ID></ID>
                                                    <NUMBER></NUMBER>
                                                    <MESSAGE></MESSAGE>
                                                    <LOG_NO></LOG_NO>
                                                    <LOG_MSG_NO></LOG_MSG_NO>
                                                    <MESSAGE_V1></MESSAGE_V1>
                                                    <MESSAGE_V2></MESSAGE_V2>
                                                    <MESSAGE_V3></MESSAGE_V3>
                                                    <MESSAGE_V4></MESSAGE_V4>
                                                </RETURN1>
                                                <!--Optional:-->
                                                <SIMULATION>"""+"simulation"+"""</SIMULATION>
                                                <!--Optional:-->
                                                <START></START>
                                                <VALIDITYBEGIN>"""+"from_date"+"""</VALIDITYBEGIN>
                                                <VALIDITYEND>"""+"to_date"+"""</VALIDITYEND>
                                            </urn:ZFTM0015>
                                        </soapenv:Body>
                                        </soapenv:Envelope>"""

# This is to get attendance enquiry
attendance_enquiry_request_body = """<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:sap-com:document:sap:rfc:functions">
                                    <soapenv:Header/>
                                    <soapenv:Body>
                                        <urn:ZFTM0016>
                                            <FROMDT>"""+"from_date"+"""</FROMDT>
                                            <OUTPUT>
                                                <!--Zero or more repetitions:-->
                                                <item>
                                                <LDATE></LDATE>
                                                <SWIPE_IN></SWIPE_IN>
                                                <SWIPE_OUT></SWIPE_OUT>
                                                <SHIFT></SHIFT>
                                                <DAY_TYPE></DAY_TYPE>
                                                </item>
                                            </OUTPUT>
                                            <PERNR>"""+"emp_id"+"""</PERNR>
                                            <TODT>"""+"to_date"+"""</TODT>
                                        </urn:ZFTM0016>
                                    </soapenv:Body>
                                    </soapenv:Envelope>"""