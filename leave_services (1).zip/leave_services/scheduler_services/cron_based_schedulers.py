from apscheduler.schedulers.background import BackgroundScheduler
from leave_requests import views
from configuration import config
from common_functions.leave_functions import print_error_v1

#This is for start the schedular and upload attendance file
def auto_approval_schedular_start():
    scheduler = BackgroundScheduler()
    try:
        scheduler.add_job(views.leave_request_auto_approval, 'cron', hour=6, minute = 5)
        scheduler.add_job(views.export_to_excel_error_in_posting_v1, 'cron', hour=3, minute = 0)
        scheduler.start()
    except Exception as error:
        scheduler.shutdown()
        print_error_v1("auto_approval_schedular_start", error)
