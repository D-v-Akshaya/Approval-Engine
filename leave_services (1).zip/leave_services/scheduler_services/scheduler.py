from django.apps import AppConfig
import os

class SchedulerServicesConfig(AppConfig):
    name = 'scheduler_services'

    def ready(self):
        if os.environ.get('RUN_MAIN', None) != 'true':
            from .cron_based_schedulers import auto_approval_schedular_start
            from .interval_based_schedulers import update_leave_request_sap_schedular_start
            auto_approval_schedular_start()
            update_leave_request_sap_schedular_start()
