from apscheduler.schedulers.background import BackgroundScheduler
from leave_requests import views
from configuration import config
from common_functions.leave_functions import print_error_v1

#This is for start the schedular and update leave request in SAP
def update_leave_request_sap_schedular_start():
    scheduler = BackgroundScheduler()
    try:
        scheduler.add_job(views.update_leave_request_sap, 'interval', minutes= config.time_minutes)
        scheduler.add_job(views.update_leave_request_sap_v1, 'interval', minutes= config.time_minutes)
        scheduler.start()
    except Exception as error:
        scheduler.shutdown()
        print_error_v1("update_leave_request_sap_schedular_start", error)