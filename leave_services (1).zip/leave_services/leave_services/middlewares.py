class APIMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        response.__setitem__('Server', '')
        response.__setitem__('Strict-Transport-Security','max-age=31536000;includeSubDomains')
        response.__setitem__('Content-Security-Policy','script-src self; img-src self')
        return response
