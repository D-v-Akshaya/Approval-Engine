# from rest_framework import permissions
from keycloak import KeycloakOpenID
from keycloak import KeycloakAdmin
import jose,json
from django.conf import settings
from common_functions.leave_functions import is_employee_valid
from leave_services.settings import base
from django.shortcuts import redirect
from django.http import HttpResponse,JsonResponse
from configuration import message, config
# Configure client
keycloak_openid = KeycloakOpenID(server_url=config.KEYCLOAK_URL,
                    client_id=config.CLIENT_ID,
                    realm_name=config.REALM_NAME,
                    client_secret_key=config.CLIENT_SECRET_KEY)

# Description: This function check user is authentacated before accessing system
# Author : Suyog Jadhav
class UserAccessPermission:
    def __init__(self,get_response):
        self.get_response = get_response
    def __call__(self, request):
        response = self.get_response(request)
        return response
    def process_view(self, request,view_func, view_args, view_kargs):

        if request.path == "/leave_requests/get_leave_request_details/":
            return None
        try:
            token = request.headers['Authorization'].split()[1]
            options = {
                        "verify_signature": True,
                        "verify_aud": False,
                        "exp": True
            }
            token_info = keycloak_openid.decode_token(
                token,
                key=keycloak_openid.certs(),
                options=options
            )
            if not is_employee_valid(request, token_info):
                return JsonResponse(message.KEYCLOAK_UNAUTHORIZED_ACCESS_V1,safe=False)
            preferred_username = token_info['preferred_username'] if 'preferred_username' in token_info else ''
            clientId = token_info['clientId'] if 'clientId' in token_info else ''
            iss = token_info['iss'] if 'iss' in token_info else ''
            
            if (request.path=="/authentication/get_company_list/"):
                if preferred_username==config.PREFERRED_USERNAME and clientId == config.EDP_CLIENT_ID and iss == config.ISS:
                    return None
                else:
                    return JsonResponse(message.KEYCLOAK_UNAUTHORIZED_ACCESS)
            else:
                if preferred_username==config.PREFERRED_USERNAME:
                    return JsonResponse(message.KEYCLOAK_UNAUTHORIZED_ACCESS)
                else:
                    return None
                    
        except jose.exceptions.ExpiredSignatureError:
            result = {
                "status" : "450",
                "message" : config.TOKEN_EXPIRED_ERROR
            }
            return JsonResponse(result, safe=False)
        except jose.exceptions.JWTError:
            result = {
                "status" : "401",
                "message" : config.INVALID_TOKEN
            }  
            return JsonResponse(result, safe=False) 
        except Exception as error:
            print(error)
            return JsonResponse(message.KEYCLOAK_UNAUTHORIZED_ACCESS)