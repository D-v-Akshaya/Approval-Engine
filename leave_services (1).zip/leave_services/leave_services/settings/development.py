from .base import *
import os

# DATABASES = {
#     'default': {
#         'ENGINE':'django.db.backends.postgresql',
#         'NAME': os.getenv('DATABASE_NAME', 'Approval'),
#         'USER': os.getenv('DATABASE_USER', 'postgres'),
#         'PASSWORD': os.getenv('DATABASE_PASSWORD', '1234'),
#         'HOST': os.getenv('DATABASE_HOST', 'localhost'),
#         'PORT': os.getenv('DATABASE_PORT', '5432')
#     }
# }


DB_NAME='leave'
DB_USER='postgres'
DB_PASSWORD='1234'
DB_HOST='localhost'
DB_PORT='5432'

DATABASES = {
    'default': {
        'ENGINE':'django.db.backends.postgresql',
        'NAME': 'leave',
        'USER': 'postgres',
        'PASSWORD':'1234',
        'HOST':'localhost', 
        'PORT':'5432',
    }
}

