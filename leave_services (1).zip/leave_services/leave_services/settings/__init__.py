# settings file for local
# from .local import *

# settings file for development
from .development import *

# settings file for staging -- comment above and uncomment below line
# from .staging import *

# settings file for qa -- comment above and uncomment below line
# from .qa import *

# settings file for production -- comment above and uncomment below line
# from .production import *
