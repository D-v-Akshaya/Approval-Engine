from django.apps import AppConfig
import os

class LeaveRequestsConfig(AppConfig):
    name = 'leave_requests'
