from os import access
from django.db import models
from django.contrib.postgres.fields import JSONField,ArrayField
from django.contrib.postgres.fields import HStoreField
from approval_engine.models import ApprovalEngMasterData
# This is to store leave quota
class LeaveQuota2021(models.Model):
    leave_quota_id = models.CharField(max_length=100 , null=True)
    unique_quota_id = models.CharField(max_length=100 , null=True)
    emp_id = models.CharField(max_length=10 , null=True)
    quota_code = models.CharField(max_length=10 , null=True)
    quota_valid_from = models.DateField(null=True)
    quota_valid_to = models.DateField(null=True)
    total_leaves = models.CharField(max_length=10 , null=True)
    available_leaves = models.CharField(max_length=10 , null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=10 , null=True)
    modified_by = models.CharField(max_length=10 , null=True)

    class Meta:
        db_table = "leave_quota_2021"

# This is to store leave quota
class QuotaLeaveCategoryMapping(models.Model):
    leave_category = models.CharField(max_length=10 , null=True)
    quota_code = models.CharField(max_length=10 , null=True)
    
    class Meta:
        db_table = "quota_leave_category_mapping"

# This is to strore leave requests from edp
class LeaveRequestsEDP2021(models.Model):
    leave_request_id = models.CharField(max_length=100 , null=True)
    requestor_emp_id = models.CharField(max_length=10 , null=True)
    requestor_email = models.CharField(max_length=256 , null=True)
    leave_category = models.CharField(max_length=20, null=True)
    leave_type = models.CharField(max_length=20, null=True)
    from_date = models.DateField(null=True)
    to_date = models.DateField(null=True)
    reason = models.CharField(max_length=256, null=True)
    total_days = models.CharField(max_length=10, null=True)
    leave_status = models.CharField(max_length=20, null=True)
    applied_date = models.DateField(null=True)
    approver_emp_id = models.CharField(max_length=10 , null=True)
    approver_email = models.CharField(max_length=256 , null=True)
    is_deleted = models.BooleanField(null=True)
    unique_quota_id = models.CharField(max_length=256 , null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=100, null=True)
    modified_by = models.CharField(max_length=100, null=True)

    class Meta:
        db_table = "leave_requests_edp_2021"

# This is to strore leave requests from sap
class LeaveRequestsSAP2021(models.Model):
    leave_request_id = models.CharField(max_length=100 , null=True)
    requestor_emp_id = models.CharField(max_length=10 , null=True)
    requestor_email = models.CharField(max_length=256 , null=True)
    leave_category = models.CharField(max_length=20, null=True)
    leave_type = models.CharField(max_length=20, null=True)
    from_date = models.DateField(null=True)
    to_date = models.DateField(null=True)
    reason = models.CharField(max_length=256, null=True)
    total_days = models.CharField(max_length=10, null=True)
    leave_status = models.CharField(max_length=20, null=True)
    applied_date = models.DateField(null=True)
    approver_emp_id = models.CharField(max_length=10 , null=True)
    approver_email = models.CharField(max_length=256 , null=True)
    is_deleted = models.BooleanField(null=True)
    unique_quota_id = models.CharField(max_length=256 , null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=100, null=True)
    modified_by = models.CharField(max_length=100, null=True)

    class Meta:
        db_table = "leave_requests_sap_2021"

# This is to strore leave requests with status approved and update in progrss
class ApprovedLeaveRequests2021(models.Model):
    leave_request_id = models.CharField(max_length=100 , null=True)
    created_date_time = models.DateTimeField(null=True)
    
    class Meta:
        db_table = "approved_leave_requests_2021"

# This is to strore leave categoty (master table) 
class LeaveCategory(models.Model):
    leave_category_code = models.CharField(max_length=20 , null=True)
    leave_category_text = models.CharField(max_length=100 , null=True)

    class Meta:
        db_table = "leave_category"

# This is to strore leave type (master table) 
class LeaveType(models.Model):
    leave_type_code = models.CharField(max_length=20 , null=True)
    leave_type_text = models.CharField(max_length=100 , null=True)

    class Meta:
        db_table = "leave_type"

# This is to strore leave status (master table)
class LeaveStatus(models.Model):
    leave_status_code = models.CharField(max_length=20 , null=True)
    leave_status_text = models.CharField(max_length=100 , null=True)
    leave_status_color = models.CharField(max_length=256 , null=True)

    class Meta:
        db_table = "leave_status"

# This is to strore leave categoty and PA/PSA mapping(master table) 
class PAPSALeaveCategoryMapping(models.Model):
    personal_area = models.CharField(max_length=20 , null=True)
    personal_sub_area = models.CharField(max_length=20, null=True)
    applicable_leave_categories = JSONField(null=True)

    class Meta:
        db_table = "pa_psa_leave_category_mapping"

#This is to store the leave approval 
class LeaveApproval2021(models.Model):
    leave_approval_id = models.CharField(max_length=100 , null=True)
    leave_request_id = models.CharField(max_length=100 , null=True)
    requestor_emp_id = models.CharField(max_length=10 , null=True)
    action_taken = models.CharField(max_length=20, null=True)
    action_owner = models.CharField(max_length=20, null=True)
    approval_type = models.CharField(max_length=30, null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=100, null=True)
    modified_by = models.CharField(max_length=100, null=True)

    class Meta:
        db_table = "leave_approval_2021"

#This is to store the leave approval 
class LeaveApprovalActions(models.Model):
    leave_approval_action_code = models.CharField(max_length=100 , null=True)
    leave_approval_action_text = models.CharField(max_length=100 , null=True)
    class Meta:
        db_table = "leave_approval_action"

#This is to store the pa psa and group mapping
class PAPSAGroupMapping(models.Model):
    pa_code = models.CharField(max_length=5 , null=True)
    psa_code = models.CharField(max_length=5 , null=True)
    pa_psa_group = models.CharField(max_length=5 , null=True)
    class Meta:
        db_table = "pa_psa_group_mapping"

#This is to store the ps group and leave category mapping
class PSGroupLeaveCategoryMapping(models.Model):
    pa_psa_group = models.CharField(max_length=5 , null=True)
    leave_category_code = models.CharField(max_length=5 , null=True)
    leave_category_text = models.CharField(max_length=100 , null=True)
    leave_group = models.CharField(max_length=100 , null=True)
    valid_from = models.DateField(null=True)
    valid_to = models.DateField(null=True)
    leave_categrory_color = models.CharField(max_length=256 , null=True)
    class Meta:
        db_table = "ps_group_leave_category_mapping"

#This is to store quota (Master table)
class Quota(models.Model):
    quota_code = models.CharField(max_length=256 , null=True)
    quota_text = models.CharField(max_length=256 , null=True)
    quota_color_text = models.CharField(max_length=256 , null=True)
    home_page_visibility = models.BooleanField(null=True)
    class Meta:
        db_table = "quota"

# This is to strore active quota codes 
class ActiveQuotaDetails2021(models.Model):
    active_quota_details_id = models.CharField(max_length=100 , null=True)
    emp_id = models.CharField(max_length=10 , null=True)
    active_quota_code = ArrayField(models.CharField(max_length=5),size = 20 ,null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=100, null=True)
    modified_by = models.CharField(max_length=100, null=True)

    class Meta:
        db_table = "active_quota_details2021"

#This is to store the ps group and leave category mapping -- extra leave categories
class ExtendedPSGroupLeaveCategoryMapping(models.Model):
    pa_psa_group = models.CharField(max_length=5 , null=True)
    leave_category_code = models.CharField(max_length=5 , null=True)
    leave_category_text = models.CharField(max_length=100 , null=True)
    leave_group = models.CharField(max_length=100 , null=True)
    valid_from = models.DateField(null=True)
    valid_to = models.DateField(null=True)
    class Meta:
        db_table = "extended_ps_group_leave_category_mapping"

#This is to store leave services log
class LeaveServicesLogs_2021(models.Model):
    log_id = models.CharField(max_length=100 , null=True)
    log_type = models.CharField(max_length=100 , null=True)
    result = models.CharField(max_length=100 , null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=10 , null=True)
    modified_by = models.CharField(max_length=10 , null=True)
    class Meta:
        db_table = "leave_services_logs_2021"

#This is to store sap  postoing details
class SAPPostingDetails2021(models.Model):
    leave_request_id = models.CharField(max_length=100 , null=True)
    leave_request_datetime= models.DateTimeField(null=True)
    delete_leave_datetime = models.DateTimeField(null=True)
    leave_request_posting_datetime= models.DateTimeField(null=True)
    delete_leave_posting_datetime = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=10 , null=True)
    modified_by = models.CharField(max_length=10 , null=True)
    class Meta:
        db_table = "sap_posting_details_2021"

# This is to strore leave againest LWOP
class LeaveAgainstLWOP2021(models.Model):
    leave_request_id = models.CharField(max_length=100 , null=True)
    is_deleted = models.BooleanField(null=True,default=False)
    is_posted = models.BooleanField(null=True,default=False)
    created_date_time = models.DateTimeField(null=True)
    
    class Meta:
        db_table = "leave_against_lwop_2021"

class ActiveYear(models.Model):
    active_year = models.CharField(max_length=100 , null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=10 , null=True)
    modified_by = models.CharField(max_length=10 , null=True)
    is_active = models.BooleanField(null=True,default=True)
    class Meta:
        db_table = "active_year"

####################################################### BackUp 2020 ###############################################

# This is to store leave quota 2020
class LeaveQuota2020(models.Model):
    leave_quota_id = models.CharField(max_length=100 , null=True)
    unique_quota_id = models.CharField(max_length=100 , null=True)
    emp_id = models.CharField(max_length=10 , null=True)
    quota_code = models.CharField(max_length=10 , null=True)
    quota_valid_from = models.DateField(null=True)
    quota_valid_to = models.DateField(null=True)
    total_leaves = models.CharField(max_length=10 , null=True)
    available_leaves = models.CharField(max_length=10 , null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=10 , null=True)
    modified_by = models.CharField(max_length=10 , null=True)

    class Meta:
        db_table = "leave_quota_2020"

# This is to store leave requests from edp 2020
class LeaveRequestsEDP2020(models.Model):
    leave_request_id = models.CharField(max_length=100 , null=True)
    requestor_emp_id = models.CharField(max_length=10 , null=True)
    requestor_email = models.CharField(max_length=256 , null=True)
    leave_category = models.CharField(max_length=20, null=True)
    leave_type = models.CharField(max_length=20, null=True)
    from_date = models.DateField(null=True)
    to_date = models.DateField(null=True)
    reason = models.CharField(max_length=256, null=True)
    total_days = models.CharField(max_length=10, null=True)
    leave_status = models.CharField(max_length=20, null=True)
    applied_date = models.DateField(null=True)
    approver_emp_id = models.CharField(max_length=10 , null=True)
    approver_email = models.CharField(max_length=256 , null=True)
    is_deleted = models.BooleanField(null=True)
    unique_quota_id = models.CharField(max_length=256 , null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=100, null=True)
    modified_by = models.CharField(max_length=100, null=True)

    class Meta:
        db_table = "leave_requests_edp_2020"

# This is to strore leave requests from sap
class LeaveRequestsSAP2020(models.Model):
    leave_request_id = models.CharField(max_length=100 , null=True)
    requestor_emp_id = models.CharField(max_length=10 , null=True)
    requestor_email = models.CharField(max_length=256 , null=True)
    leave_category = models.CharField(max_length=20, null=True)
    leave_type = models.CharField(max_length=20, null=True)
    from_date = models.DateField(null=True)
    to_date = models.DateField(null=True)
    reason = models.CharField(max_length=256, null=True)
    total_days = models.CharField(max_length=10, null=True)
    leave_status = models.CharField(max_length=20, null=True)
    applied_date = models.DateField(null=True)
    approver_emp_id = models.CharField(max_length=10 , null=True)
    approver_email = models.CharField(max_length=256 , null=True)
    is_deleted = models.BooleanField(null=True)
    unique_quota_id = models.CharField(max_length=256 , null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=100, null=True)
    modified_by = models.CharField(max_length=100, null=True)

    class Meta:
        db_table = "leave_requests_sap_2020"

# This is to store leave requests with status approved and update in progress 2020
class ApprovedLeaveRequests2020(models.Model):
    leave_request_id = models.CharField(max_length=100 , null=True)
    created_date_time = models.DateTimeField(null=True)
    
    class Meta:
        db_table = "approved_leave_requests_2020"

#This is to store the leave approval 2020
class LeaveApproval2020(models.Model):
    leave_approval_id = models.CharField(max_length=100 , null=True)
    leave_request_id = models.CharField(max_length=100 , null=True)
    requestor_emp_id = models.CharField(max_length=10 , null=True)
    action_taken = models.CharField(max_length=20, null=True)
    action_owner = models.CharField(max_length=20, null=True)
    approval_type = models.CharField(max_length=30, null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=100, null=True)
    modified_by = models.CharField(max_length=100, null=True)

    class Meta:
        db_table = "leave_approval_2020"

# This is to store active quota codes 2020 
class ActiveQuotaDetails2020(models.Model):
    active_quota_details_id = models.CharField(max_length=100 , null=True)
    emp_id = models.CharField(max_length=10 , null=True)
    active_quota_code = ArrayField(models.CharField(max_length=5),size = 20 ,null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=100, null=True)
    modified_by = models.CharField(max_length=100, null=True)

    class Meta:
        db_table = "active_quota_details_2020"

#This is to store leave services log 2020
class LeaveServicesLogs2020(models.Model):
    log_id = models.CharField(max_length=100 , null=True)
    log_type = models.CharField(max_length=100 , null=True)
    result = models.CharField(max_length=100 , null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=10 , null=True)
    modified_by = models.CharField(max_length=10 , null=True)
    class Meta:
        db_table = "leave_services_logs_2020"

#This is to store sap posting details 2020
class SAPPostingDetails2020(models.Model):
    leave_request_id = models.CharField(max_length=100 , null=True)
    leave_request_datetime= models.DateTimeField(null=True)
    delete_leave_datetime = models.DateTimeField(null=True)
    leave_request_posting_datetime= models.DateTimeField(null=True)
    delete_leave_posting_datetime = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=10 , null=True)
    modified_by = models.CharField(max_length=10 , null=True)
    class Meta:
        db_table = "sap_posting_details_2020"

# This is to strore leave againest LWOP
class LeaveAgainstLWOP2020(models.Model):
    leave_request_id = models.CharField(max_length=100 , null=True)
    is_deleted = models.BooleanField(null=True,default=False)
    is_posted = models.BooleanField(null=True,default=False)
    created_date_time = models.DateTimeField(null=True)
    
    class Meta:
        db_table = "leave_against_lwop_2020"

class EmployeePushNotification(models.Model):
    employee_unique_id = models.CharField(max_length=256 , null=True)
    emp_id = models.CharField(max_length=256 , null=True)
    emp_fcm_token = models.CharField(max_length=1024 , null=True)
    create_by = models.CharField(max_length=256 , null=True)
    platform = models.CharField(max_length=256 , null=True)
    notification_allowed = models.CharField(max_length=256 , null=True)
    organization_notification = models.CharField(max_length=256 , null=True)
    announcement_notification = models.CharField(max_length=256 , null=True)
    notification_access = JSONField(null=True)
    create_datetime = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)

    class Meta:
        db_table = "employee_push_notification"

################################## Backup 2021 ##################################################################

# This is to store leave quota
class LeaveQuota(models.Model):
    leave_quota_id = models.CharField(max_length=100 , null=True)
    unique_quota_id = models.CharField(max_length=100 , null=True)
    emp_id = models.CharField(max_length=10 , null=True)
    quota_code = models.CharField(max_length=10 , null=True)
    quota_valid_from = models.DateField(null=True)
    quota_valid_to = models.DateField(null=True)
    total_leaves = models.CharField(max_length=10 , null=True)
    available_leaves = models.CharField(max_length=10 , null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=10 , null=True)
    modified_by = models.CharField(max_length=10 , null=True)

    class Meta:
        db_table = "leave_quota"


# This is to strore leave requests from edp
class LeaveRequestsEDP(models.Model):
    leave_request_id = models.CharField(max_length=100 , null=True)
    requestor_emp_id = models.CharField(max_length=10 , null=True)
    requestor_email = models.CharField(max_length=256 , null=True)
    leave_category = models.CharField(max_length=20, null=True)
    leave_type = models.CharField(max_length=20, null=True)
    from_date = models.DateField(null=True)
    to_date = models.DateField(null=True)
    reason = models.CharField(max_length=256, null=True)
    total_days = models.CharField(max_length=10, null=True)
    leave_status = models.CharField(max_length=20, null=True)
    applied_date = models.DateField(null=True)
    approver_emp_id = models.CharField(max_length=10 , null=True)
    approver_email = models.CharField(max_length=256 , null=True)
    is_deleted = models.BooleanField(null=True)
    unique_quota_id = models.CharField(max_length=256 , null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=100, null=True)
    modified_by = models.CharField(max_length=100, null=True)

    class Meta:
        db_table = "leave_requests_edp"

#New leave request table
class LeaveRequeststable(models.Model): 
    requestor_emp_id = models.CharField(max_length=10 , null=True)
    approvalEngUniqueID =models.ForeignKey(ApprovalEngMasterData,on_delete=models.CASCADE)
    
# This is to strore leave requests from sap
class LeaveRequestsSAP(models.Model):
    leave_request_id = models.CharField(max_length=100 , null=True) 
    requestor_emp_id = models.CharField(max_length=10 , null=True)
    requestor_email = models.CharField(max_length=256 , null=True)
    leave_category = models.CharField(max_length=20, null=True)
    leave_type = models.CharField(max_length=20, null=True)
    from_date = models.DateField(null=True)
    to_date = models.DateField(null=True)
    reason = models.CharField(max_length=256, null=True)
    total_days = models.CharField(max_length=10, null=True)
    leave_status = models.CharField(max_length=20, null=True)
    applied_date = models.DateField(null=True)
    approver_emp_id = models.CharField(max_length=10 , null=True)
    approver_email = models.CharField(max_length=256 , null=True)
    is_deleted = models.BooleanField(null=True)
    unique_quota_id = models.CharField(max_length=256 , null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=100, null=True)
    modified_by = models.CharField(max_length=100, null=True)

    class Meta:
        db_table = "leave_requests_sap"


# This is to strore leave requests with status approved and update in progrss
class ApprovedLeaveRequests(models.Model):
    leave_request_id = models.CharField(max_length=100 , null=True)
    created_date_time = models.DateTimeField(null=True)
    
    class Meta:
        db_table = "approved_leave_requests"

# This is to store the leave approval 
class LeaveApproval(models.Model):
    leave_approval_id = models.CharField(max_length=100 , null=True)
    leave_request_id = models.CharField(max_length=100 , null=True)
    requestor_emp_id = models.CharField(max_length=10 , null=True)
    action_taken = models.CharField(max_length=20, null=True)
    action_owner = models.CharField(max_length=20, null=True)
    approval_type = models.CharField(max_length=30, null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=100, null=True)
    modified_by = models.CharField(max_length=100, null=True)

    class Meta:
        db_table = "leave_approval"

# This is to strore active quota codes 
class ActiveQuotaDetails(models.Model):
    active_quota_details_id = models.CharField(max_length=100 , null=True)
    emp_id = models.CharField(max_length=10 , null=True)
    active_quota_code = ArrayField(models.CharField(max_length=5),size = 20 ,null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=100, null=True)
    modified_by = models.CharField(max_length=100, null=True)

    class Meta:
        db_table = "active_quota_details"

class LeaveServicesLogs(models.Model):
    log_id = models.CharField(max_length=100 , null=True)
    log_type = models.CharField(max_length=100 , null=True)
    result = models.CharField(max_length=100 , null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=10 , null=True)
    modified_by = models.CharField(max_length=10 , null=True)
    class Meta:
        db_table = "leave_services_logs"

# This is to store sap  postoing details
class SAPPostingDetails(models.Model):
    leave_request_id = models.CharField(max_length=100 , null=True)
    leave_request_datetime= models.DateTimeField(null=True)
    delete_leave_datetime = models.DateTimeField(null=True)
    leave_request_posting_datetime= models.DateTimeField(null=True)
    delete_leave_posting_datetime = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=10 , null=True)
    modified_by = models.CharField(max_length=10 , null=True)
    class Meta:
        db_table = "sap_posting_details"

class LeaveAgainstLWOP(models.Model):
    leave_request_id = models.CharField(max_length=100 , null=True)
    is_deleted = models.BooleanField(null=True,default=False)
    is_posted = models.BooleanField(null=True,default=False)
    created_date_time = models.DateTimeField(null=True)
    
    class Meta:
        db_table = "leave_against_lwop"
'''class PreviousLeaveAgainstLWOP(models.Model):
    leave_request_id = models.CharField(max_length=100 , null=True)
    is_deleted = models.BooleanField(null=True,default=False)
    is_posted = models.BooleanField(null=True,default=False)
    created_date_time = models.DateTimeField(null=True)
    
    class Meta:
        db_table = "leave_against_lwop"
        '''
# This is to strore leave requests from edp
class PreviousYearLeaveRequests(models.Model):
    leave_request_id = models.CharField(max_length=100 , null=True)
    requestor_emp_id = models.CharField(max_length=10 , null=True)
    requestor_email = models.CharField(max_length=256 , null=True)
    leave_category = models.CharField(max_length=20, null=True)
    leave_type = models.CharField(max_length=20, null=True)
    from_date = models.DateField(null=True)
    to_date = models.DateField(null=True)
    reason = models.CharField(max_length=256, null=True)
    total_days = models.CharField(max_length=10, null=True)
    leave_status = models.CharField(max_length=20, null=True)
    applied_date = models.DateField(null=True)
    approver_emp_id = models.CharField(max_length=10 , null=True)
    approver_email = models.CharField(max_length=256 , null=True)
    is_deleted = models.BooleanField(null=True)
    unique_quota_id = models.CharField(max_length=256 , null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=100, null=True)
    modified_by = models.CharField(max_length=100, null=True)

    class Meta:
        db_table = "previous_year_leave_requests"

#This is to store the leave approval 
class PreviousYearLeaveApproval(models.Model):
    leave_approval_id = models.CharField(max_length=100 , null=True)
    leave_request_id = models.CharField(max_length=100 , null=True)
    requestor_emp_id = models.CharField(max_length=10 , null=True)
    action_taken = models.CharField(max_length=20, null=True)
    action_owner = models.CharField(max_length=20, null=True)
    approval_type = models.CharField(max_length=30, null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=100, null=True)
    modified_by = models.CharField(max_length=100, null=True)

    class Meta:
        db_table = "previous_year_leave_approval"
################################## Backup 2021  ##################################################################

# Year end activity - 2022

class LeaveAgainstLWOP_2022(models.Model):
    leave_request_id = models.CharField(max_length=100 , null=True)
    is_deleted = models.BooleanField(null=True,default=False)
    is_posted = models.BooleanField(null=True,default=False)
    created_date_time = models.DateTimeField(null=True)
    
    class Meta:
        db_table = "leave_against_lwop_2022"

# This is to store sap  postoing details
class SAPPostingDetails_2022(models.Model):
    leave_request_id = models.CharField(max_length=100 , null=True)
    leave_request_datetime= models.DateTimeField(null=True)
    delete_leave_datetime = models.DateTimeField(null=True)
    leave_request_posting_datetime= models.DateTimeField(null=True)
    delete_leave_posting_datetime = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=10 , null=True)
    modified_by = models.CharField(max_length=10 , null=True)
    class Meta:
        db_table = "sap_posting_details_2022"

class LeaveServicesLogs_2022(models.Model):
    log_id = models.CharField(max_length=100 , null=True)
    log_type = models.CharField(max_length=100 , null=True)
    result = models.CharField(max_length=100 , null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=10 , null=True)
    modified_by = models.CharField(max_length=10 , null=True)
    class Meta:
        db_table = "leave_services_logs_2022"

# This is to strore active quota codes 
class ActiveQuotaDetails_2022(models.Model):
    active_quota_details_id = models.CharField(max_length=100 , null=True)
    emp_id = models.CharField(max_length=10 , null=True)
    active_quota_code = ArrayField(models.CharField(max_length=5),size = 20 ,null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=100, null=True)
    modified_by = models.CharField(max_length=100, null=True)

    class Meta:
        db_table = "active_quota_details_2022"

# This is to store the leave approval 
class LeaveApproval_2022(models.Model):
    leave_approval_id = models.CharField(max_length=100 , null=True)
    leave_request_id = models.CharField(max_length=100 , null=True)
    requestor_emp_id = models.CharField(max_length=10 , null=True)
    action_taken = models.CharField(max_length=20, null=True)
    action_owner = models.CharField(max_length=20, null=True)
    approval_type = models.CharField(max_length=30, null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=100, null=True)
    modified_by = models.CharField(max_length=100, null=True)

    class Meta:
        db_table = "leave_approval_2022"

# This is to strore leave requests with status approved and update in progrss
class ApprovedLeaveRequests_2022(models.Model):
    leave_request_id = models.CharField(max_length=100 , null=True)
    created_date_time = models.DateTimeField(null=True)
    
    class Meta:
        db_table = "approved_leave_requests_2022"

# This is to strore leave requests from sap
class LeaveRequestsSAP_2022(models.Model):
    leave_request_id = models.CharField(max_length=100 , null=True)
    requestor_emp_id = models.CharField(max_length=10 , null=True)
    requestor_email = models.CharField(max_length=256 , null=True)
    leave_category = models.CharField(max_length=20, null=True)
    leave_type = models.CharField(max_length=20, null=True)
    from_date = models.DateField(null=True)
    to_date = models.DateField(null=True)
    reason = models.CharField(max_length=256, null=True)
    total_days = models.CharField(max_length=10, null=True)
    leave_status = models.CharField(max_length=20, null=True)
    applied_date = models.DateField(null=True)
    approver_emp_id = models.CharField(max_length=10 , null=True)
    approver_email = models.CharField(max_length=256 , null=True)
    is_deleted = models.BooleanField(null=True)
    unique_quota_id = models.CharField(max_length=256 , null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=100, null=True)
    modified_by = models.CharField(max_length=100, null=True)

    class Meta:
        db_table = "leave_requests_sap_2022"

# This is to strore leave requests from edp
class LeaveRequestsEDP_2022(models.Model):
    leave_request_id = models.CharField(max_length=100 , null=True)
    requestor_emp_id = models.CharField(max_length=10 , null=True)
    requestor_email = models.CharField(max_length=256 , null=True)
    leave_category = models.CharField(max_length=20, null=True)
    leave_type = models.CharField(max_length=20, null=True)
    from_date = models.DateField(null=True)
    to_date = models.DateField(null=True)
    reason = models.CharField(max_length=256, null=True)
    total_days = models.CharField(max_length=10, null=True)
    leave_status = models.CharField(max_length=20, null=True)
    applied_date = models.DateField(null=True)
    approver_emp_id = models.CharField(max_length=10 , null=True)
    approver_email = models.CharField(max_length=256 , null=True)
    is_deleted = models.BooleanField(null=True)
    unique_quota_id = models.CharField(max_length=256 , null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=100, null=True)
    modified_by = models.CharField(max_length=100, null=True)

    class Meta:
        db_table = "leave_requests_edp_2022"

# This is to store leave quota
class LeaveQuota_2022(models.Model):
    leave_quota_id = models.CharField(max_length=100 , null=True)
    unique_quota_id = models.CharField(max_length=100 , null=True)
    emp_id = models.CharField(max_length=10 , null=True)
    quota_code = models.CharField(max_length=10 , null=True)
    quota_valid_from = models.DateField(null=True)
    quota_valid_to = models.DateField(null=True)
    total_leaves = models.CharField(max_length=10 , null=True)
    available_leaves = models.CharField(max_length=10 , null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)
    created_by = models.CharField(max_length=10 , null=True)
    modified_by = models.CharField(max_length=10 , null=True)

    class Meta:
        db_table = "leave_quota_2022"

#This table is to Store the Ex Com Employees(Employees without Reporting Managers)
class ExComEmployees(models.Model):
    emp_id = models.CharField(max_length=10)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "ex_com_employees"

#This table is to store the logs of the certain APIs
class LeaveErrorLogs(models.Model):
    unique_id = models.CharField(max_length=100 , null=True)
    api_name = models.CharField(max_length=100 , null=True)
    action = models.CharField(max_length=256 , null=True)
    status = models.CharField(max_length=256 , null=True)
    description = models.TextField(null=True)
    leave_request_id = models.CharField(max_length=100 , null=True)
    requestor_emp_id = models.CharField(max_length=10 , null=True)
    requestor_email = models.CharField(max_length=256 , null=True)
    leave_category = models.CharField(max_length=20, null=True)
    leave_type = models.CharField(max_length=20, null=True)
    from_date = models.DateField(null=True)
    to_date = models.DateField(null=True)
    total_days = models.CharField(max_length=10, null=True)
    leave_status = models.CharField(max_length=20, null=True)
    applied_date = models.DateField(null=True)
    approver_emp_id = models.CharField(max_length=10 , null=True)
    approver_email = models.CharField(max_length=256 , null=True)
    is_deleted = models.BooleanField(null=True)
    leave_created_datetime = models.DateTimeField(null=True)
    leave_modified_datetime = models.DateTimeField(null=True)
    leave_created_by = models.CharField(max_length=100, null=True)
    leave_modified_by = models.CharField(max_length=100, null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)

    class Meta:
        db_table = "leave_error_logs"

#This table is to store the logs and data of the leave scheduler program.
class LeaveSchedulerLogs(models.Model):
    unique_id = models.CharField(max_length=100 , null=True)
    scheduler_name = models.CharField(max_length=100 , null=True)
    sap_leave_post_type = models.CharField(max_length=256 , null=True)
    description = models.TextField(null=True)
    status = models.CharField(max_length=256 , null=True)
    status_code = models.CharField(max_length=256 , null=True)
    status_number = models.CharField(max_length=256 , null=True)
    status_message = models.CharField(max_length=256 , null=True)
    leave_request_id = models.CharField(max_length=100 , null=True)
    requestor_emp_id = models.CharField(max_length=10 , null=True)
    requestor_email = models.CharField(max_length=256 , null=True)
    leave_category = models.CharField(max_length=20, null=True)
    leave_type = models.CharField(max_length=20, null=True)
    from_date = models.DateField(null=True)
    to_date = models.DateField(null=True)
    total_days = models.CharField(max_length=10, null=True)
    leave_status = models.CharField(max_length=20, null=True)
    applied_date = models.DateField(null=True)
    approver_emp_id = models.CharField(max_length=10 , null=True)
    approver_email = models.CharField(max_length=256 , null=True)
    is_deleted = models.BooleanField(null=True)
    leave_created_datetime = models.DateTimeField(null=True)
    leave_modified_datetime = models.DateTimeField(null=True)
    leave_created_by = models.CharField(max_length=100, null=True)
    leave_modified_by = models.CharField(max_length=100, null=True)
    created_date_time = models.DateTimeField(null=True)
    modified_date_time = models.DateTimeField(null=True)

    class Meta:
        db_table = "leave_scheduler_logs"

#This table is for configuring the leave schedulers(on/off)
class LeaveSchedulerConfig(models.Model):
    scheduler_name = models.CharField(max_length=100 , null=True)
    is_active = models.BooleanField(null=True)

    class Meta:
        db_table = "leave_scheduler_config"