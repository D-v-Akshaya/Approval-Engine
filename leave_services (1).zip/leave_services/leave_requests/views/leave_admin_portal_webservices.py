from django.http import JsonResponse
from ..models import *
import json
from django.views.decorators.csrf import csrf_exempt
from django.core import serializers
from datetime import datetime, date, timedelta
from pytz import timezone
from datetime import time
from django.db.models import Q
from django.core.mail import EmailMultiAlternatives
from django.core import mail
from django.core.paginator import Paginator
from django.db import connection
from configuration import config
from configuration import common_request_body
from configuration import constants
from configuration import message
from configuration import template
from common_functions import *


# METHOD: get_employee_leave_summary
# DESCRIPTION: #This is used to get the approved leave summary..
# AUTHOR: Vikas Tomar
# Date: 04/11/2022
@csrf_exempt
def get_employee_leave_summary(request):
    try:
        user_request = json.loads(request.body)
        if not (user_request and 'month' in user_request):
            return JsonResponse(return_object_func(message.ERROR_STATUS_CODE,message.INVALID_REQUEST_BODY,{}),safe=False)
        leave_month = user_request['month']

        # This is to get current year IST
        active_year_details = ActiveYear.objects.filter(is_active=True).first()
        current_year_ist = int(active_year_details.active_year)

        #Get the employee leave summary.
        if leave_month ==constants.ALL_LEAVE_MONTH:
            leave_summary_query_set = LeaveRequestsEDP.objects.filter(leave_status = constants.APPROVED_LEAVE_STATUS,is_deleted=False)
        else:
            leave_summary_query_set = LeaveRequestsEDP.objects.filter(Q(from_date__month = leave_month) | Q(to_date__month = leave_month), leave_status = constants.APPROVED_LEAVE_STATUS,is_deleted=False)

        leave_summary = {
            "casual_leave":leave_summary_query_set.filter(leave_category = constants.CASUAL_LEAVE_CODE).count(),
            "sick_leave":leave_summary_query_set.filter(leave_category= constants.SICK_LEAVE_CODE).count(),
            "privilege_leave":leave_summary_query_set.filter(leave_category=constants.PRIVILEGE_LEAVE).count(),
        }
        return JsonResponse(return_object_func(message.SUCCESS_STATUS_CODE,message.SUCCESS_RETIVED_DATA,leave_summary),safe=False)
    except Exception as error:
        print_error("get_employee_leave_summary",error)
        return JsonResponse(return_object_func(message.ERROR_STATUS_CODE,message.INVALID_REQUEST_BODY,{}),safe=False)
