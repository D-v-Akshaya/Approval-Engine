from django.http import JsonResponse
import json, xmltodict
from django.views.decorators.csrf import csrf_exempt
from configuration import config, common_request_body
from configuration import constants
from configuration import message
from common_functions import return_object_func, return_response_func, print_error_v1
from datetime import datetime
import requests
from dateutil.relativedelta import relativedelta
from ..models import LeaveRequestsEDP, LeaveStatus

# Method: get_reportee_availed_leaves_data
# Author: Bhavik Jain
# Description: This Method will fetch direct reportee total and availed leave quota 
@csrf_exempt
def get_reportee_availed_leaves_data(request):
    try:
        user_request = json.loads(request.body)
        if not all (key in user_request and user_request[key] for key in constants.REPORTEE_ID):
            return JsonResponse(constants.HTTP_400_BAD_REQUEST, message.INVALID_REQUEST_BODY_V1)
        emp_id = user_request.get('emp_id')

        reportees_leave_quota = []
        request_body = {"emp_id": emp_id}
        response_data = requests.post(config.GET_SF_USER_DETAILS, headers=request.headers, data=json.dumps(request_body))
        print("response_data", response_data.status_code)
        if response_data.status_code != constants.SUCCESS_STATUS_CODE:
            return JsonResponse(return_object_func(constants.ERROR_STATUS_CODE, message.GET_SF_DATA_FAILED, {}), safe=False)
        user_details_json = response_data.json()
        if not user_details_json:
            return JsonResponse(return_object_func(constants.ERROR_STATUS_CODE, message.FAILURE, {}), safe=False)
        all_reportess = user_details_json.get('user_details').get('all_reportees')
        for reportee in all_reportess:
            employee_id = reportee.get('empId')
            employee_leave_quota = {
                constants.EMPLOYEE_ID: "", constants.EMPLOYEE_NAME: "", "doj": None, constants.PL_QUOTA: None, 
                constants.PL_QUOTA_AVAILED: None, constants.CL_QUOTA: None,
                constants.CL_QUOTA_AVAILED: None, constants.SL_QUOTA: None,constants.SL_QUOTA_AVAILED: None
            }
            employee_leave_quota[constants.EMPLOYEE_ID] = employee_id
            employee_leave_quota[constants.EMPLOYEE_NAME] = reportee.get('defaultFullName')
            employee = {"emp_id": employee_id}
            response_data = requests.post(config.GET_LEAVE_QUOTA, headers=request.headers, data=json.dumps(employee))
            if response_data.status_code == constants.ERROR_STATUS_CODE:
                return JsonResponse(return_object_func(constants.ERROR_STATUS_CODE, message.FAILURE, {}), safe=False)
            user_details_json = response_data.json()
            if user_details_json[constants.STATUS_CODE] == constants.ERROR_STATUS_CODE:
                print('unable to fetch leave quota for: ', employee_id)
                return JsonResponse(return_object_func(constants.ERROR_STATUS_CODE, message.FAILURE, {}), safe=False)
            get_employee_leave_quota = user_details_json.get("leave_quota_details")
            for leave_quota in get_employee_leave_quota:
                if leave_quota.get("leave_quota_code") == constants.PL_LEAVE_QUOTA:
                    employee_leave_quota[constants.PL_QUOTA] = float(leave_quota.get("total_leaves"))
                    employee_leave_quota[constants.PL_QUOTA_AVAILED] = float(leave_quota.get("total_leaves")) - float(leave_quota.get("available_leaves"))
                if leave_quota.get("leave_quota_code") == constants.SL_LEAVE_QUOTA:
                    employee_leave_quota[constants.SL_QUOTA] = float(leave_quota.get("total_leaves"))
                    employee_leave_quota[constants.SL_QUOTA_AVAILED] = float(leave_quota.get("total_leaves")) - float(leave_quota.get("available_leaves"))
                if leave_quota.get("leave_quota_code") == constants.CL_LEAVE_QUOTA:
                    employee_leave_quota[constants.CL_QUOTA] = float(leave_quota.get("total_leaves"))
                    employee_leave_quota[constants.CL_QUOTA_AVAILED] = float(leave_quota.get("total_leaves")) - float(leave_quota.get("available_leaves"))

            # Get ZV (DOJ) from CET
            cet_response = requests.post(config.get_edp_employee_details, headers=request.headers, data=json.dumps(employee))
            if not cet_response:
                return JsonResponse(return_object_func(constants.ERROR_STATUS_CODE, message.SERVER_ERROR_MESSAGE, {}), safe=False)
            if cet_response.status_code != constants.SUCCESS_STATUS_CODE:
                return JsonResponse(return_object_func(constants.ERROR_STATUS_CODE, message.GET_CET_DATA_FAILED, {}), safe=False)
            cet_response = cet_response.json()
            user_details = cet_response.get('user_details')
            tml_group_joining_date = user_details[0]['tml_group_joining_date']
            if tml_group_joining_date:
                employee_leave_quota["doj"] = datetime.strptime(tml_group_joining_date, "%Y-%m-%dT%H:%M:%SZ").date()
            reportees_leave_quota.append(employee_leave_quota)
        print("reportees_leave_quota", reportees_leave_quota)
        return JsonResponse(return_object_func(constants.SUCCESS_STATUS_CODE, message.SUCCESS_RETIVED_DATA, reportees_leave_quota))
    except Exception as error:
        print_error_v1("get_reportee_availed_leaves_data", error)
        return JsonResponse(return_object_func(constants.ERROR_STATUS_CODE, message.SOMETHING_WENT_WRONG, {}), safe=False)
    

# Method: generate_attendance_reports
# Author: Mahesh Shendage
# Description: This method will generate attendance reports for employee
@csrf_exempt
def generate_attendance_reports(request):
    try:
        user_request = json.loads(request.body)
        if not all(key in user_request and user_request[key] for key in constants.ATTENDANCE_ENQUIRY):
            return JsonResponse(return_object_func(constants.HTTP_400_BAD_REQUEST, message.INVALID_REQUEST_BODY_V1, {}))
        
        week_offs = []
        public_holidays = []
        format = '%Y-%m-%d'
        emp_id = f'{(int(user_request["emp_id"])):08}'
        from_date = user_request["from_date"]
        to_date = user_request["to_date"]
        date_of_joining = user_request["date_of_joining"]

        # Get todays date
        today_date = datetime.now().date()

        # Calculate the date 3 months ago from today
        three_months_ago = today_date - relativedelta(months=3)

        # Check if from_date is within 3 months of date_of_joining
        date_of_joining = datetime.strptime(date_of_joining, format).date()
        from_date = datetime.strptime(from_date, format).date()
        to_date = datetime.strptime(to_date, format).date()

        if three_months_ago <= date_of_joining <= from_date:
            from_date = date_of_joining
        
        # from_date condition for todays and three month prior check
        if not (three_months_ago <= from_date <= today_date):
            return JsonResponse(return_object_func(constants.HTTP_400_BAD_REQUEST, message.FROM_DATE_ERROR, {}))
        
        # to_date condition for todays and three month prior check
        if not (from_date <= to_date <= today_date):
            return JsonResponse(return_object_func(constants.HTTP_400_BAD_REQUEST, message.TO_DATE_ERROR, {}))

        headers = {'content-type': 'text/xml'}
        request_body = common_request_body.attendance_enquiry_request_body
        request_body = request_body.replace("emp_id", emp_id)
        request_body = request_body.replace("from_date", str(from_date))
        request_body = request_body.replace("to_date", str(to_date))
        response = requests.post(config.attendance_enquiry_request_url, data=request_body, headers=headers, auth=(config.cv_sap_webservice_id, config.cv_sap_webservice_password))

        if not (response and response.status_code == 200 and response.content):
            return JsonResponse(return_object_func(constants.HTTP_500_INTERNAL_SERVER_ERROR, message.SAP_RESPONSE_ERROR, {}))

        attendance_details_sap = json.dumps(xmltodict.parse(response.content))
        attendance_details_sap_json = json.loads(attendance_details_sap)
        attendance_details = attendance_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0016Response']['OUTPUT']['item']

        # check if single record for attendance enquiry
        is_single_attendance_enquiry = isinstance(attendance_details, dict)
        if is_single_attendance_enquiry == False:
            for data in attendance_details:
                # This is to make date in YYYY-MM-DD format
                if 'LDATE' in data:
                    date = data['LDATE'].strip()
                    data['LDATE'] = date[:4] + "-" + date[4:6] + "-" + date[6:]

                    # This is to get week off list in selected month
                    if ('DAY_TYPE' in data and data['DAY_TYPE'] == "O"):
                        week_offs.append(data['LDATE'])

                    # This is to get public holidays list in selected month
                    if ('DAY_TYPE' in data and data['DAY_TYPE'] == "P"):
                        public_holidays.append(data['LDATE'])

            attendance_enquiry_details = attendance_details
            attendance_week_offs = week_offs
            attendance_public_holidays = public_holidays
            for attendance_index in range(len(attendance_enquiry_details)):
                attendance_date = attendance_enquiry_details[attendance_index]['LDATE']
                first_half_attendance = attendance_enquiry_details[attendance_index]['FH']
                second_half_attendance = attendance_enquiry_details[attendance_index]['SH']
                attendance_enquiry_details[attendance_index]['start'] = attendance_enquiry_details[attendance_index]['LDATE'] + ' 00:00'
                attendance_enquiry_details[attendance_index]['end'] = attendance_enquiry_details[attendance_index]['LDATE'] + ' 23:59'

                if attendance_date in attendance_week_offs:
                    attendance_enquiry_details[attendance_index]['title'] = constants.WEEKLY_OFF_TEXT
                    attendance_enquiry_details[attendance_index]['reason'] = ""
                    continue

                if attendance_date in attendance_public_holidays:
                    attendance_enquiry_details[attendance_index]['title'] = constants.PUBLIC_HOLIDAY_TEXT
                    attendance_enquiry_details[attendance_index]['reason'] = ""
                    continue

                leave_details= LeaveRequestsEDP.objects.filter(requestor_emp_id=emp_id, from_date__lte=attendance_date, to_date__gte=attendance_date,is_deleted=False).first()
                if leave_details:
                    leave_status = leave_details.leave_status
                    leave_status_text = LeaveStatus.objects.filter(leave_status_code=leave_status).first()
                    attendance_enquiry_details[attendance_index]['title'] = leave_status_text.leave_status_text
                    attendance_enquiry_details[attendance_index]['reason'] = leave_details.reason
                else:
                    print('yes inside')
                    if not first_half_attendance is None and not second_half_attendance is None:
                        leave_status_text = 'FH: ' + first_half_attendance + '\n' + 'SH: ' + second_half_attendance +'\n'
                        attendance_enquiry_details[attendance_index]['title'] = leave_status_text
                        attendance_enquiry_details[attendance_index]['reason'] = ""
                    elif first_half_attendance is None:
                        if not second_half_attendance is None:
                            leave_status_text = 'FH: ' + second_half_attendance 
                            attendance_enquiry_details[attendance_index]['title'] = leave_status_text
                            attendance_enquiry_details[attendance_index]['reason'] = ""
                        else:
                            attendance_enquiry_details[attendance_index]['title'] = ""
                            attendance_enquiry_details[attendance_index]['reason'] = ""
                    elif second_half_attendance is None:
                        if not first_half_attendance is None:
                            leave_status_text = 'SH: ' + first_half_attendance 
                            attendance_enquiry_details[attendance_index]['title'] = leave_status_text
                            attendance_enquiry_details[attendance_index]['reason'] = ""
                        else:
                            attendance_enquiry_details[attendance_index]['title'] = ""
                            attendance_enquiry_details[attendance_index]['reason'] = ""
                    else:
                        attendance_enquiry_details[attendance_index]['title'] = ""
                        attendance_enquiry_details[attendance_index]['reason'] = ""

            return JsonResponse(return_object_func(constants.HTTP_200_OK, message.SUCCESS_RETIVED_DATA, attendance_details))
    
    except Exception as error:
        print_error_v1("generate_attendance_reports", error)
        return JsonResponse(return_object_func(constants.HTTP_500_INTERNAL_SERVER_ERROR, message.INTERNAL_SERVER_ERROR, {}))