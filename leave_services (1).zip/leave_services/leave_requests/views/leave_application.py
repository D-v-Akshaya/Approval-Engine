from django.http import JsonResponse
from ..models import *
import json
from django.views.decorators.csrf import csrf_exempt
from django.core import serializers
from datetime import datetime, date, timedelta
import os,base64
from pytz import timezone
from html2image import Html2Image
from datetime import time
import uuid
import xmltodict
import requests
from xml.sax.saxutils import escape
from django.db import transaction
import calendar
from django.db.models import Q
from django.core.mail import send_mail, EmailMessage, EmailMultiAlternatives
from django.core import mail
from django.core.paginator import Paginator
from django.db import connection
from collections import namedtuple
from configuration import config
from configuration import common_request_body
from configuration import constants
from configuration import message
from configuration import template
from configuration import message as custom_messages
from common_functions import *
import csv
session = requests.Session()
import re

######################################### Leave Listing Section Start #######################################
# This function is to get leave quota


@csrf_exempt
def get_leave_quota(request):
    try:
        leave_quota = []
        active_quota_code = []
        user_data = json.loads(request.body)
        # To check if employee id is present in json or not
        if user_data["emp_id"] != "":
            emp_id = user_data["emp_id"]
        else:
            result = {
                "status_code": "500",
                "message": "Invalid employee id"
            }
            return JsonResponse(result, safe=False)

        # This is to get current year IST
        active_year_details = ActiveYear.objects.filter(is_active=True).first()
        current_year_ist = int(active_year_details.active_year)
        # current_year_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).year

        valid_from = str(current_year_ist) + "-01-01"
        valid_to = str(current_year_ist) + "-12-31"

        # To get leave quota from SAP
        response = get_leave_quota_sap_request(emp_id, valid_from, valid_to)

        # This is to check wheather th response is in string
        is_string = isinstance(response, str)
        if is_string == True:
            result = {
                "status_code": "500",
                "message": "Unable to fetch quota details"
            }
            return JsonResponse(result, safe=False)

        # This is when sap webservices gives success as response
        if response.status_code == 200:
            leave_quota_details_sap = json.dumps(
                xmltodict.parse(response.content))
            leave_quota_details_sap_json = json.loads(leave_quota_details_sap)

            # check if single record for leave quota
            is_single_leave_quota = isinstance(
                leave_quota_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0014Response']['QUOTA_OVERVIEW']['item'], dict)

            if is_single_leave_quota == False:
                # This is to delete leave quota
                leave_quota_details = LeaveQuota.objects.filter(emp_id=emp_id)
                if leave_quota_details:
                    leave_quota_details.delete()

                # This is reset active leave quota code
                active_quota_details = ActiveQuotaDetails.objects.filter(
                    emp_id=emp_id).first()
                if active_quota_details:
                    active_quota_details.delete()

                for data in leave_quota_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0014Response']['QUOTA_OVERVIEW']['item']:
                    quota_value = 0
                    display_quota_value = 0

                    # This is to neglect first item in the body
                    if not (data['KTEXT'] == "" or data['KTEXT'] == None):
                        total_leaves = data['ANZHL']
                        display_total_leaves = data['ANZHL']
                        available_leaves = float(data['ANZHL_CLOSE'])
                        display_available_leaves = data['ANZHL_CLOSE']
                        quota_valid_from = data['BEGDA']
                        quota_valid_to = data['ENDDA']

                        # to get leave quoto text
                        leave_quota_code = data['KTEXT'].strip()
                        leave_quota_details = Quota.objects.filter(
                            quota_code=leave_quota_code).first()
                        if leave_quota_details:
                            leave_quota_text = leave_quota_details.quota_text
                        else:
                            leave_quota_text = ""

                        # # This is set active leave quota code
                        active_quota_code.append(leave_quota_code)

                        unique_quota_id = emp_id + "-" + leave_quota_code + \
                            "-" + quota_valid_from + "-" + quota_valid_to

                        if available_leaves != 0:
                            # This is to find quota applicable leave categories
                            leave_category_details = QuotaLeaveCategoryMapping.objects.filter(
                                quota_code=leave_quota_code)
                            if leave_category_details:
                                leave_category_details_json = get_serialize_data(
                                    leave_category_details)
                                for data in leave_category_details_json:
                                    total_days = 0

                                    # #This is to calulate availble leave quota against leave applied from edp
                                    # leave_history_edp = LeaveRequestsEDP.objects.filter(requestor_emp_id = emp_id ,leave_category = data['leave_category'],from_date__year = current_year_ist,is_deleted = False).exclude(Q(leave_status = "2") | Q(leave_status = "3") | Q(leave_status = "4") |Q(leave_status = "5") | Q(leave_status = "6") | Q(leave_status = "7"))
                                    # if leave_history_edp:
                                    #     leave_history_edp_json = get_serialize_data(leave_history_edp)

                                    #     for data in leave_history_edp_json:
                                    #         if not (data['total_days'] == "" or data['total_days'] == None):
                                    #             total_days = total_days + float(data['total_days'])

                                    # This is to calulate availble leave quota against leave applied from edp
                                    leave_history_edp = LeaveRequestsEDP.objects.filter(
                                        Q(requestor_emp_id=emp_id, leave_category=data['leave_category'], from_date__year=current_year_ist,
                                          is_deleted=False, from_date__gte=quota_valid_from, to_date__lte=quota_valid_to, unique_quota_id=unique_quota_id)
                                        # Q(requestor_emp_id = emp_id ,leave_category = data['leave_category'],from_date__year = current_year_ist,is_deleted = False,from_date__gte = quota_valid_to, to_date__lte = quota_valid_to,unique_quota_id = unique_quota_id)
                                        # Q(requestor_emp_id = emp_id ,leave_category = data['leave_category'],from_date__year = current_year_ist,is_deleted = False,from_date__lte = quota_valid_from, to_date__gte = quota_valid_to,unique_quota_id = unique_quota_id)
                                    ).exclude(Q(leave_status="2") | Q(leave_status="3") | Q(leave_status="4") | Q(leave_status="5") | Q(leave_status="6") | Q(leave_status="7")).order_by("from_date")

                                    if leave_history_edp:
                                        leave_history_edp_json = get_serialize_data(
                                            leave_history_edp)

                                        for data in leave_history_edp_json:
                                            if not (data['total_days'] == "" or data['total_days'] == None):
                                                total_days = total_days + \
                                                    float(data['total_days'])

                                    available_leaves = available_leaves - total_days

                            # This is to haldle divide by zero error
                            if (total_leaves == "0" or total_leaves == "" or total_leaves == None or total_leaves == "0.0"):
                                quota_value = 0
                                display_quota_value = 0
                            else:
                                quota_value = available_leaves / \
                                    float(total_leaves)
                                display_quota_value = float(
                                    display_available_leaves)/float(display_total_leaves)

                        # This is to insert into leave quota table
                        leave_quota_details = LeaveQuota(
                            leave_quota_id=uuid.uuid4(),
                            unique_quota_id=unique_quota_id,
                            emp_id=emp_id,
                            quota_code=leave_quota_code,
                            quota_valid_from=quota_valid_from,
                            quota_valid_to=quota_valid_to,
                            total_leaves=total_leaves,
                            available_leaves=str(available_leaves),
                            created_date_time=datetime.now(),
                            modified_date_time=datetime.now(),
                            created_by=emp_id,
                            modified_by=emp_id
                        )
                        leave_quota_details.save()

                        leave_categrory_color_code = ""
                        leave_category_color_response = Quota.objects.filter(quota_code=leave_quota_code).first()
                        if leave_category_color_response:
                            leave_categrory_color_code = leave_category_color_response.quota_color_text
                            
                        quota_data = {
                            "leave_quota_code": leave_quota_code,
                            "leave_quota_text": leave_quota_text,
                            "quota_valid_from": str(quota_valid_from),
                            "quota_valid_to": str(quota_valid_to),
                            "total_leaves": display_total_leaves,
                            "available_leaves": display_available_leaves,
                            "quota_value": display_quota_value,
                            "leave_category_color":leave_categrory_color_code
                        }
                        leave_quota.append(quota_data)

                # This is to add active leave quota codes in table
                active_quota_details = ActiveQuotaDetails(
                    active_quota_details_id=uuid.uuid4(),
                    emp_id=emp_id,
                    active_quota_code=active_quota_code,
                    created_date_time=datetime.now(),
                    modified_date_time=datetime.now(),
                    created_by=emp_id,
                    modified_by=emp_id
                )
                active_quota_details.save()

                result = {
                    "status_code": "200",
                    "message": "",
                    "leave_quota_details": leave_quota
                }
                return JsonResponse(result, safe=False)
            else:
                # result = {
                #     "status_code" : "500",
                #     "message":"Unable to fetch quota details"
                # }
                # return JsonResponse(result,safe=False)
                leave_quota_details = LeaveQuota.objects.filter(emp_id=emp_id)
                if leave_quota_details:
                    for data in leave_quota_details:
                        quota_details = Quota.objects.filter(
                            quota_code=data.quota_code).first()
                        quota_data = {
                            "leave_quota_code": data.quota_code,
                            "leave_quota_text": quota_details.quota_text,
                            "total_leaves": data.total_leaves,
                            "available_leaves": data.available_leaves,
                            "quota_value": float(data.available_leaves)/float(data.total_leaves)
                        }
                        leave_quota.append(quota_data)

                    result = {
                        "status_code": "300",
                        "message": "Unable to fetch latest quota details",
                        "leave_quota_details": leave_quota
                    }
                    return JsonResponse(result, safe=False)
                else:
                    result = {
                        "status_code": "500",
                        "message": "Unable to fetch latest quota details"
                    }
                    return JsonResponse(result, safe=False)
        else:
            # result = {
            #     "status_code" : "500",
            #     "message":"Unable to fetch quota details"
            # }
            # return JsonResponse(result,safe=False)
            leave_quota_details = LeaveQuota.objects.filter(emp_id=emp_id)
            if leave_quota_details:
                for data in leave_quota_details:
                    quota_details = Quota.objects.filter(
                        quota_code=data.quota_code).first()
                    quota_data = {
                        "leave_quota_code": data.quota_code,
                        "leave_quota_text": quota_details.quota_text,
                        "total_leaves": data.total_leaves,
                        "available_leaves": data.available_leaves,
                        "quota_value": float(data.available_leaves)/float(data.total_leaves)
                    }
                    leave_quota.append(quota_data)
                result = {
                    "status_code": "300",
                    "message": "Unable to fetch latest quota details",
                    "leave_quota_details": leave_quota
                }
                return JsonResponse(result, safe=False)
            else:
                result = {
                    "status_code": "500",
                    "message": "Unable to fetch latest quota details"
                }
                return JsonResponse(result, safe=False)

    except (Exception) as error:
        print(error)
        result = {
            "status_code": "500",
            "message": "Unable to fetch latest quota details"
        }
        return JsonResponse(result, safe=False)

# This function is to get leave quota


@csrf_exempt
def get_leave_quota_sap_request(emp_id, valid_from, valid_to):
    headers = {'content-type': 'text/xml'}
    body = common_request_body.leave_quota_request_body
    body = body.replace("emp_id", emp_id)
    body = body.replace("valid_from", valid_from)
    body = body.replace("valid_to", valid_to)
    try:
        response = requests.post(config.leave_quota_request_url, data=body, headers=headers, timeout=5, auth=(
            config.cv_sap_webservice_id, config.cv_sap_webservice_password))
        return response
    except (Exception) as error:
        print(error)
        response = "408"
        return response

# This function is to get leave requests


@csrf_exempt
def get_leave_requests(request):
    try:
        user_data = json.loads(request.body)
        # To check if employee id is present in json or not
        if user_data["emp_id"] != "":
            emp_id = user_data["emp_id"]
        else:
            result = {
                "status_code": "500",
                "message": "Unable to fetch leave history"
            }
            return JsonResponse(result, safe=False)
        # This is to get current year IST
        active_year_details = ActiveYear.objects.filter(is_active=True).first()
        current_year_ist = int(active_year_details.active_year)
        # current_year_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).year
        current_month_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).month
        print(current_month_ist)

        # this is to filter leave request based on leave category and leave status
        if 'filter_type' in user_data:
            leave_history_sap = get_leave_history_sap(request)
            if leave_history_sap['status_code'] == "500":
                result = {
                    "status_code": "500",
                    "message": "Unable to fetch latest data"
                }
                return JsonResponse(result, safe=False)
            if (user_data['leave_category_code'] == "All" and user_data['leave_status_code'] == "All" and user_data['month'] == "All"):
                # leave_requests_edp = LeaveRequestsEDP.objects.filter(requestor_emp_id = emp_id,from_date__year = current_year_ist,is_deleted=False).exclude(leave_status = "2").order_by('-from_date')
                # leave_requests_sap = LeaveRequestsSAP.objects.filter(requestor_emp_id = emp_id,is_deleted=False).order_by('-from_date')
                # leave_requests_details = leave_requests_edp.union(leave_requests_sap)
                # leave_requests_details = leave_requests_details.order_by('-from_date')

                leave_requests_edp = LeaveRequestsEDP.objects.filter(
                    requestor_emp_id=emp_id, from_date__year=current_year_ist, is_deleted=False).exclude(leave_status="2").order_by('-from_date')
                leave_requests_sap = LeaveRequestsSAP.objects.filter(
                    requestor_emp_id=emp_id, from_date__year=current_year_ist, is_deleted=False).order_by('-from_date')

                leave_requests_edp_pending_delete = LeaveRequestsEDP.objects.filter(
                    requestor_emp_id=emp_id, from_date__year=current_year_ist, is_deleted=False)
                leave_requests_edp_pending_delete = leave_requests_edp_pending_delete.filter(
                    Q(leave_status="5") | Q(leave_status="6") | Q(leave_status="9"))
                for data in leave_requests_edp_pending_delete:
                    leave_requests_sap = leave_requests_sap.exclude(
                        from_date=data.from_date)

                leave_requests_details = leave_requests_edp.union(
                    leave_requests_sap)
                leave_requests_details = leave_requests_details.order_by(
                    '-from_date')

            elif (user_data['leave_category_code'] == "All" and user_data[' '] != "All" and user_data['month'] == "All"):
                # leave_requests_edp = LeaveRequestsEDP.objects.filter(requestor_emp_id = emp_id,leave_status = user_data['leave_status_code'],from_date__year = current_year_ist,is_deleted=False).exclude(leave_status = "2").order_by('-from_date')
                # leave_requests_sap = LeaveRequestsSAP.objects.filter(requestor_emp_id = emp_id,leave_status = user_data['leave_status_code'],is_deleted=False).order_by('-from_date')
                # leave_requests_details = leave_requests_edp.union(leave_requests_sap)
                # leave_requests_details = leave_requests_details.order_by('-from_date')

                leave_requests_edp = LeaveRequestsEDP.objects.filter(
                    requestor_emp_id=emp_id, leave_status=user_data['leave_status_code'], from_date__year=current_year_ist, is_deleted=False).exclude(leave_status="2").order_by('-from_date')
                leave_requests_sap = LeaveRequestsSAP.objects.filter(
                    requestor_emp_id=emp_id, leave_status=user_data['leave_status_code'], from_date__year=current_year_ist, is_deleted=False).order_by('-from_date')

                leave_requests_edp_pending_delete = LeaveRequestsEDP.objects.filter(
                    requestor_emp_id=emp_id, from_date__year=current_year_ist, is_deleted=False)
                leave_requests_edp_pending_delete = leave_requests_edp_pending_delete.filter(
                    Q(leave_status="5") | Q(leave_status="6") | Q(leave_status="9"))
                for data in leave_requests_edp_pending_delete:
                    leave_requests_sap = leave_requests_sap.exclude(
                        from_date=data.from_date)

                leave_requests_details = leave_requests_edp.union(
                    leave_requests_sap)
                leave_requests_details = leave_requests_details.order_by(
                    '-from_date')

            elif (user_data['leave_status_code'] == "All" and user_data['leave_category_code'] != "All" and user_data['month'] == "All"):
                # leave_requests_edp = LeaveRequestsEDP.objects.filter(requestor_emp_id = emp_id,leave_category = user_data['leave_category_code'],from_date__year = current_year_ist,is_deleted=False).exclude(leave_status = "2").order_by('-from_date')
                # leave_requests_sap = LeaveRequestsSAP.objects.filter(requestor_emp_id = emp_id,leave_category = user_data['leave_category_code'],is_deleted=False).order_by('-from_date')
                # leave_requests_details = leave_requests_edp.union(leave_requests_sap)
                # leave_requests_details = leave_requests_details.order_by('-from_date')

                leave_requests_edp = LeaveRequestsEDP.objects.filter(
                    requestor_emp_id=emp_id, leave_category=user_data['leave_category_code'], from_date__year=current_year_ist, is_deleted=False).exclude(leave_status="2").order_by('-from_date')
                leave_requests_sap = LeaveRequestsSAP.objects.filter(
                    requestor_emp_id=emp_id, leave_category=user_data['leave_category_code'], from_date__year=current_year_ist, is_deleted=False).order_by('-from_date')

                leave_requests_edp_pending_delete = LeaveRequestsEDP.objects.filter(
                    requestor_emp_id=emp_id, from_date__year=current_year_ist, is_deleted=False)
                leave_requests_edp_pending_delete = leave_requests_edp_pending_delete.filter(
                    Q(leave_status="5") | Q(leave_status="6") | Q(leave_status="9"))
                for data in leave_requests_edp_pending_delete:
                    leave_requests_sap = leave_requests_sap.exclude(
                        from_date=data.from_date)

                leave_requests_details = leave_requests_edp.union(
                    leave_requests_sap)
                leave_requests_details = leave_requests_details.order_by(
                    '-from_date')

            elif (user_data['leave_category_code'] == "All" and user_data['leave_status_code'] == "All" and user_data['month'] != "All"):
                # leave_requests_edp = LeaveRequestsEDP.objects.filter(requestor_emp_id = emp_id,from_date__year = current_year_ist,is_deleted=False).exclude(leave_status = "2").order_by('-from_date')
                # leave_requests_sap = LeaveRequestsSAP.objects.filter(requestor_emp_id = emp_id,is_deleted=False).order_by('-from_date')
                # leave_requests_details = leave_requests_edp.union(leave_requests_sap)
                # leave_requests_details = leave_requests_details.order_by('-from_date')

                leave_requests_edp = LeaveRequestsEDP.objects.filter(Q(requestor_emp_id=emp_id, from_date__year=current_year_ist, from_date__month=user_data['month'], is_deleted=False) | Q(
                    requestor_emp_id=emp_id, from_date__year=current_year_ist, to_date__month=user_data['month'], is_deleted=False)).exclude(leave_status="2").order_by('-from_date')
                leave_requests_sap = LeaveRequestsSAP.objects.filter(Q(requestor_emp_id=emp_id, from_date__year=current_year_ist, from_date__month=user_data['month'], is_deleted=False) | Q(
                    requestor_emp_id=emp_id, from_date__year=current_year_ist, to_date__month=user_data['month'], is_deleted=False)).order_by('-from_date')

                leave_requests_edp_pending_delete = LeaveRequestsEDP.objects.filter(Q(requestor_emp_id=emp_id, from_date__year=current_year_ist, from_date__month=user_data['month'], is_deleted=False) | Q(
                    requestor_emp_id=emp_id, from_date__year=current_year_ist, to_date__month=user_data['month'], is_deleted=False))
                leave_requests_edp_pending_delete = leave_requests_edp_pending_delete.filter(
                    Q(leave_status="5") | Q(leave_status="6") | Q(leave_status="9"))
                for data in leave_requests_edp_pending_delete:
                    leave_requests_sap = leave_requests_sap.exclude(
                        from_date=data.from_date)

                leave_requests_details = leave_requests_edp.union(
                    leave_requests_sap)
                leave_requests_details = leave_requests_details.order_by(
                    '-from_date')

            elif (user_data['leave_category_code'] == "All" and user_data['leave_status_code'] != "All" and user_data['month'] != "All"):
                # leave_requests_edp = LeaveRequestsEDP.objects.filter(requestor_emp_id = emp_id,leave_status = user_data['leave_status_code'],from_date__year = current_year_ist,is_deleted=False).exclude(leave_status = "2").order_by('-from_date')
                # leave_requests_sap = LeaveRequestsSAP.objects.filter(requestor_emp_id = emp_id,leave_status = user_data['leave_status_code'],is_deleted=False).order_by('-from_date')
                # leave_requests_details = leave_requests_edp.union(leave_requests_sap)
                # leave_requests_details = leave_requests_details.order_by('-from_date')

                leave_requests_edp = LeaveRequestsEDP.objects.filter(Q(requestor_emp_id=emp_id, leave_status=user_data['leave_status_code'], from_date__year=current_year_ist, from_date__month=user_data['month'], is_deleted=False) | Q(
                    requestor_emp_id=emp_id, leave_status=user_data['leave_status_code'], from_date__year=current_year_ist, to_date__month=user_data['month'], is_deleted=False)).exclude(leave_status="2").order_by('-from_date')
                leave_requests_sap = LeaveRequestsSAP.objects.filter(Q(requestor_emp_id=emp_id, leave_status=user_data['leave_status_code'], from_date__year=current_year_ist, from_date__month=user_data['month'], is_deleted=False) | Q(
                    requestor_emp_id=emp_id, leave_status=user_data['leave_status_code'], from_date__year=current_year_ist, to_date__month=user_data['month'], is_deleted=False)).order_by('-from_date')

                leave_requests_edp_pending_delete = LeaveRequestsEDP.objects.filter(Q(requestor_emp_id=emp_id, from_date__year=current_year_ist, from_date__month=user_data['month'], is_deleted=False) | Q(
                    requestor_emp_id=emp_id, from_date__year=current_year_ist, to_date__month=user_data['month'], is_deleted=False))
                leave_requests_edp_pending_delete = leave_requests_edp_pending_delete.filter(
                    Q(leave_status="5") | Q(leave_status="6") | Q(leave_status="9"))
                for data in leave_requests_edp_pending_delete:
                    leave_requests_sap = leave_requests_sap.exclude(
                        from_date=data.from_date)

                leave_requests_details = leave_requests_edp.union(
                    leave_requests_sap)
                leave_requests_details = leave_requests_details.order_by(
                    '-from_date')

            elif (user_data['leave_status_code'] == "All" and user_data['leave_category_code'] != "All" and user_data['month'] != "All"):
                # leave_requests_edp = LeaveRequestsEDP.objects.filter(requestor_emp_id = emp_id,leave_category = user_data['leave_category_code'],from_date__year = current_year_ist,is_deleted=False).exclude(leave_status = "2").order_by('-from_date')
                # leave_requests_sap = LeaveRequestsSAP.objects.filter(requestor_emp_id = emp_id,leave_category = user_data['leave_category_code'],is_deleted=False).order_by('-from_date')
                # leave_requests_details = leave_requests_edp.union(leave_requests_sap)
                # leave_requests_details = leave_requests_details.order_by('-from_date')

                leave_requests_edp = LeaveRequestsEDP.objects.filter(Q(requestor_emp_id=emp_id, leave_category=user_data['leave_category_code'], from_date__year=current_year_ist, from_date__month=user_data['month'], is_deleted=False) | Q(
                    requestor_emp_id=emp_id, leave_category=user_data['leave_category_code'], from_date__year=current_year_ist, to_date__month=user_data['month'], is_deleted=False)).exclude(leave_status="2").order_by('-from_date')
                leave_requests_sap = LeaveRequestsSAP.objects.filter(Q(requestor_emp_id=emp_id, leave_category=user_data['leave_category_code'], from_date__year=current_year_ist, from_date__month=user_data['month'], is_deleted=False) | Q(
                    requestor_emp_id=emp_id, leave_category=user_data['leave_category_code'], from_date__year=current_year_ist, to_date__month=user_data['month'], is_deleted=False)).order_by('-from_date')

                leave_requests_edp_pending_delete = LeaveRequestsEDP.objects.filter(Q(requestor_emp_id=emp_id, from_date__year=current_year_ist, from_date__month=user_data['month'], is_deleted=False) | Q(
                    requestor_emp_id=emp_id, from_date__year=current_year_ist, to_date__month=user_data['month'], is_deleted=False))
                leave_requests_edp_pending_delete = leave_requests_edp_pending_delete.filter(
                    Q(leave_status="5") | Q(leave_status="6") | Q(leave_status="9"))
                for data in leave_requests_edp_pending_delete:
                    leave_requests_sap = leave_requests_sap.exclude(
                        from_date=data.from_date)

                leave_requests_details = leave_requests_edp.union(
                    leave_requests_sap)
                leave_requests_details = leave_requests_details.order_by(
                    '-from_date')

            elif (user_data['leave_status_code'] != "All" and user_data['leave_category_code'] != "All" and user_data['month'] == "All"):
                # leave_requests_edp = LeaveRequestsEDP.objects.filter(requestor_emp_id = emp_id,leave_category = user_data['leave_category_code'],from_date__year = current_year_ist,is_deleted=False).exclude(leave_status = "2").order_by('-from_date')
                # leave_requests_sap = LeaveRequestsSAP.objects.filter(requestor_emp_id = emp_id,leave_category = user_data['leave_category_code'],is_deleted=False).order_by('-from_date')
                # leave_requests_details = leave_requests_edp.union(leave_requests_sap)
                # leave_requests_details = leave_requests_details.order_by('-from_date')

                leave_requests_edp = LeaveRequestsEDP.objects.filter(requestor_emp_id=emp_id, leave_category=user_data['leave_category_code'], leave_status=user_data[
                                                                     'leave_status_code'], from_date__year=current_year_ist, is_deleted=False).exclude(leave_status="2").order_by('-from_date')
                leave_requests_sap = LeaveRequestsSAP.objects.filter(
                    requestor_emp_id=emp_id, leave_category=user_data['leave_category_code'], leave_status=user_data['leave_status_code'], from_date__year=current_year_ist, is_deleted=False).order_by('-from_date')

                leave_requests_edp_pending_delete = LeaveRequestsEDP.objects.filter(
                    requestor_emp_id=emp_id, from_date__year=current_year_ist, is_deleted=False)
                leave_requests_edp_pending_delete = leave_requests_edp_pending_delete.filter(
                    Q(leave_status="5") | Q(leave_status="6") | Q(leave_status="9"))
                for data in leave_requests_edp_pending_delete:
                    leave_requests_sap = leave_requests_sap.exclude(
                        from_date=data.from_date)

                leave_requests_details = leave_requests_edp.union(
                    leave_requests_sap)
                leave_requests_details = leave_requests_details.order_by(
                    '-from_date')

            elif (user_data['leave_status_code'] != "All" and user_data['leave_category_code'] != "All" and user_data['month'] != "All"):
                # leave_requests_edp = LeaveRequestsEDP.objects.filter(requestor_emp_id = emp_id,leave_category = user_data['leave_category_code'],from_date__year = current_year_ist,is_deleted=False).exclude(leave_status = "2").order_by('-from_date')
                # leave_requests_sap = LeaveRequestsSAP.objects.filter(requestor_emp_id = emp_id,leave_category = user_data['leave_category_code'],is_deleted=False).order_by('-from_date')
                # leave_requests_details = leave_requests_edp.union(leave_requests_sap)
                # leave_requests_details = leave_requests_details.order_by('-from_date')

                leave_requests_edp = LeaveRequestsEDP.objects.filter(Q(requestor_emp_id=emp_id, leave_category=user_data['leave_category_code'], leave_status=user_data['leave_status_code'], from_date__year=current_year_ist, from_date__month=user_data['month'], is_deleted=False) | Q(
                    requestor_emp_id=emp_id, leave_category=user_data['leave_category_code'], leave_status=user_data['leave_status_code'], from_date__year=current_year_ist, to_date__month=user_data['month'], is_deleted=False)).exclude(leave_status="2").order_by('-from_date')
                leave_requests_sap = LeaveRequestsSAP.objects.filter(Q(requestor_emp_id=emp_id, leave_category=user_data['leave_category_code'], leave_status=user_data['leave_status_code'], from_date__year=current_year_ist, from_date__month=user_data['month'], is_deleted=False) | Q(
                    requestor_emp_id=emp_id, leave_category=user_data['leave_category_code'], leave_status=user_data['leave_status_code'], from_date__year=current_year_ist, to_date__month=user_data['month'], is_deleted=False)).order_by('-from_date')

                leave_requests_edp_pending_delete = LeaveRequestsEDP.objects.filter(Q(requestor_emp_id=emp_id, from_date__year=current_year_ist, from_date__month=user_data['month'], is_deleted=False) | Q(
                    requestor_emp_id=emp_id, from_date__year=current_year_ist, to_date__month=user_data['month'], is_deleted=False))
                leave_requests_edp_pending_delete = leave_requests_edp_pending_delete.filter(
                    Q(leave_status="5") | Q(leave_status="6") | Q(leave_status="9"))
                for data in leave_requests_edp_pending_delete:
                    leave_requests_sap = leave_requests_sap.exclude(
                        from_date=data.from_date)

                leave_requests_details = leave_requests_edp.union(
                    leave_requests_sap)
                leave_requests_details = leave_requests_details.order_by(
                    '-from_date')

            else:
                # leave_requests_edp = LeaveRequestsEDP.objects.filter(requestor_emp_id = emp_id,leave_category = user_data['leave_category_code'],leave_status = user_data['leave_status_code'],from_date__year = current_year_ist,is_deleted=False).exclude(leave_status = "2").order_by('-from_date')
                # leave_requests_sap = LeaveRequestsSAP.objects.filter(requestor_emp_id = emp_id,leave_category = user_data['leave_category_code'],leave_status = user_data['leave_status_code'],is_deleted=False).order_by('-from_date')
                # leave_requests_details = leave_requests_edp.union(leave_requests_sap)
                # leave_requests_details = leave_requests_details.order_by('-from_date')

                leave_requests_edp = LeaveRequestsEDP.objects.filter(requestor_emp_id=emp_id, leave_category=user_data['leave_category_code'], leave_status=user_data[
                                                                     'leave_status_code'], from_date__year=current_year_ist, is_deleted=False).exclude(leave_status="2").order_by('-from_date')
                leave_requests_sap = LeaveRequestsSAP.objects.filter(
                    requestor_emp_id=emp_id, leave_category=user_data['leave_category_code'], leave_status=user_data['leave_status_code'], from_date__year=current_year_ist, is_deleted=False).order_by('-from_date')

                leave_requests_edp_pending_delete = LeaveRequestsEDP.objects.filter(
                    requestor_emp_id=emp_id, from_date__year=current_year_ist, is_deleted=False)
                leave_requests_edp_pending_delete = leave_requests_edp_pending_delete.filter(
                    Q(leave_status="5") | Q(leave_status="6") | Q(leave_status="9"))
                for data in leave_requests_edp_pending_delete:
                    leave_requests_sap = leave_requests_sap.exclude(
                        from_date=data.from_date)

                leave_requests_details = leave_requests_edp.union(
                    leave_requests_sap)
                leave_requests_details = leave_requests_details.order_by(
                    '-from_date')

        else:
            leave_history_sap = get_leave_history_sap(request)
            if leave_history_sap['status_code'] == "500":
                result = {
                    "status_code": "500",
                    "message": "Unable to fetch latest data"
                }
                return JsonResponse(result, safe=False)

            # leave_requests_edp = LeaveRequestsEDP.objects.filter(requestor_emp_id = emp_id,from_date__year = current_year_ist,is_deleted=False).exclude(leave_status = "2")
            # leave_requests_sap = LeaveRequestsSAP.objects.filter(requestor_emp_id = emp_id,is_deleted=False)
            # leave_requests_details = leave_requests_edp.union(leave_requests_sap)
            # leave_requests_details = leave_requests_details.order_by('-from_date')

            leave_requests_edp = LeaveRequestsEDP.objects.filter(Q(requestor_emp_id=emp_id, from_date__year=current_year_ist, from_date__month=current_month_ist, is_deleted=False) | Q(
                requestor_emp_id=emp_id, from_date__year=current_year_ist, to_date__month=current_month_ist, is_deleted=False)).exclude(leave_status="2")
            leave_requests_sap = LeaveRequestsSAP.objects.filter(Q(requestor_emp_id=emp_id, from_date__year=current_year_ist, from_date__month=current_month_ist, is_deleted=False) | Q(
                requestor_emp_id=emp_id, from_date__year=current_year_ist, to_date__month=current_month_ist, is_deleted=False))

            leave_requests_edp_pending_delete = LeaveRequestsEDP.objects.filter(Q(requestor_emp_id=emp_id, from_date__year=current_year_ist, from_date__month=current_month_ist, is_deleted=False) | Q(
                requestor_emp_id=emp_id, from_date__year=current_year_ist, to_date__month=current_month_ist, is_deleted=False))
            leave_requests_edp_pending_delete = leave_requests_edp_pending_delete.filter(
                Q(leave_status="5") | Q(leave_status="6") | Q(leave_status="9"))
            for data in leave_requests_edp_pending_delete:
                leave_requests_sap = leave_requests_sap.exclude(
                    from_date=data.from_date)

            leave_requests_details = leave_requests_edp.union(
                leave_requests_sap)
            leave_requests_details = leave_requests_details.order_by(
                '-from_date')

        if leave_requests_details:
            leave_requests_details_json = get_serialize_data(
                leave_requests_details)

            for data in leave_requests_details_json:
                # to get leave category text
                leave_category_code = data['leave_category']
                data['leave_category'] = get_extended_leave_category_text(
                    user_data['pa'], user_data['psa'], leave_category_code)
                data['leave_category_code'] = leave_category_code

                # To get leave type text
                leave_type_code = data['leave_type']
                leave_type_details = LeaveType.objects.filter(
                    leave_type_code=leave_type_code).first()
                if leave_type_details:
                    data['leave_type'] = leave_type_details.leave_type_text
                else:
                    data['leave_type'] == ""

                data['leave_type_code'] = leave_type_code

                # To get leave status text
                leave_status_code = data['leave_status']
                leave_status_details = LeaveStatus.objects.filter(
                    leave_status_code=leave_status_code).first()
                if leave_status_details:
                    data['leave_status'] = leave_status_details.leave_status_text
                    data['leave_status_color'] = leave_status_details.leave_status_color
                else:
                    data['leave_status'] == ""
                    data['leave_status_color'] == ""

                data['leave_status_code'] = leave_status_code

                # This is to get reason
                if data['reason'] == "" or data['reason'] == None:
                    # from_date = datetime.strptime(data['from_date'], "%Y-%m-%d").date()
                    # leave_requests_edp = LeaveRequestsEDP.objects.filter(requestor_emp_id = data['requestor_emp_id'],leave_status = "2",from_date = from_date).first()
                    # if leave_requests_edp:
                    #     data['reason'] = leave_requests_edp.reason
                    data['reason'] = ""

            result = {
                "status_code": "200",
                "message": "",
                "data": {
                    "leave_requests": leave_requests_details_json,
                }
            }
            return JsonResponse(result, safe=False)
        else:
            result = {
                "status_code": "200",
                "message": "",
                "data": {
                    "leave_requests": [],
                }
            }
            return JsonResponse(result, safe=False)
    except (Exception) as error:
        print(error)
        result = {
            "status_code": "500",
            "message": "Unable to fetch leave history"
        }
        return JsonResponse(result, safe=False)

# This function is to get leave details from EDP


@csrf_exempt
def get_leave_details(request):
    try:
        user_data = json.loads(request.body)
        token = request.headers['Authorization'].split()[1]
        headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer' + ' ' + token
        }
        print("user_request", user_data)
        from_date = datetime.strptime(
            user_data['from_date'], "%Y-%m-%d").date()
        leave_requests_edp = LeaveRequestsEDP.objects.filter(
            requestor_emp_id=user_data['requestor_emp_id'], from_date=from_date, is_deleted=False).first()
        if leave_requests_edp:
            user = {
                "emp_id": leave_requests_edp.approver_emp_id
            }
            data_to_be_serialized = requests.post(config.get_edp_employee_details, headers=headers, data=json.dumps(user))
            user_details_json = data_to_be_serialized.json()
            print(user_details_json)

            # To add employee name in json
            approver_name = user_details_json['user_details'][0]['CompName']
            reason = leave_requests_edp.reason
            result = {
                "status_code": "200",
                "message": "",
                "reason": reason,
                "approver_name": approver_name
            }
            return JsonResponse(result, safe=False)
        else:
            result = {
                "status_code": "500",
                "message": "Leave is applied from SAP Backend",
            }
            return JsonResponse(result, safe=False)
    except (Exception) as error:
        print(error)
        result = {
            "status_code": "500",
            "message": "Unable to fetch leave details"
        }
        return JsonResponse(result, safe=False)

# This is used to get leave detail for leave approval section
@csrf_exempt
def get_approved_leave_details(request):
    try:
        user_data = json.loads(request.body)
        token = request.headers['Authorization'].split()[1]
        headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer' + ' ' + token
        }
        leave_requests_edp = LeaveRequestsEDP.objects.filter(
            leave_request_id=user_data['leave_request_id']).first()
        if leave_requests_edp:
            user = {
                "emp_id": leave_requests_edp.approver_emp_id
            }
            data_to_be_serialized = requests.post(config.get_edp_employee_details, headers=headers, data=json.dumps(user))
            user_details_json = data_to_be_serialized.json()

            # To add employee name in json
            approver_name = user_details_json['user_details'][0]['CompName']
            reason = leave_requests_edp.reason
            result = {
                "status_code": "200",
                "message": "",
                "reason": reason,
                "approver_name": approver_name
            }
            return JsonResponse(result, safe=False)
        else:
            result = {
                "status_code": "500",
                "message": "Leave is applied from SAP Backend",
            }
            return JsonResponse(result, safe=False)
    except (Exception) as error:
        print(error)
        result = {
            "status_code": "500",
            "message": "Unable to fetch leave details"
        }
        return JsonResponse(result, safe=False)

# This function is to get leave history from SAP
@csrf_exempt
def get_leave_history_sap(request):
    leave_history = []
    user_data = json.loads(request.body)

    # To check if employee id is present in json or not
    if user_data["emp_id"] != "":
        emp_id = user_data["emp_id"]
    else:
        result = {
            "status_code": "500"
        }
        return result

    # This is to get current year IST
    active_year_details = ActiveYear.objects.filter(is_active=True).first()
    current_year_ist = int(active_year_details.active_year)
    # current_year_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).year

    valid_from = str(current_year_ist) + "-01-01"
    valid_to = str(current_year_ist) + "-12-31"

    # To get leave quota from SAP
    response = get_leave_history_sap_request(emp_id, valid_from, valid_to)

    # This is to check wheather th response is in string
    is_string = isinstance(response, str)
    if is_string == True:
        result = {
            "status_code": "500",
        }
        return result

    if response.status_code == 200:
        leave_history_details_sap = json.dumps(
            xmltodict.parse(response.content))
        leave_history_details_sap_json = json.loads(leave_history_details_sap)

        # check if single record for dependent
        is_single_leave_history = isinstance(
            leave_history_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0017Response']['OUTPUT']['item'], dict)

        if is_single_leave_history == False:
            for data in leave_history_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0017Response']['OUTPUT']['item']:
                # This is to neglect first item in the body
                if not (data['LEAVE_CODE'] == "" or data['LEAVE_CODE'] == None):
                    leave_history_data = {
                        "leave_category": data['LEAVE_CODE'],
                        "applied_date": data['APPLIED_DATE'],
                        "from_date": data['BEGDA'],
                        "to_date": data['ENDDA'],
                        "leave_type": data['LEAVE_TYPE'],
                        "total_days": data['TOT_LEAVES'],
                        "approver_emp_id": data['APPROVER'],
                        "leave_status": data['STATUS']
                    }
                    leave_history.append(leave_history_data)

            if leave_history:
                from_datetime = datetime.combine(datetime.strptime(
                    valid_from, "%Y-%m-%d").date(), time.min)
                to_datetime = datetime.combine(datetime.strptime(
                    valid_to, "%Y-%m-%d").date(), time.max)

                leave_history_details = LeaveRequestsSAP.objects.filter(
                    requestor_emp_id=emp_id)
                if leave_history_details:
                    leave_history_details.delete()  # to delete currnet year leave history records

                for data in leave_history:
                    try:
                        leave_status_code = ""
                        leave_status = data['leave_status']
                        leave_status_data = LeaveStatus.objects.filter(
                            leave_status_text=leave_status).first()
                        if leave_status_data:
                            leave_status_code = leave_status_data.leave_status_code

                        leave_history_details = LeaveRequestsSAP(
                            leave_request_id=uuid.uuid4(),
                            requestor_emp_id=emp_id,
                            leave_category=data['leave_category'],
                            applied_date=data['applied_date'],
                            from_date=data['from_date'],
                            to_date=data['to_date'],
                            leave_type=data['leave_type'],
                            total_days=data['total_days'],
                            approver_emp_id=data['approver_emp_id'],
                            leave_status=leave_status_code,
                            is_deleted=False,
                            created_date_time=datetime.now(),
                            modified_date_time=datetime.now(),
                            created_by=emp_id,
                            modified_by=emp_id
                        )
                        leave_history_details.save()
                    except (Exception) as error:
                        print(error)
                        result = {
                            "status_code": "500",
                        }
                        return result
                result = {
                    "status_code": "200",
                }
                return result
            else:
                result = {
                    "status_code": "500",
                }
                return result
        else:
            result = {
                "status_code": "300",
            }
            return result
    else:
        result = {
            "status_code": "500",
        }
        return result

# This function is to get bulk leave history from SAP


@csrf_exempt
def get_bulk_leave_history_sap(request):
    try:
        emp_list = []
        count = 0
        data = json.loads(request.body)

        for value in data:
            emp_list.append(value['emp_id'].strip())

        for emp_id in emp_list:
            leave_history = []
            count += 1
            string = str(count) + " - " + str(emp_id)
            print(string)
            # To check if employee id is present in json or not
            # if user_data["emp_id"] != "":
            #     emp_id = user_data["emp_id"]
            # else:
            #     result = {
            #         "status_code" : "500"
            #     }
            #     return result

            # This is to get current year IST
            active_year_details = ActiveYear.objects.filter(
                is_active=True).first()
            current_year_ist = int(active_year_details.active_year)
            # current_year_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).year

            valid_from = str(current_year_ist) + "-01-01"
            valid_to = str(current_year_ist) + "-12-31"

            # To get leave quota from SAP
            response = get_leave_history_sap_request(
                emp_id, valid_from, valid_to)

            # This is to check wheather th response is in string
            is_string = isinstance(response, str)
            if is_string == True:
                result = {
                    "status_code": "500",
                }
                return result

            if response.status_code == 200:
                leave_history_details_sap = json.dumps(
                    xmltodict.parse(response.content))
                leave_history_details_sap_json = json.loads(
                    leave_history_details_sap)

                # check if single record for dependent
                is_single_leave_history = isinstance(
                    leave_history_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0017Response']['OUTPUT']['item'], dict)

                if is_single_leave_history == False:
                    for data in leave_history_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0017Response']['OUTPUT']['item']:
                        # This is to neglect first item in the body
                        if not (data['LEAVE_CODE'] == "" or data['LEAVE_CODE'] == None):
                            leave_history_data = {
                                "leave_category": data['LEAVE_CODE'],
                                "applied_date": data['APPLIED_DATE'],
                                "from_date": data['BEGDA'],
                                "to_date": data['ENDDA'],
                                "leave_type": data['LEAVE_TYPE'],
                                "total_days": data['TOT_LEAVES'],
                                "approver_emp_id": data['APPROVER'],
                                "leave_status": data['STATUS']
                            }
                            leave_history.append(leave_history_data)

                    if leave_history:
                        from_datetime = datetime.combine(datetime.strptime(
                            valid_from, "%Y-%m-%d").date(), time.min)
                        to_datetime = datetime.combine(datetime.strptime(
                            valid_to, "%Y-%m-%d").date(), time.max)

                        leave_history_details = LeaveRequestsSAP.objects.filter(
                            requestor_emp_id=emp_id)
                        if leave_history_details:
                            leave_history_details.delete()  # to delete currnet year leave history records

                        for data in leave_history:
                            try:
                                leave_status_code = ""
                                leave_status = data['leave_status']
                                leave_status_data = LeaveStatus.objects.filter(
                                    leave_status_text=leave_status).first()
                                if leave_status_data:
                                    leave_status_code = leave_status_data.leave_status_code

                                leave_history_details = LeaveRequestsSAP(
                                    leave_request_id=uuid.uuid4(),
                                    requestor_emp_id=emp_id,
                                    leave_category=data['leave_category'],
                                    applied_date=data['applied_date'],
                                    from_date=data['from_date'],
                                    to_date=data['to_date'],
                                    leave_type=data['leave_type'],
                                    total_days=data['total_days'],
                                    approver_emp_id=data['approver_emp_id'],
                                    leave_status=leave_status_code,
                                    is_deleted=False,
                                    created_date_time=datetime.now(),
                                    modified_date_time=datetime.now(),
                                    created_by=emp_id,
                                    modified_by=emp_id
                                )
                                leave_history_details.save()
                            except (Exception) as error:
                                print(error)
                                result = {
                                    "status_code": "500",
                                }
                                # return result
                                print("failed")
                        result = {
                            "status_code": "200",
                        }
                        # return result
                        print("successfull")
                    else:
                        result = {
                            "status_code": "500",
                        }
                        # return result
                        print("failed")
                else:
                    result = {
                        "status_code": "300",
                    }
                    # return result
                    print("failed")
            else:
                result = {
                    "status_code": "500",
                }
                # return result
                print("failed")
    except (Exception) as error:
        print(error)
        result = {
            "status_code": "500",
        }
        # return result
        print("failed")

# This function is to get leave requests from SAP


@csrf_exempt
def get_leave_history_sap_request(emp_id, valid_from, valid_to):
    response = ""
    headers = {'content-type': 'text/xml'}
    try:
        body = common_request_body.leave_history_request_body
        body = body.replace("emp_id", str(emp_id))
        body = body.replace("valid_from", str(valid_from))
        body = body.replace("valid_to", str(valid_to))
        response = requests.post(config.leave_history_request_url, data=body, headers=headers, timeout=5, 
            auth=(config.cv_sap_webservice_id, config.cv_sap_webservice_password))
    except (Exception) as error:
        print(error)
    return response

# This fuction is to get all currency


@csrf_exempt
def get_leave_requests_master(request):
    try:
        user_data = json.loads(request.body)
        token = request.headers['Authorization'].split()[1]
        headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer' + ' ' + token
        }
        leave_category_values = []
        leave_status_values = []
        emp_id_values = []
        emp_id_values_dup = []
        emp_id_data = {
            "value": '',
            "code": ''
        }
        month_list = []
        leave_category_text = ""
        current_date_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).date()

        ps_group_details = PAPSAGroupMapping.objects.filter(
            pa_code=user_data['pa'], psa_code=user_data['psa']).first()
        if ps_group_details:
            leave_category_details = PSGroupLeaveCategoryMapping.objects.filter(
                pa_psa_group=ps_group_details.pa_psa_group, valid_from__lte=current_date_ist, valid_to__gte=current_date_ist)

            if leave_category_details:
                leave_category_details_json = get_serialize_data(
                    leave_category_details)

                for data in leave_category_details_json:
                    leave_category_data = {
                        "value": data['leave_category_text'],
                        "code": data['leave_category_code'],
                        "color":data['leave_categrory_color']
                    }
                    leave_category_values.append(leave_category_data)
            else:
                result = {
                    "status_code": "500",
                    "message": "",
                }
                return JsonResponse(result, safe=False)
        else:
            result = {
                "status_code": "500",
                "message": "",
            }
            return JsonResponse(result, safe=False)

        leave_status = LeaveStatus.objects.all()
        if leave_status:
            leave_status_json = get_serialize_data(leave_status)
            for data in leave_status_json:
                leave_status_data = {
                    "value": data['leave_status_text'],
                    "code": data['leave_status_code'],
                    "color":data['leave_status_color']
                }
                leave_status_values.append(leave_status_data)

        requestor_emp_id_details = LeaveRequestsEDP.objects.filter(approver_emp_id=user_data['emp_id']).exclude(Q(leave_status="1") | Q(
            leave_status="2") | Q(leave_status="3") | Q(leave_status="4") | Q(leave_status="7") | Q(leave_status="8") | Q(leave_status="9"))
        if requestor_emp_id_details:
            requestor_emp_id_details_json = get_serialize_data(
                requestor_emp_id_details)
            for user_data in requestor_emp_id_details_json:
                if user_data['requestor_emp_id'] not in emp_id_data['code']:
                    data = {
                        "emp_id": user_data['requestor_emp_id']
                    }
                    data_to_be_serialized = requests.post(config.get_edp_employee_details, headers=headers, data=json.dumps(data))
                    user_details_json = data_to_be_serialized.json()
                    print(user_details_json)

                    emp_id_data = {
                        "value": user_details_json['user_details'][0]['CompName'],
                        "code": user_details_json['user_details'][0]['Perno']
                    }
                    emp_id_values_dup.append(emp_id_data)
            emp_id_values_set = set()
            for data in emp_id_values_dup:
                data_items = tuple(data.items())
                if data_items not in emp_id_values_set:
                    emp_id_values_set.add(data_items)
                    emp_id_values.append(data)
            print(emp_id_values)

        # This is to get months from previous year
        for month in range(1, 13):
            month_data = {
                "code": f'{(month)}',
                "value": calendar.month_name[month],
            }
            month_list.append(month_data)
        result = {
            "status_code": "200",
            "message": "",
            "data": {
                "leave_category": leave_category_values,
                "leave_status": leave_status_values,
                "emp_id": emp_id_values,
                "month_list": month_list
            }
        }
        return JsonResponse(result, safe=False)
    except (Exception) as error:
        print(error)
        result = {
            "status_code": "500",
            "message": "",
        }
        return JsonResponse(result, safe=False)

# This function is to insert data into leave type table


@csrf_exempt
def insert_leave_type(request):
    leave_type_code = []
    leave_type_text = []
    data = json.loads(request.body)
    if bool(data):
        for value in data:
            leave_type_code.append(value['leave_type_code'])
            leave_type_text.append(value['leave_type_text'])
        for x in range(len(leave_type_code)):
            try:
                leave_type_details = LeaveType(
                    leave_type_code=leave_type_code[x],
                    leave_type_text=leave_type_text[x]
                )
                leave_type_details.save()
                result = {
                    "statusCode": "200",
                    "message": "data insert success",
                }

            except (Exception) as error:
                result = {
                    "statusCode": "200",
                    "message": "data insert fail"
                }
    else:
        result = {
            "statusCode": "200",
            "message": "incorrect request body"
        }
    return JsonResponse(result, safe=False)

# This function is to insert data into leave status table


@csrf_exempt
def insert_leave_status(request):
    leave_status_code = []
    leave_status_text = []
    leave_status_color = []
    data = json.loads(request.body)
    if bool(data):
        for value in data:
            leave_status_code.append(value['leave_status_code'])
            leave_status_text.append(value['leave_status_text'])
            leave_status_color.append(value['leave_status_color'])
        for x in range(len(leave_status_code)):
            try:
                leave_status_details = LeaveStatus(
                    leave_status_code=leave_status_code[x],
                    leave_status_text=leave_status_text[x],
                    leave_status_color=leave_status_color[x]
                )
                leave_status_details.save()
                result = {
                    "statusCode": "200",
                    "message": "data insert success",
                }

            except (Exception) as error:
                result = {
                    "statusCode": "200",
                    "message": "data insert fail"
                }
    else:
        result = {
            "statusCode": "200",
            "message": "incorrect request body"
        }
    return JsonResponse(result, safe=False)

# This function is to insert data into leave category table


@csrf_exempt
def insert_leave_category(request):
    leave_category_code = []
    leave_category_text = []
    data = json.loads(request.body)
    if bool(data):
        for value in data:
            leave_category_code.append(value['leave_category_code'])
            leave_category_text.append(value['leave_category_text'])
        for x in range(len(leave_category_code)):
            try:
                leave_category_details = LeaveCategory(
                    leave_category_code=leave_category_code[x],
                    leave_category_text=leave_category_text[x]
                )
                leave_category_details.save()
                result = {
                    "statusCode": "200",
                    "message": "data insert success",
                }

            except (Exception) as error:
                result = {
                    "statusCode": "200",
                    "message": "data insert fail"
                }
    else:
        result = {
            "statusCode": "200",
            "message": "incorrect request body"
        }
    return JsonResponse(result, safe=False)

# This function is to insert data into leave quota table


@csrf_exempt
def insert_leave_quota(request):
    quota_code = []
    quota_text = []
    quota_color_text = []
    data = json.loads(request.body)
    if bool(data):
        for value in data:
            quota_code.append(value['quota_code'])
            quota_text.append(value['quota_text'])
            quota_color_text.append(value['quota_color_text'])
        for x in range(len(quota_code)):
            try:
                quota_details = Quota(
                    quota_code=quota_code[x],
                    quota_text=quota_text[x],
                    quota_color_text=quota_color_text[x],
                )
                quota_details.save()
                result = {
                    "statusCode": "200",
                    "message": "data insert success",
                }

            except (Exception) as error:
                print(error)
                result = {
                    "statusCode": "200",
                    "message": "data insert fail"
                }
    else:
        result = {
            "statusCode": "200",
            "message": "incorrect request body"
        }
    return JsonResponse(result, safe=False)

# This function is to insert data into leave quota code and leavve category mapping table


@csrf_exempt
def insert_leave_quota_category_mapping(request):
    quota_code = []
    leave_category = []
    data = json.loads(request.body)
    if bool(data):
        for value in data:
            quota_code.append(value['quota_code'])
            leave_category.append(value['leave_category'])
        for x in range(len(quota_code)):
            try:
                leave_quota_category_mapping_details = QuotaLeaveCategoryMapping(
                    quota_code=quota_code[x],
                    leave_category=leave_category[x]
                )
                leave_quota_category_mapping_details.save()
                result = {
                    "statusCode": "200",
                    "message": "data insert success",
                }

            except (Exception) as error:
                print(error)
                result = {
                    "statusCode": "200",
                    "message": "data insert fail"
                }
    else:
        result = {
            "statusCode": "200",
            "message": "incorrect request body"
        }
    return JsonResponse(result, safe=False)

######################################### Leave Listing Section End ########################################

######################################### Leave Request Section Start #######################################
# This function is to create/update leave request in edp


@csrf_exempt
def create_leave_request_edp(request):
    leave_request_data = json.loads(request.body)
    print("create leave request",leave_request_data)
    if bool(leave_request_data):
        try:
            leave_entry_count =0
            is_add_another_leave_functionality = False
            platform = "Other"
            if 'platform' in leave_request_data:
                platform = "chat-bot"
            token = request.headers['Authorization'].split()[1]
            headers = {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer' + ' ' + token
            }
            # This is to check cross company manager 
            if 'emp_company_code' in leave_request_data and 'manager_company_code' in leave_request_data:
                if leave_request_data['emp_company_code'] != leave_request_data['manager_company_code']:
                    result = cross_company_reporting_leave_request(request)
                    return JsonResponse(result, safe=False)
            for data in leave_request_data['data']:
                if leave_entry_count > 0:
                    is_add_another_leave_functionality = True
                leave_entry_count = leave_entry_count + 1

                # This is to get current year in IST
                current_date_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).date()

                # This is to create unique leave request id
                leave_request_id = str(uuid.uuid4())
                # This is to add leave request againest LWOP table
                if 'is_lwop' in data and data['is_lwop'] == "1":
                    leave_against_lwop_details = LeaveAgainstLWOP(
                        leave_request_id=leave_request_id,
                        is_deleted=False,
                        is_posted=False,
                        created_date_time=datetime.now()
                    )
                    leave_against_lwop_details.save()

                if not "approver_email" in data:
                    data['approver_email'] = constants.system_approver_email
                #Approval Engine Api call for now we just call objects
                

                # This is to create new leave requests
                leave_request_details = LeaveRequestsEDP(
                    leave_request_id=leave_request_id,
                    requestor_emp_id=leave_request_data['emp_id'],
                    requestor_email=data['requestor_email'],
                    approver_emp_id=data['approver'],
                    approver_email=data['approver_email'],
                    leave_category=data['leave_category_code'],
                    leave_type=data['leave_type_code'],
                    from_date=data['from_date'],
                    to_date=data['to_date'],
                    reason=data['reason'],
                    total_days=data['total_days'],
                    unique_quota_id=data['unique_quota_id'],
                    leave_status="0",
                    applied_date=current_date_ist,
                    is_deleted=False,
                    created_date_time=datetime.now(),
                    modified_date_time=datetime.now(),
                    created_by=leave_request_data['emp_id'],
                    modified_by=leave_request_data['emp_id'],
                )
                leave_request_details.save()
                if data['approver_email'] != "":
                    leave_category_text = ""
                    leave_type_text = ""

                    # To create email subject
                    current_datetime_ist = datetime.now() + timedelta(hours=5, minutes=30)
                    current_date_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).date()
                    email_subject = leave_request_data['emp_id'] + """ - """ + leave_request_data['emp_name'] + \
                        """ - Leave Request Notification - """ + \
                        str(current_datetime_ist.date())

                    # This is to get leave category text
                    ps_group_details = PAPSAGroupMapping.objects.filter(
                        pa_code=leave_request_data['pa'], psa_code=leave_request_data['psa']).first()
                    if ps_group_details:
                        leave_category_details = PSGroupLeaveCategoryMapping.objects.filter(
                            pa_psa_group=ps_group_details.pa_psa_group, leave_category_code=data['leave_category_code'], valid_from__lte=current_date_ist, valid_to__gte=current_date_ist).first()
                        if leave_category_details:
                            leave_category_text = leave_category_details.leave_category_text

                    # This is to get leave type text
                    leave_type_details = LeaveType.objects.filter(
                        leave_type_code=data['leave_type_code']).first()
                    if leave_type_details:
                        leave_type_text = leave_type_details.leave_type_text

                    #Request Body for leave request application mail template - NOT IN USE FOR NOW..
                    request_body_for_mail_template = {
                        constants.LEAVE_CATEGORY_MAIL: constants.LEAVE_REQUEST,
                        constants.EMP_ID:leave_request_data['emp_id'],
                        constants.EMP_NAME:leave_request_data['emp_name'],
                        constants.LEAVE_TYPE:leave_category_text,
                        constants.ABSENCE_TYPE:leave_type_text,
                        constants.START_DATE:data['from_date'],
                        constants.END_DATE: data['to_date'],
                        constants.LEAVE_REASON: data['reason'],
                        constants.TO_MAIL_ADDRESS:data['approver_email'],
                        constants.CC_MAIL_ADDRESS:data['requestor_email'],
                        constants.LEAVE_REQUESTOR_ROLE : constants.MANAGER_ROLE,
                        # constants.LEAVE_REQUEST_UNIQUE_ID: leave_request_id
                    }
                    mail_response = leave_application_mail(request_body_for_mail_template)
                    print("mail response",mail_response)

                    # to create a email body
                    # email_body = template.leave_request_email_template
                    # email_body = email_body.replace(
                    #     'emp_id', leave_request_data['emp_id'])
                    # email_body = email_body.replace(
                    #     'emp_name', leave_request_data['emp_name'])
                    # email_body = email_body.replace(
                    #     'leave_type', leave_category_text)
                    # email_body = email_body.replace(
                    #     'absence_type', leave_type_text)
                    # email_body = email_body.replace(
                    #     'start_date', data['from_date'])
                    # email_body = email_body.replace(
                    #     'end_date', data['to_date'])
                    # email_body = email_body.replace(
                    #     'leave_reason', data['reason'])

                    # # To send attendance email  to manager
                    # send_email_notification(
                    #     data['approver_email'], data['requestor_email'], email_body, email_subject)

                notification_details = {
                    "emp_id": leave_request_data['emp_id'],
                    "emp_name": leave_request_data['emp_name'],
                    "reporting_manager": data['approver'],
                    "leave_request_id": leave_request_id,
                    "notification_type": "Leave Request"
                }

                # This is to get leave type text
                leave_type_details = LeaveType.objects.filter(
                    leave_type_code=data['leave_type_code']).first()
                if leave_type_details:
                    leave_type_text = leave_type_details.leave_type_text

                # This is to create leave request notification
                response = session.post(
                    config.create_leave_request_notification_url, data=json.dumps(notification_details))

                # This is for create approver leave push notification
                push_notification_request_body = {
                    "notification_for": "manager",
                    "notification_to": leave_request_data['emp_id'],
                    "notification_content": leave_request_data['emp_name'] + " has applied for " + leave_category_text + " from " + date_format_conversion(str(data['from_date']))+" to " + date_format_conversion(str(data['to_date'])),
                    "notification_type": "Leave",
                    "notification_title": "Leave Request",
                    "data_content": leave_request_data['emp_name'] + " has applied for " + leave_category_text + " from "+data['from_date']+" to "+data['to_date'],
                    "data_title": "Leave Request",
                    "data_type":  "Leave Request",
                    "screen_type": "LeaveApprovals",
                    "request_from":"show_leave_apply_delete",
                }
                push_notification_response = insert_push_notification(
                    json.dumps(push_notification_request_body))

                push_notification_request_body = {
                    "notification_for": "employee",
                    "notification_to": leave_request_data['emp_id'],
                    "notification_content": "Leave" + " applied for " + leave_category_text + " from " + date_format_conversion(str(data['from_date']))+" to " + date_format_conversion(str(data['to_date'])),
                    "notification_type": "Leave",
                    "notification_title": "Leave Request",
                    "data_content": "Leave" + " applied for " + leave_category_text + " from "+data['from_date']+" to "+data['to_date'],
                    "data_title": "Leave Request",
                    "data_type":  "Leave Request",
                    "screen_type": "LeaveApprovals",
                    "request_from":"show_leave_apply_delete",
                }
                push_notification_response = insert_push_notification(
                    json.dumps(push_notification_request_body))
                
            # This is to insert leave requst timestamp
            sap_posting_details = SAPPostingDetails(
                leave_request_id=leave_request_id,
                leave_request_datetime=datetime.now(),
                created_by="SYSTEM",
                modified_by="SYSTEM"
            )
            sap_posting_details.save()
            LEAVE_SUCCESS = constants.LEAVE_SUCCESS
            if is_add_another_leave_functionality:
                ADD_ANOTHER_LEAVE_WARNING = constants.ADD_ANOTHER_LEAVE_WARNING_MESSAGE
                LEAVE_SUCCESS = LEAVE_SUCCESS + ADD_ANOTHER_LEAVE_WARNING
            result = {
                "status_code": "200",
                "message": LEAVE_SUCCESS
            }

            # InterService Call to Store Activity Log
            activity_details = {
                "leave_request_id": leave_request_id,
                "emp_id": leave_request_data['emp_id'],
                "browser": str(request.user_agent.browser.family),
                "device_type": str(request.user_agent.device.family),
                "operating_system": str(request.user_agent.os.family),
                "action": 'Create-Leave',
                "platform":platform
            }
            token = request.headers['Authorization'].split()[1]
            headers = {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer' + ' ' + token
            }
            response = session.post(
                config.create_activity_log_url, headers=headers, data=json.dumps(activity_details))
            print('Activity Log', response)

            #This is used to just handle timeout execption for kafka webservices.
            try:
                # This is for call kafka producer   
                leave_task_module_notification={
                    "eventType":constants.LEAVE_REQUEST,
                    "adaptiveCardType":constants.TASK_MODULE,
                    "receiverId":data['approver'],
                    "comp_code":constants.TMCV     
                    }
                kafka_task_module_leave = requests.post(config.producer_leave_notification, headers=headers,timeout = 5, data=json.dumps(leave_task_module_notification))
            except Exception as error:
                print("kakfa error",error)
                return JsonResponse(result, safe=False)
            return JsonResponse(result, safe=False)
        except (Exception) as error:
            # transaction.rollback()
            print(error)
            result = {
                "status_code": "500",
                "message": "Unable to Submit leave request"
            }
            return JsonResponse(result, safe=False)
    else:
        result = {
            "status_code": "500",
            "message": "Unable to Submit leave request"
        }
        return JsonResponse(result, safe=False)

#This function is to create leave with cross company reporting manager
def cross_company_reporting_leave_request(request):
    try:
        leave_request_data = json.loads(request.body)

        platform = "Other"
        if 'platform' in leave_request_data:
            platform = "chat-bot"

        for data in leave_request_data['data']:
            # This is to get current year in IST
            current_date_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).date()
            # This is to create unique leave request id
            leave_request_id = str(uuid.uuid4())

            # This is to add leave request againest LWOP table
            if 'is_lwop' in data and data['is_lwop'] == "1":
                leave_against_lwop_details = LeaveAgainstLWOP(
                    leave_request_id=leave_request_id,
                    is_deleted=False,
                    is_posted=False,
                    created_date_time=datetime.now()
                )
                leave_against_lwop_details.save()

            # This is to create new leave requests
            leave_request_details = LeaveRequestsEDP(
                leave_request_id=leave_request_id,
                requestor_emp_id=leave_request_data['emp_id'],
                requestor_email=data['requestor_email'],
                approver_emp_id=data['approver'],
                approver_email=data['approver_email'],
                leave_category=data['leave_category_code'],
                leave_type=data['leave_type_code'],
                from_date=data['from_date'],
                to_date=data['to_date'],
                reason=data['reason'],
                total_days=data['total_days'],
                unique_quota_id=data['unique_quota_id'],
                leave_status="1",
                applied_date=current_date_ist,
                is_deleted=False,
                created_date_time=datetime.now(),
                modified_date_time=datetime.now(),
                created_by=leave_request_data['emp_id'],
                modified_by=leave_request_data['emp_id'],
            )
            leave_request_details.save()

            # this is to collect all approved leaves
            approved_leave_request = ApprovedLeaveRequests(
                leave_request_id = leave_request_id,
                created_date_time = datetime.now()
            )
            approved_leave_request.save()

            # This is to insert leave requst timestamp
            sap_posting_details = SAPPostingDetails(
                leave_request_id=leave_request_id,
                leave_request_datetime=datetime.now(),
                created_by="SYSTEM",
                modified_by="SYSTEM"
            )
            sap_posting_details.save()

            # InterService Call to Store Activity Log
            activity_details = {
                "leave_request_id": leave_request_id,
                "emp_id": leave_request_data['emp_id'],
                "browser": str(request.user_agent.browser.family),
                "device_type": str(request.user_agent.device.family),
                "operating_system": str(request.user_agent.os.family),
                "action": 'Cross-Company-Reporting-Create-Leave',
                "platform":platform
            }
            token = request.headers['Authorization'].split()[1]
            headers = {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer' + ' ' + token
            }
            response = session.post(
                config.create_activity_log_url, headers=headers, data=json.dumps(activity_details))

            # This is to create leave request notification
            notification_details = {
                "requestor_emp_id": leave_request_data['emp_id'],
                "approver_emp_id": "00000000",
                "leave_request_id": leave_request_id,
                "notification_type": "Leave Auto Approval",
                "action": "0"
            }
            response = session.post(
                config.create_leave_approval_notification_url, data=json.dumps(notification_details))

             # This is for create push notification
            push_notification_request_body = {
                "notification_for": "employee",
                "notification_to": leave_request_data['emp_id'],
                "notification_content":  "Your " + get_leave_category_text_emp_id(data['leave_category_code'],leave_request_data['emp_id']) + " request has been auto approved from "+date_format_conversion(str(data['from_date']))+" to "+date_format_conversion(str(data['to_date'])),
                "notification_type": "Leave",
                "notification_title": "Leave Auto Approval",
                "data_content": "Your " + get_leave_category_text_emp_id(data['leave_category_code'], leave_request_data['emp_id']) + " request has been auto approved from "+date_format_conversion(str(data['from_date']))+" to "+date_format_conversion(str(data['to_date'])),
                "data_title": "Leave Auto Approval",
                "data_type":  "Leave Request",
                "screen_type": "LeaveListing",
                "request_from":"show_leave_apply_delete",
            }
            push_notification_response = insert_push_notification(
                json.dumps(push_notification_request_body))

        result = {
            "status_code": "200",
            "message": "Leave requests submitted successfully"
        }
        return result
    except (Exception) as error:
        print(error)
        result = {
            "status_code": "500",
            "message": "Unable to Submit leave request"
        }
        return result

# METHOD: update_leave_request_sap
# DESCRIPTION: This function is to create leave request/update in sap - Old
# AUTHOR: Mayur Kulkarni
# Date: 05/08/2020
@csrf_exempt
def update_leave_request_sap():
    try:
        scheduler_name = constants.UPDATE_LEAVE_REQUEST_SAP
        start_scheduler = LeaveSchedulerConfig.objects.filter(scheduler_name = scheduler_name).first()
        if not start_scheduler or (start_scheduler.is_active == False):
            leave_services_logs = LeaveServicesLogs(
                log_id=str(uuid.uuid4()),
                log_type="LEAVE POSTING SCHEDULAR",
                result="STOPPED",
                created_date_time=datetime.now(),
                modified_date_time=datetime.now(),
                created_by="SYSTEM",
                modified_by="SYSTEM"
            )
            leave_services_logs.save()
            print("Leave Scheduler(Old): Leave Scheduler has been stopped.")
            status = constants.STOPPED
            description = message.SCHEDULER_STOPPED
            leave_scheduler_logs(scheduler_name,status,description)
            return return_response_func(request, return_object_func(constants.HTTP_400_BAD_REQUEST, message.SCHEDULER_STOPPED, {}))
        print('update start..')
        approved_leave_requests_details = ApprovedLeaveRequests.objects.all()
        if approved_leave_requests_details:
            approved_leave_requests_details_json = get_serialize_data(
                approved_leave_requests_details)

            for data in approved_leave_requests_details_json:
                try:

                    # hit sap web service to update leave request in SAP
                    leave_request_details = LeaveRequestsEDP.objects.filter(
                        leave_request_id=data['leave_request_id']).first()
                    if leave_request_details:

                        # This is to stop leave updation in case of LWOP
                        leave_against_lwop_details = LeaveAgainstLWOP.objects.filter(
                            leave_request_id=data['leave_request_id']).first()
                        if leave_against_lwop_details and leave_against_lwop_details.is_deleted == False:
                            lwop_delete_sap_response = delete_lwop_leave_request_sap_request(
                                leave_request_details)

                            if lwop_delete_sap_response != None and lwop_delete_sap_response.status_code == 200:
                                lwop_delete_leave_details_sap = json.dumps(xmltodict.parse(
                                    lwop_delete_sap_response.content))  # to convert xml response into dictionary
                                lwop_delete_leave_details_sap_json = json.loads(
                                    lwop_delete_leave_details_sap)

                                if lwop_delete_leave_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['TYPE'] == "S":
                                    leave_against_lwop_details.is_deleted = True
                                    leave_against_lwop_details.save()
                                else:
                                    if leave_request_details.applied_date < (datetime.now().date() - timedelta(days=3)):
                                        if leave_request_details.leave_status == "1":
                                            leave_request_details.leave_status = "8"
                                    continue
                            else:
                                continue

                        if leave_against_lwop_details and leave_against_lwop_details.is_posted == True:
                            continue

                        # This is to update leave in SAP
                        sap_response = update_leave_request_sap_request(
                            leave_request_details)

                        # This is to check wheather th response is in string
                        is_string = isinstance(sap_response, str)
                        if is_string == True:
                            print("SAP webservice failed")

                        if sap_response != None and sap_response.status_code == 200:

                            # to convert xml response into dictionary
                            leave_update_details_sap = json.dumps(
                                xmltodict.parse(sap_response.content))
                            leave_update_sap_json = json.loads(
                                leave_update_details_sap)

                            # This is to allow leave against LWOP
                            sap_status_code = leave_update_sap_json[
                                'soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['TYPE']
                            sap_msg_number = leave_update_sap_json[
                                'soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['NUMBER']
                            print(leave_update_sap_json['soap-env:Envelope']
                                ['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['MESSAGE'])
                            print(leave_update_sap_json['soap-env:Envelope']
                                ['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['TYPE'])
                            print(leave_update_sap_json['soap-env:Envelope']
                                ['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['NUMBER'])
                            emp_id = leave_request_details.requestor_emp_id
                            from_date = leave_request_details.from_date
                            to_date = leave_request_details.to_date

                            sap_leave_request = LeaveRequestsSAP.objects.filter(
                                Q(requestor_emp_id=emp_id, from_date=from_date, to_date=to_date, \
                                  leave_category__in=constants.sap_leave_category_status, is_deleted=False) 
                            )

                            if(sap_status_code == "E" and sap_msg_number == "080" and sap_leave_request):
                                leave_against_lwop_details = LeaveAgainstLWOP(
                                    leave_request_id=data['leave_request_id'],
                                    is_deleted=False,
                                    is_posted=False,
                                    created_date_time=datetime.now()
                                )
                                print("Adding LWOP Leave")
                                leave_against_lwop_details.save()

                            if leave_update_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['TYPE'] == "S":

                                if leave_against_lwop_details and leave_against_lwop_details.is_posted == False:
                                    leave_against_lwop_details.is_posted = True
                                    leave_against_lwop_details.save()

                                # This is to update the status after successfully udpated in SAP
                                leave_request_details = LeaveRequestsEDP.objects.filter(
                                    leave_request_id=data['leave_request_id']).first()
                                if leave_request_details:
                                    if leave_request_details.leave_status == "1":
                                        leave_request_details.leave_status = "2"

                                        # This is to insert leave requst timestamp
                                        sap_posting_details = SAPPostingDetails.objects.filter(
                                            leave_request_id=data['leave_request_id']).first()
                                        if sap_posting_details:
                                            sap_posting_details.leave_request_posting_datetime = datetime.now()
                                            sap_posting_details.created_by = "SYSTEM"
                                            sap_posting_details.modified_by = "SYSTEM"
                                            sap_posting_details.save()

                                    else:
                                        leave_request_details.leave_status = "7"
                                        leave_request_details.is_deleted = True

                                        # This is to insert leave requst timestamp
                                        sap_posting_details = SAPPostingDetails.objects.filter(
                                            leave_request_id=data['leave_request_id']).first()
                                        if sap_posting_details:
                                            sap_posting_details.delete_leave_posting_datetime = datetime.now()
                                            sap_posting_details.created_by = "SYSTEM"
                                            sap_posting_details.modified_by = "SYSTEM"
                                            sap_posting_details.save()

                                    leave_request_details.modified_date_time = datetime.now()
                                    leave_request_details.save()

                                # This is to delete the record from approved leave request table
                                approved_leave_request = ApprovedLeaveRequests.objects.filter(
                                    leave_request_id=data['leave_request_id']).delete()

                                if leave_request_details.requestor_email != "":
                                    leave_category_text = ""
                                    leave_type_text = ""

                                    # To create email subject
                                    leave_categpory_mail = ""
                                    current_datetime_ist = datetime.now() + timedelta(hours=5, minutes=30)
                                    if leave_request_details.leave_status == "2":
                                        leave_categpory_mail = constants.LEAVE_APPROVAL_NOTIFICATION
                                        email_subject = """Leave Approval Notification - """ + \
                                            str(current_datetime_ist.date())
                                        email_body = template.leave_approval_email_template
                                    else:
                                        leave_categpory_mail = constants.LEAVE_DELETE_APPROVE
                                        email_subject = """Delete Leave Approval Notification - """ + \
                                            str(current_datetime_ist.date())
                                        email_body = template.delete_leave_approval_email_template

                                    user = {
                                        "emp_id": leave_request_details.requestor_emp_id
                                    }
                                    response = session.post(
                                        config.get_edp_employee_details, data=json.dumps(user))
                                    user_details = response.content.decode("utf-8")
                                    user_details_json = json.loads(user_details)

                                    pa = user_details_json['user_details'][0]['PersArea']
                                    psa = user_details_json['user_details'][0]['PSubarea']
                                    emp_name = user_details_json['user_details'][0]['CompName']
                                    # This is to get leave category text
                                    current_date_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).date()
                                    ps_group_details = PAPSAGroupMapping.objects.filter(
                                        pa_code=pa, psa_code=psa).first()
                                    if ps_group_details:
                                        leave_category_details = PSGroupLeaveCategoryMapping.objects.filter(
                                            pa_psa_group=ps_group_details.pa_psa_group, leave_category_code=leave_request_details.leave_category, valid_from__lte=current_date_ist, valid_to__gte=current_date_ist).first()
                                        if leave_category_details:
                                            leave_category_text = leave_category_details.leave_category_text

                                    # This is to get leave type text
                                    leave_type_details = LeaveType.objects.filter(
                                        leave_type_code=leave_request_details.leave_type).first()
                                    if leave_type_details:
                                        leave_type_text = leave_type_details.leave_type_text

                                    #Request Body - To send leave application approval mail
                                    request_body_for_mail_template = {
                                        constants.LEAVE_CATEGORY_MAIL: leave_categpory_mail,
                                        constants.EMP_ID:leave_request_details.requestor_emp_id,
                                        constants.EMP_NAME:emp_name,
                                        constants.LEAVE_TYPE:leave_category_text,
                                        constants.ABSENCE_TYPE:leave_type_text,
                                        constants.START_DATE:str(leave_request_details.from_date),
                                        constants.END_DATE:str(leave_request_details.to_date),
                                        constants.LEAVE_REASON: leave_request_details.reason,
                                        constants.TO_MAIL_ADDRESS: leave_request_details.requestor_email,
                                        constants.CC_MAIL_ADDRESS:leave_request_details.approver_email,
                                        constants.LEAVE_REQUESTOR_ROLE : constants.EMPLOYEE_ROLE
                                        
                                    }
                                    mail_response = leave_application_mail(request_body_for_mail_template)
                                    print("approved mail response",mail_response)

                                print("Leave request sucuessfully updated in SAP")
                            else:
                                print("Unable to update request in SAP")

                                # This is to make leave status as error
                                current_date = datetime.now().date()
                                if leave_request_details.applied_date < (datetime.now().date() - timedelta(days=3)):
                                    if leave_request_details.leave_status == "1":
                                        leave_request_details.leave_status = "8"

                                        # This is to insert leave requst timestamp
                                        sap_posting_details = SAPPostingDetails.objects.filter(
                                            leave_request_id=data['leave_request_id']).first()
                                        if sap_posting_details:
                                            sap_posting_details.leave_request_posting_datetime = datetime.now()
                                            sap_posting_details.created_by = "SYSTEM"
                                            sap_posting_details.modified_by = "SYSTEM"
                                            sap_posting_details.save()
                                    else:
                                        leave_request_details.leave_status = "9"

                                    leave_request_details.modified_date_time = datetime.now()
                                    leave_request_details.save()

                                    # This is to delete the record from approved leave request table
                                    approved_leave_request = ApprovedLeaveRequests.objects.filter(
                                        leave_request_id=data['leave_request_id']).delete()
                        else:
                            print("SAP webservice failed.")
                    else:
                        print("leave request is not present in leave deatils table ")
                except Exception as error:
                    print("SAP Posting error",error)
                    continue

            # This is insert data in logs table
            leave_services_logs = LeaveServicesLogs(
                log_id=str(uuid.uuid4()),
                log_type="LEAVE POSTING SCHEDULAR",
                result="SUCCESS",
                created_date_time=datetime.now(),
                modified_date_time=datetime.now(),
                created_by="SYSTEM",
                modified_by="SYSTEM"
            )
            leave_services_logs.save()
        else:
            print("No data found to update in SAP")
        return JsonResponse(message.SUCCESSFULLY_WORKING,safe=False)
    except (Exception) as error:
        print_error_v1("update_leave_request_sap",error)
        # This is insert data in logs table
        leave_services_logs = LeaveServicesLogs(
            log_id=str(uuid.uuid4()),
            log_type="LEAVE POSTING SCHEDULAR",
            result="FAIL",
            created_date_time=datetime.now(),
            modified_date_time=datetime.now(),
            created_by="SYSTEM",
            modified_by="SYSTEM"
        )
        leave_services_logs.save()
        return JsonResponse(message.SERVER_ERROR_MESSAGE,safe=False)

# This function is to create leave request/update in sap


@csrf_exempt
def update_leave_request_sap_request(request):
    leave_request_data = request

    if bool(leave_request_data):

        # This is to get leave group
        leave_category_code = leave_request_data.leave_category
        leave_group_details = PSGroupLeaveCategoryMapping.objects.filter(
            leave_category_code=leave_category_code).first()
        if not leave_group_details:
            return None

        # This is to get info type
        info_type = "2002"
        if leave_group_details.leave_group == "0":
            info_type = "2001"

        # This is to identify which operation should perform
        if leave_request_data.leave_status == "1":
            operation = "INS"
        elif leave_request_data.leave_status == "6":
            operation = "DEL"
        else:
            return None

        headers = {'content-type': 'text/xml'}
        request_body = common_request_body.leave_validate_update_requst_body
        #simulation = "N"

        request_body = request_body.replace(
            "emp_id", leave_request_data.requestor_emp_id)
        request_body = request_body.replace(
            "leave_category", leave_request_data.leave_category)
        request_body = request_body.replace(
            "leave_type", leave_request_data.leave_type)
        request_body = request_body.replace("info_type", info_type)
        request_body = request_body.replace(
            "from_date", str(leave_request_data.from_date))
        request_body = request_body.replace(
            "to_date", str(leave_request_data.to_date))
        request_body = request_body.replace("simulation", "N")
        request_body = request_body.replace("operation", operation)

        response = requests.post(config.leave_validate_update_request_url, data=request_body, headers=headers, auth=(
            config.cv_sap_webservice_id, config.cv_sap_webservice_password))
        return response
    else:
        return None

# This function is to create leave request/update in sap


@csrf_exempt
def delete_lwop_leave_request_sap_request(request):
    try:
        leave_request_data = request

        if bool(leave_request_data):

            # This is to get leave group
            leave_category_code = leave_request_data.leave_category
            leave_group_details = PSGroupLeaveCategoryMapping.objects.filter(
                leave_category_code=leave_category_code).first()
            if not leave_group_details:
                return None

            # This is to get info type
            info_type = "2001"
            # if leave_group_details.leave_group == "0":
            #     info_type = "2001"

            # # This is to identify which operation should perform
            # if leave_request_data.leave_status == "1":
            #     operation = "INS"
            # elif leave_request_data.leave_status == "6":
            #     operation = "DEL"
            # else:
            #     return None

            leave_requests_sap = LeaveRequestsSAP.objects.filter(
                from_date=leave_request_data.from_date,
                to_date=leave_request_data.to_date,
                requestor_emp_id=leave_request_data.requestor_emp_id
            ).first()

            if leave_requests_sap:
                if leave_requests_sap.leave_category == "ZOP":
                    return None

            leave_against_lwop_details = LeaveAgainstLWOP.objects.filter(
                leave_request_id=leave_request_data.leave_request_id).first()
            if leave_against_lwop_details and leave_requests_sap:

                if leave_against_lwop_details.is_deleted == False:
                    operation = "DEL"
                    leave_category = leave_requests_sap.leave_category
                else:
                    return None

            headers = {'content-type': 'text/xml'}
            request_body = common_request_body.leave_validate_update_requst_body

            # request_body = request_body.replace("emp_id", leave_request_data.requestor_emp_id)
            # request_body = request_body.replace("leave_category", leave_category)
            # request_body = request_body.replace("leave_type", leave_request_data.leave_type)
            # request_body = request_body.replace("info_type", info_type)
            # request_body = request_body.replace("from_date", str(leave_request_data.from_date))
            # request_body = request_body.replace("to_date", str(leave_request_data.to_date))
            # request_body = request_body.replace("simulation", "N")
            # request_body = request_body.replace("operation", operation)

            request_body = request_body.replace("emp_id", leave_request_data.requestor_emp_id)
            request_body = request_body.replace("leave_category", leave_category)
            request_body = request_body.replace("leave_type", leave_request_data.leave_type)
            request_body = request_body.replace("info_type", info_type)
            request_body = request_body.replace("from_date", str(leave_request_data.from_date))
            request_body = request_body.replace("to_date", str(leave_request_data.to_date))
            request_body = request_body.replace("simulation", "N")
            request_body = request_body.replace("operation", operation)
            print(request_body)
            response = requests.post(config.leave_validate_update_request_url, data=request_body, headers=headers, auth=(
                config.cv_sap_webservice_id, config.cv_sap_webservice_password))
            return response
        else:
            return None
    except Exception as error:
        print(error)
        return None

# This function is to validate leave request


@csrf_exempt
def validate_leave_request(request):
    try:
        unique_quota_id = ""
        is_lwop = "0"
        leave_request_data = json.loads(request.body)

        platform = "Other"
        if 'platform' in leave_request_data:
            platform = "chat-bot"

        emp_id = leave_request_data['emp_id']
        from_date = leave_request_data['data'][len(
            leave_request_data['data']) - 1]['from_date']
        to_date = leave_request_data['data'][len(
            leave_request_data['data']) - 1]['to_date']
        leave_category_code = leave_request_data['data'][len(
            leave_request_data['data']) - 1]['leave_category_code']
        leave_type_code = leave_request_data['data'][len(
            leave_request_data['data']) - 1]['leave_type_code']
        
        fetch_data = fetch_cet_data(request.headers, emp_id = emp_id)
        if fetch_data and 'status_code' in fetch_data and fetch_data['status_code'] == "200":
            emp_pa = fetch_data['user_details'][0]['PersArea']
            print("Employee Per Area", emp_pa)

        # This is used to check if WFH is on Tuesday or Thursday
        if leave_category_code == constants.WORK_FROM_HOME:
            from_date = datetime.strptime(from_date, constants.DATE_FORMAT)
            to_date = datetime.strptime(to_date, constants.DATE_FORMAT)
            days_btw_from_to = (to_date - from_date).days + 1
            for i in range(days_btw_from_to):
                current_day = (from_date + timedelta(days=i)).weekday()
                # 1: Tuesday , 2: Wednesday and 3: Thursday
                if emp_pa == constants.PA:
                    if current_day == 1 or current_day == 2 or current_day == 3:
                        return JsonResponse(return_object_func(custom_messages.ERROR_STATUS_CODE ,custom_messages.WFH_LEAVE_ERROR_ERCU, {}), safe = False)
                # 1: Tuesday and 3: Thursday
                else:
                    if current_day == 1 or current_day == 3:
                        return JsonResponse(return_object_func(custom_messages.ERROR_STATUS_CODE ,custom_messages.WFH_LEAVE_ERROR, {}), safe = False)

        # if leave_category_code != "WFH":
        #     result={
        #         "status_code": "200",
        #         "leave_applied_message":leave_applied_msg
        #     }
        #     return JsonResponse(result, safe=False)
        # print('after wfh-------------')

        
        #This is used to syn the employee leave quota - commit for testing perspective.
        response = get_leave_quota(request)

        # This is to validate leave from edp
        edp_validation = validate_leave_request_edp(request)
        print("validate", edp_validation)

        if edp_validation['validate'] == False:
            result = {
                "status_code": "500",
                "message": edp_validation['message']
            }
            return JsonResponse(result, safe=False)

        # This is to validate leave from SAP
        sap_response = validate_leave_request_sap(request)
        print(sap_response)
        # This is to check wheather th response is in string
        is_string = isinstance(sap_response, str)
        if is_string == True:
            result = {
                "status_code": "500",
                "message": ""
            }
            return JsonResponse(result, safe=False)

        if sap_response != None and sap_response.status_code == 200:
            leave_validate_details_sap = json.dumps(xmltodict.parse(
                sap_response.content))  # to convert xml response into dictionary
            leave_validate_sap_json = json.loads(leave_validate_details_sap)

            print(leave_validate_sap_json)
            # This is to allow leave againest LWOP
            sap_status_code = leave_validate_sap_json[
                'soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['TYPE']
            sap_msg_number = leave_validate_sap_json[
                'soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['NUMBER']

            sap_leave_request = LeaveRequestsSAP.objects.filter(
                Q(requestor_emp_id=emp_id, from_date=from_date, to_date=to_date, \
                    leave_category__in=constants.sap_leave_category_status, is_deleted=False) 
                # Q(requestor_emp_id=emp_id, from_date=from_date, to_date=to_date, leave_category="Z0P", is_deleted=False) |
                # Q(requestor_emp_id=emp_id, from_date=from_date, to_date=to_date, leave_category="X0", is_deleted=False) |
                # Q(requestor_emp_id=emp_id, from_date=from_date, to_date=to_date, leave_category="X0P", is_deleted=False) 
            )

            if (sap_status_code == "S" or (sap_status_code == "E" and sap_msg_number == "080" and sap_leave_request)):
                status_code = "200"
                message = """Leave/Regularization request validated successfully. Kindly click on "Submit" button to complete submission."""
                message = message + " " + constants.ADD_ANOTHER_LEAVE_WARNING_MESSAGE
                # InterService Call to Store Activity Log #start
                activity_details = {
                    "leave_request_id": '',
                    "emp_id": emp_id,
                    "browser": str(request.user_agent.browser.family),
                    "device_type": str(request.user_agent.device.family),
                    "operating_system": str(request.user_agent.os.family),
                    "action": 'Validate-Leave',
                    "platform":platform
                }
                token = request.headers['Authorization'].split()[1]
                headers = {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer' + ' ' + token
                }
                response = session.post(
                    config.create_activity_log_url, headers=headers, data=json.dumps(activity_details))
                print('Activity Log', response)

                if(sap_status_code == "E" and sap_msg_number == "080" and sap_leave_request):
                    is_lwop = "1"

                # This is to check leave category againest active quota
                active_quota_details = ActiveQuotaDetails.objects.filter(
                    emp_id=emp_id).first()
                for quota_code in active_quota_details.active_quota_code:
                    leave_quota = QuotaLeaveCategoryMapping.objects.filter(
                        leave_category=leave_category_code, quota_code=quota_code).first()
                    if leave_quota:
                        break

                # # This is to update leave quota
                # if leave_quota:
                #     leave_quota_deatils = LeaveQuota.objects.filter(emp_id= emp_id , quota_code = leave_quota.quota_code).first()
                #     if (leave_quota_deatils and float(leave_quota_deatils.available_leaves) != 0):
                #         available_leaves = float(leave_quota_deatils.available_leaves) - float(edp_validation['total_days'])
                #         leave_quota_deatils.available_leaves = str(available_leaves)
                #         leave_quota_deatils.save()

                # This is to update leave quota
                if leave_quota:
                    print("working")
                    leave_quota_deatils = LeaveQuota.objects.filter(
                        emp_id=emp_id,
                        quota_code=leave_quota.quota_code,
                        quota_valid_from__lte=from_date,
                        quota_valid_to__gte=to_date,
                    ).order_by('quota_valid_from')

                    for leave_data in leave_quota_deatils:
                        if float(leave_data.available_leaves) != 0:
                            unique_quota_id = leave_data.unique_quota_id
                            available_leaves = float(
                                leave_data.available_leaves) - float(edp_validation['total_days'])
                            leave_data.available_leaves = str(available_leaves)
                            leave_data.save()
                            break
            else:
                status_code = "500"
                message = leave_validate_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['MESSAGE']

            result = {
                "status_code": status_code,
                # "total_days" : str(edp_validation['total_days']) + "+" + is_lwop + "+" + unique_quota_id,
                "total_days": str(edp_validation['total_days']),
                "unique_quota_id": unique_quota_id,
                "is_lwop": is_lwop,
                "message": message
            }
            return JsonResponse(result, safe=False)
        else:
            result = {
                "status_code": "500",
                "message": ""
            }
            return JsonResponse(result, safe=False)
    except (Exception) as error:
        print_error_v1("validate_leave_request",error)
        result = {
            "validate": False,
            "message": "Unable to validate leave request"
        }
        return result

# This function is to validate leave request from SAP


@csrf_exempt
def validate_leave_request_sap(request):
    leave_request_data = json.loads(request.body)
    print("leave_request", leave_request_data)
    if bool(leave_request_data):

        # This is to get leave group
        leave_category_code = leave_request_data['data'][len(
            leave_request_data['data']) - 1]['leave_category_code']
        leave_group_details = PSGroupLeaveCategoryMapping.objects.filter(
            leave_category_code=leave_category_code).first()
        if not leave_group_details:
            return None

        info_type = "2002"
        if leave_group_details.leave_group == "0":
            info_type = "2001"

        headers = {'content-type': 'text/xml'}
        request_body = common_request_body.leave_validate_update_requst_body

        request_body = request_body.replace(
            "emp_id", leave_request_data['emp_id'])
        request_body = request_body.replace("leave_category", leave_request_data['data'][len(
            leave_request_data['data']) - 1]['leave_category_code'])
        request_body = request_body.replace("leave_type", leave_request_data['data'][len(
            leave_request_data['data']) - 1]['leave_type_code'])
        request_body = request_body.replace("info_type", info_type)
        request_body = request_body.replace("from_date", leave_request_data['data'][len(
            leave_request_data['data']) - 1]['from_date'])
        request_body = request_body.replace("to_date", leave_request_data['data'][len(
            leave_request_data['data']) - 1]['to_date'])
        request_body = request_body.replace("simulation", "Y")
        request_body = request_body.replace("operation", "INS")
        print(request_body)
        response = requests.post(config.leave_validate_update_request_url, data=request_body, headers=headers, auth=(
            config.cv_sap_webservice_id, config.cv_sap_webservice_password))
        print(response.content)
        return response
    else:
        return None

# This function is to validate leave request from edp


@csrf_exempt
def validate_leave_request_edp(request):
    try:
        quota_available = True
        current_date = datetime.now().date()
        valid_date = current_date
        print(valid_date)
        leave_request_data = json.loads(request.body)
        token = request.headers['Authorization'].split()[1]
        headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer' + ' ' + token
        }
        if bool(leave_request_data):
            emp_id = leave_request_data['emp_id']
            from_date = leave_request_data['data'][len(
                leave_request_data['data']) - 1]['from_date']
            to_date = leave_request_data['data'][len(
                leave_request_data['data']) - 1]['to_date']
            leave_category_code = leave_request_data['data'][len(
                leave_request_data['data']) - 1]['leave_category_code']
            leave_type_code = leave_request_data['data'][len(
                leave_request_data['data']) - 1]['leave_type_code']
            leave_category_text = leave_request_data['data'][len(
                leave_request_data['data']) - 1]['leave_category_text']

            data = {
                "emp_id": emp_id,
                "from_date": from_date,
                "to_date": to_date,
                "leave_type_code": leave_type_code
            }
            working_days_details = get_working_days(data)
            if working_days_details['status_code'] == "200":
                attendance_enquiry_data = working_days_details['attendance_enquiry_details']

            # This is to check if early going is in second half or not
            if leave_category_code == "E0":
                if leave_type_code != "SH":
                    result = {
                        "validate": False,
                        "message": "Early going should be applied only in second half"
                    }
                    return result
                if leave_type_code == "SH":
                    # Validating swipe in and swipe out of E0, V0, 10
                    if (attendance_enquiry_data['SWIPE_IN'] == '00:00:00' and leave_category_code == "E0"):
                        result = {
                            "validate": False,
                            "message": "Early going cannot be applied since swipe in details is not available"
                        }
                        return result
                    if (attendance_enquiry_data['SWIPE_OUT'] == '00:00:00' and leave_category_code == "E0"):
                        result = {
                            "validate": False,
                            "message": "Early going cannot be applied since swipe out details is not available"
                        }
                        return result

            # This is to check if late coming is in first half or not
            if leave_category_code == "V0":
                if leave_type_code != "FH":
                    result = {
                        "validate": False,
                        "message": "Late coming should be applied only in first half"
                    }
                    return result
                if leave_type_code == "FH":
                    # Validating swipe in and swipe out of E0, V0, 10
                    if (attendance_enquiry_data['SWIPE_IN'] == '00:00:00' and leave_category_code == "V0"):
                        result = {
                            "validate": False,
                            "message": "Late coming cannot be applied since swipe in details is not available"
                        }
                        return result
                    if (attendance_enquiry_data['SWIPE_OUT'] == '00:00:00' and leave_category_code == "V0"):
                        result = {
                            "validate": False,
                            "message": "Late coming cannot be applied since swipe out details is not available"
                        }
                        return result

            # This is to check if bus late is in first half or not
            if leave_category_code == "F0" and leave_type_code != "FH":
                result = {
                    "validate": False,
                    "message": "Bus late should be applied only in first half"
                }
                return result

            # This is to check if certified no swipe is in full day or not
            if (leave_category_code == "10" and leave_type_code == "FH") or (leave_category_code == "10" and leave_type_code == "SH"):
                result = {
                    "validate": False,
                    "message": "Certified no swipe can only be applied for full day"
                }
                return result

            user = {
                "emp_id": emp_id
            }
            data_to_be_serialized = requests.post(config.get_edp_employee_details, headers=headers, data=json.dumps(data))
            if data_to_be_serialized.status_code != constants.HTTP_200_OK:
                return JsonResponse(return_object_func(constants.HTTP_400_BAD_REQUEST,message.INTERNAL_SERVER_ERROR,{}))
            user_details_json = data_to_be_serialized.json()
            reporting_id = user_details_json.get('user_details')[0].get("Reporting") if user_details_json.get('user_details') \
                and user_details_json.get('user_details')[0].get("Reporting") else None    
            print(reporting_id, emp_id)
            ex_com_list = ExComEmployees.objects.filter(is_active = True).values_list('emp_id',flat=True)    
            if not reporting_id or (reporting_id == '00000000' and emp_id not in ex_com_list):
                result = {
                    "validate": False,
                    "message": message.REPORTING_MANAGER_NOT_FOUND
                }
                return result

            # This is to check if flex is not applied for future date
            if leave_category_code == "FLEX" and to_date > str(valid_date):
                result = {
                    "validate": False,
                    "message": "Unable to apply FLEXI leave for future dates"
                }
                return result
            print(leave_category_text)
            if leave_category_code == "FLEX" and leave_category_text != "Flexibletime -MUCO":

                is_single_leave_data = isinstance(
                    attendance_enquiry_data, dict)
                if is_single_leave_data == True:
                    TOTAL_TIME = datetime.strptime(attendance_enquiry_data['SWIPE_OUT'], '%H:%M:%S') - datetime.strptime(
                        attendance_enquiry_data['SWIPE_IN'], '%H:%M:%S')
                    print("2222", TOTAL_TIME)
                    print(attendance_enquiry_data['SWIPE_IN'])
                    print(attendance_enquiry_data['SWIPE_OUT'])
                    if attendance_enquiry_data['SWIPE_IN'] > '10:00:00':
                        result = {
                            "validate": False,
                            "message": "Unable to apply FLEXI leave on " + datetime.strptime(attendance_enquiry_data['LDATE'], '%Y%m%d').strftime('%d-%m-%Y') + " as Swipe In is after 10 AM"
                        }
                        return result
                    if attendance_enquiry_data['SWIPE_OUT'] < '16:00:00':
                        result = {
                            "validate": False,
                            "message": "Unable to apply FLEXI leave on " + datetime.strptime(attendance_enquiry_data['LDATE'], '%Y%m%d').strftime('%d-%m-%Y') + " as Swipe Out is before 4 PM"
                        }
                        return result
                    if attendance_enquiry_data['SWIPE_IN'] > '10:00:00' and attendance_enquiry_data['SWIPE_OUT'] < '16:00:00':
                        result = {
                            "validate": False,
                            "message": "Unable to apply FLEXI leave on " + datetime.strptime(attendance_enquiry_data['LDATE'], '%Y%m%d').strftime('%d-%m-%Y') + " as Swipe In is before 9 AM and Swipe Out after 4 PM "
                        }
                        return result
                    if datetime.strptime(str(TOTAL_TIME), '%H:%M:%S') < datetime.strptime('09:10:00', '%H:%M:%S'):
                        result = {
                            "validate": False,
                            "message": "Unable to apply FLEXI leave on " + datetime.strptime(attendance_enquiry_data['LDATE'], '%Y%m%d').strftime('%d-%m-%Y') + " as total working hours are less than 9 hrs 10 min"
                        }
                        return result
                else:
                    invalid_date = []
                    for data in attendance_enquiry_data:
                        print("111", data)
                        TOTAL_TIME = datetime.strptime(
                            data['SWIPE_OUT'], '%H:%M:%S') - datetime.strptime(data['SWIPE_IN'], '%H:%M:%S')
                        print("2222", TOTAL_TIME)
                        print(data['SWIPE_IN'])
                        print(data['SWIPE_OUT'])
                        if data['SWIPE_IN'] > '10:00:00':
                            invalid_date.append(datetime.strptime(
                                data['LDATE'], '%Y%m%d').strftime('%d-%m-%Y'))
                            # result = {
                            #     "validate":False,
                            #     "message":"Unable to apply FLEXI leave as In Time on " + datetime.strptime(data['LDATE'], '%Y%m%d').strftime('%d-%m-%Y') + " is after 10 AM"
                            # }
                            # return result
                        if data['SWIPE_OUT'] < '16:00:00':
                            invalid_date.append(datetime.strptime(
                                data['LDATE'], '%Y%m%d').strftime('%d-%m-%Y'))
                            # result = {
                            #     "validate":False,
                            #     "message":"Unable to apply FLEXI leave as Out Time on " + datetime.strptime(data['LDATE'], '%Y%m%d').strftime('%d-%m-%Y') + " is before 4 PM"
                            # }
                            # return result
                        if datetime.strptime(str(TOTAL_TIME), '%H:%M:%S') < datetime.strptime('09:10:00', '%H:%M:%S'):
                            invalid_date.append(datetime.strptime(
                                data['LDATE'], '%Y%m%d').strftime('%d-%m-%Y'))
                            # result = {
                            #     "validate":False,
                            #     "message":"Unable to apply FLEXI leave on " + datetime.strptime(data['LDATE'], '%Y%m%d').strftime('%d-%m-%Y') + " as total working hours are less than 9 hrs 10 min"
                            # }
                            # return result
                    print(invalid_date)
                    unique_invalid_date_str = str(set(invalid_date))
                    for char in "{'}":
                        unique_invalid_date_str = unique_invalid_date_str.replace(
                            char, '')
                    if invalid_date:
                        result = {
                            "validate": False,
                            "message": "Unable to apply FLEXI leave on date " + unique_invalid_date_str + " as request does not meet flexi policy"
                        }
                        return result
            # else:
            #     result = {
            #         "validate":False,
            #         "message":"Unable to validate leave request"
            #     }
            #     return result

            # # This is to check if early going is not applied for current or future date
            # if leave_category_code =="E0" and to_date > str(valid_date):
            #     result = {
            #         "validate":False,
            #         "message":"Early going can not be applied for current and future dates"
            #     }
            #     return result

            # # This is to check if late coming is not applied for current or future date
            # if leave_category_code =="V0" and to_date > str(valid_date):
            #     result = {
            #         "validate":False,
            #         "message":"Late coming can not be applied for current and future dates"
            #     }
            #     return result

            # This is to validate PL Quota is totally consumed before applying for PL Reservoir
            PL_leave_quota = LeaveQuota.objects.filter(
                emp_id=emp_id, quota_code="40").first()
            if PL_leave_quota:
                if leave_category_code == "P1" and PL_leave_quota.available_leaves != '0.0':
                    result = {
                        "validate": False,
                        "message": "PL Quota should be completely consumed before applying leave for PL Reservoir"
                    }
                    return result

            # This is to check if leave request is only of current year or not
            active_year_details = ActiveYear.objects.filter(
                is_active=True).first()
            current_year_ist = int(active_year_details.active_year)
            # current_year_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).year
            from_date_year = datetime.strptime(
                from_date, "%Y-%m-%d").date().year
            to_date_year = datetime.strptime(to_date, "%Y-%m-%d").date().year

            if current_year_ist != from_date_year or current_year_ist != to_date_year:
                result = {
                    "validate": False,
                    "message": "Please apply leave for current year only"
                }
                return result

            # This is to check if early going is in second half or not
            if from_date > to_date:
                result = {
                    "validate": False,
                    "message": "Start date cannot exceed end date"
                }
                return result

            # This is to check count of late coming and early going
            if leave_category_code == "E0" or leave_category_code == "V0":
                from_date_month = datetime.strptime(
                    from_date, "%Y-%m-%d").date().month
                leave_requests_details_edp = LeaveRequestsEDP.objects.filter(
                    Q(requestor_emp_id=emp_id, from_date__month=from_date_month, leave_category="E0", is_deleted=False) |
                    Q(requestor_emp_id=emp_id, from_date__month=from_date_month,
                      leave_category="V0", is_deleted=False)
                ).exclude(leave_status="3")

                leave_requests_details_sap = LeaveRequestsSAP.objects.filter(
                    Q(requestor_emp_id=emp_id, from_date__month=from_date_month, leave_category="E0", is_deleted=False) |
                    Q(requestor_emp_id=emp_id, from_date__month=from_date_month,
                      leave_category="V0", is_deleted=False)
                )

                leave_requests_details_edp = leave_requests_details_edp.exclude(
                    from_date__in=leave_requests_details_sap.all().values_list('from_date')
                )

                leave_count = leave_requests_details_edp.count() + leave_requests_details_sap.count()

                if leave_count >= 2:

                    result = {
                        "validate": False,
                        "message": "Early going and late coming not allowed more than 2 times a month"
                    }
                    return result

            # This is to calulate total woking days
            if leave_type_code == "FD":
                # if from_date == to_date:
                # total_days = 1.0
                # else:

                if leave_category_code == "RL" or leave_category_code == "D0":
                    leave_from_date = datetime.strptime(
                        from_date, "%Y-%m-%d").date()
                    leave_to_date = datetime.strptime(
                        to_date, "%Y-%m-%d").date()

                    delta = leave_to_date - leave_from_date
                    total_days = float(delta.days) + 1.0
                else:
                    data = {
                        "emp_id": emp_id,
                        "from_date": from_date,
                        "to_date": to_date,
                        "leave_type_code": leave_type_code
                    }
                    working_days_details = get_working_days(data)
                    if working_days_details['status_code'] == "200":
                        total_days = working_days_details['total_working_days']
                    else:
                        result = {
                            "validate": False,
                            "message": "Unable to validate leave request"
                        }
                        return result
                    # leave_from_date = datetime.strptime(from_date, "%Y-%m-%d").date()
                    # leave_to_date = datetime.strptime(to_date, "%Y-%m-%d").date()

                    # delta = leave_to_date - leave_from_date
                    # total_days = float(delta.days) + 1.0

            else:
                data = {
                    "emp_id": emp_id,
                    "from_date": from_date,
                    "to_date": to_date,
                    "leave_type_code": leave_type_code
                }
                working_days_details = get_working_days(data)
                if working_days_details['status_code'] == "200":
                    total_days = working_days_details['total_working_days']
                else:
                    result = {
                        "validate": False,
                        "message": "Unable to validate leave request"
                    }
                    return result
                # total_days = 0.5

            # This is to validate Paternity leave less than 10 days
            if leave_category_code == "D3" and total_days > 10:
                result = {
                    "validate": False,
                    "message": "Paternity leave should not exceed more than 10 days"
                }
                return result

            # This is to validate Paternity leave is not validating if 2 leave have days more than 10
            if leave_category_code == "D3":
                Paternity_leave = LeaveRequestsEDP.objects.filter(
                    requestor_emp_id=emp_id, leave_category="D3", is_deleted=False).exclude(leave_status="3").first()
                if Paternity_leave:
                    if float(Paternity_leave.total_days) + total_days > 10:
                        result = {
                            "validate": False,
                            "message": "2 Paternity leave should not exceed more than 10 days for current year"
                        }
                        return result

            # This is to check leave category againest active quota
            active_quota_details = ActiveQuotaDetails.objects.filter(
                emp_id=emp_id).first()
            for quota_code in active_quota_details.active_quota_code:
                leave_quota_code_details = QuotaLeaveCategoryMapping.objects.filter(
                    leave_category=leave_category_code, quota_code=quota_code).first()
                if leave_quota_code_details:
                    break

            # This is to check quota availabe or not
            # if leave_quota_code_details:
            #     leave_quota_deatils = LeaveQuota.objects.filter(emp_id= emp_id , quota_code = leave_quota_code_details.quota_code).first()
            #     if (leave_quota_deatils and total_days > float(leave_quota_deatils.available_leaves)):
            #         result = {
            #             "validate":False,
            #             "message":"Quota not available, some leaves might be in progress"
            #         }
            #         return result

            # This is to check quota availabe or not
            if leave_quota_code_details:
                # print("working --------------------------------->")
                leave_quota_deatils = LeaveQuota.objects.filter(
                    Q(emp_id=emp_id, quota_code=leave_quota_code_details.quota_code, quota_valid_from__lte=from_date, quota_valid_to__gte=from_date) |
                    Q(emp_id=emp_id, quota_code=leave_quota_code_details.quota_code, quota_valid_from__lte=to_date, quota_valid_to__gte=to_date) |
                    Q(emp_id=emp_id, quota_code=leave_quota_code_details.quota_code,
                      quota_valid_from__gte=from_date, quota_valid_to__lte=to_date)
                ).order_by("quota_valid_from")

                if not leave_quota_deatils:
                    quota_available = False

                for leave_data in leave_quota_deatils:
                    if (leave_quota_deatils and total_days > float(leave_data.available_leaves)):
                        quota_available = False
                    else:
                        quota_available = True
                        break

                if quota_available == False:
                    result = {
                        "validate": False,
                        "message": "Quota not available, some leaves might be in progress"
                    }
                    return result

            # This is to check leave is applied on same date or not
            leave_requests_details = LeaveRequestsEDP.objects.filter(
                Q(requestor_emp_id=emp_id, from_date__lte=from_date, to_date__gte=from_date, is_deleted=False) |
                Q(requestor_emp_id=emp_id, from_date__lte=to_date, to_date__gte=to_date, is_deleted=False) |
                Q(requestor_emp_id=emp_id, from_date__gte=from_date,
                  to_date__lte=to_date, is_deleted=False)
            ).exclude(leave_status="3")

            if leave_requests_details:
                leave_requests_details_json = get_serialize_data(
                    leave_requests_details)
                print(leave_requests_details_json)
                for data in leave_requests_details_json:
                    # This is to validate if Leave Type FD,FH or SH is already present
                    if(data['leave_type'] == leave_type_code):
                        print('1')
                        result = {
                            "validate": False,
                            "message": "Leave is already applied on selected days"
                        }
                        return result

                    # This is to validate if Leave Type FD is already present and
                    # Employee is applying for FH or SH
                    if(data['leave_type'] == "FD" and data['leave_type'] != leave_type_code):
                        print('2')
                        result = {
                            "validate": False,
                            "message": "Leave is already applied on selected days"
                        }
                        return result

                    # This is to validate if Leave Type FH or SH is already present and
                    # Employee is applying for FD
                    if((leave_requests_details_json[0]['leave_type'] == "FH" and leave_type_code == "FD")
                            or (leave_requests_details_json[0]['leave_type'] == "SH" and leave_type_code == "FD")):
                        print('3')
                        result = {
                            "validate": False,
                            "message": "Leave is already applied on selected days"
                        }
                        return result

                    # if leave_requests_details_json[1]:
                    #     if((leave_requests_details_json[1]['leave_type'] == "FH" and leave_type_code == "FD")
                    #     or (leave_requests_details_json[1]['leave_type'] == "SH" and leave_type_code == "FD")):
                    #         print('4')
                    #         result = {
                    #             "validate":False,
                    #             "message":"Leave is already applied on selected days"
                    #         }
                    #         return result
                else:
                    result = {
                        "validate": True,
                        "message": "",
                        "total_days": total_days
                    }
                    return result
            else:
                result = {
                    "validate": True,
                    "message": "",
                    "total_days": total_days
                }
                return result

        else:
            result = {
                "validate": False,
                "message": "Unable to validate leave request"
            }
            return result
    except (Exception) as error:
        print(error)
        result = {
            "validate": False,
            "message": "Unable to validate leave request"
        }
        return result

# This function is to insert data into PA PSA and leave category mapping table


@csrf_exempt
def insert_pa_psa_leave_category_mapping(request):
    data = json.loads(request.body)
    try:
        if bool(data):
            for value in data:
                result = {
                    "leave_categories": value['applicable_leave_categories']
                }
                pa_psa_leave_category_mapping_details = PAPSALeaveCategoryMapping(
                    personal_area=value['personal_area'],
                    personal_sub_area=value['personal_sub_area'],
                    applicable_leave_categories=result
                )
                pa_psa_leave_category_mapping_details.save()

            result = {
                "statusCode": "200",
                "message": "data insert success",
            }
            return JsonResponse(result, safe=False)
        else:
            result = {
                "statusCode": "200",
                "message": "incorrect request body"
            }
            return JsonResponse(result, safe=False)
    except (Exception) as error:
        print(error)
        result = {
            "statusCode": "200",
            "message": "failed to insert data",
        }
        return JsonResponse(result, safe=False)

######################################### Leave Request Section End ########################################

######################################### Leave Approval Section Start #######################################
# This function is to gel list of all approvals

@csrf_exempt
def get_leave_requests_approval(request):
    try:
        user_data = json.loads(request.body)
        token = request.headers['Authorization'].split()[1]
        headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer' + ' ' + token
        }
        # To check if employee id is present in json or not
        if user_data["emp_id"] != "":
            emp_id = user_data["emp_id"]
        else:
            result = {
                "status_code": "500",
                "message": "Invalid employee id"
            }
            return JsonResponse(result, safe=False)

        # This is to get current year IST
        active_year_details = ActiveYear.objects.filter(is_active=True).first()
        current_year_ist = int(active_year_details.active_year)
        # current_year_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).year

        if user_data['approval_type'] == "Leave Request":
            # this is to filter leave request based on leave category and leave status
            if 'filter_type' in user_data:
                if (user_data['leave_category_code'] == "All" and user_data['leave_status_code'] == "All" and user_data['emp_id_value'] == "All"):
                    leave_requests_details_edp = LeaveRequestsEDP.objects.filter(approver_emp_id=emp_id, from_date__year=current_year_ist, is_deleted=False).exclude(
                        Q(leave_status="5") | Q(leave_status="6") | Q(leave_status="7") | Q(leave_status="8") | Q(leave_status="9")).order_by('-modified_date_time')
                elif (user_data['leave_category_code'] == "All" and user_data['leave_status_code'] == "All" and user_data['emp_id_value'] != "All"):
                    leave_requests_details_edp = LeaveRequestsEDP.objects.filter(approver_emp_id=emp_id, requestor_emp_id=user_data['emp_id_value'], from_date__year=current_year_ist, is_deleted=False).exclude(
                        Q(leave_status="5") | Q(leave_status="6") | Q(leave_status="7") | Q(leave_status="8") | Q(leave_status="9")).order_by('-modified_date_time')
                elif (user_data['leave_category_code'] == "All" and user_data['leave_status_code'] != "All" and user_data['emp_id_value'] == "All"):
                    leave_requests_details_edp = LeaveRequestsEDP.objects.filter(approver_emp_id=emp_id, from_date__year=current_year_ist, leave_status=user_data['leave_status_code'], is_deleted=False).exclude(
                        Q(leave_status="5") | Q(leave_status="6") | Q(leave_status="7") | Q(leave_status="8") | Q(leave_status="9")).order_by('-modified_date_time')
                elif (user_data['leave_category_code'] == "All" and user_data['leave_status_code'] != "All" and user_data['emp_id_value'] != "All"):
                    leave_requests_details_edp = LeaveRequestsEDP.objects.filter(approver_emp_id=emp_id, requestor_emp_id=user_data['emp_id_value'], from_date__year=current_year_ist, leave_status=user_data['leave_status_code'], is_deleted=False).exclude(
                        Q(leave_status="5") | Q(leave_status="6") | Q(leave_status="7") | Q(leave_status="8") | Q(leave_status="9")).order_by('-modified_date_time')
                elif (user_data['leave_category_code'] != "All" and user_data['leave_status_code'] == "All" and user_data['emp_id_value'] == "All"):
                    leave_requests_details_edp = LeaveRequestsEDP.objects.filter(approver_emp_id=emp_id, from_date__year=current_year_ist, leave_category=user_data['leave_category_code'], is_deleted=False).exclude(
                        Q(leave_status="5") | Q(leave_status="6") | Q(leave_status="7") | Q(leave_status="8") | Q(leave_status="9")).order_by('-modified_date_time')
                elif (user_data['leave_category_code'] != "All" and user_data['leave_status_code'] == "All" and user_data['emp_id_value'] != "All"):
                    leave_requests_details_edp = LeaveRequestsEDP.objects.filter(approver_emp_id=emp_id, requestor_emp_id=user_data['emp_id_value'], from_date__year=current_year_ist, leave_category=user_data['leave_category_code'], is_deleted=False).exclude(
                        Q(leave_status="5") | Q(leave_status="6") | Q(leave_status="7") | Q(leave_status="8") | Q(leave_status="9")).order_by('-modified_date_time')
                elif (user_data['leave_category_code'] != "All" and user_data['leave_status_code'] != "All" and user_data['emp_id_value'] == "All"):
                    leave_requests_details_edp = LeaveRequestsEDP.objects.filter(approver_emp_id=emp_id, from_date__year=current_year_ist, leave_category=user_data['leave_category_code'], leave_status=user_data['leave_status_code'], is_deleted=False).exclude(
                        Q(leave_status="5") | Q(leave_status="6") | Q(leave_status="7") | Q(leave_status="8") | Q(leave_status="9")).order_by('-modified_date_time')
                elif (user_data['leave_category_code'] != "All" and user_data['leave_status_code'] != "All" and user_data['emp_id_value'] != "All"):
                    leave_requests_details_edp = LeaveRequestsEDP.objects.filter(approver_emp_id=emp_id, requestor_emp_id=user_data['emp_id_value'], from_date__year=current_year_ist, leave_category=user_data['leave_category_code'], leave_status=user_data['leave_status_code'], is_deleted=False).exclude(
                        Q(leave_status="5") | Q(leave_status="6") | Q(leave_status="7") | Q(leave_status="8") | Q(leave_status="9")).order_by('-modified_date_time')
                else:
                    leave_requests_details_edp = LeaveRequestsEDP.objects.filter(approver_emp_id=emp_id, requestor_emp_id=user_data['emp_id_value'], from_date__year=current_year_ist, leave_category=user_data['leave_category_code'], leave_status=user_data['leave_status_code'], is_deleted=False).exclude(
                        Q(leave_status="5") | Q(leave_status="6") | Q(leave_status="7") | Q(leave_status="8") | Q(leave_status="9")).order_by('-modified_date_time')
            else:
                leave_requests_details_edp = LeaveRequestsEDP.objects.filter(approver_emp_id=emp_id, from_date__year=current_year_ist, is_deleted=False).exclude(
                    Q(leave_status="5") | Q(leave_status="6") | Q(leave_status="7") | Q(leave_status="8") | Q(leave_status="9")).order_by('-modified_date_time')
        else:
            # this is to filter leave request based on leave category and leave status
            if 'filter_type' in user_data:
                if (user_data['leave_category_code'] == "All" and user_data['leave_status_code'] == "All" and user_data['emp_id_value'] == "All"):
                    leave_requests_details_edp = LeaveRequestsEDP.objects.filter(approver_emp_id=emp_id, from_date__year=current_year_ist, is_deleted=False).exclude(Q(leave_status="0") | Q(
                        leave_status="1") | Q(leave_status="2") | Q(leave_status="3") | Q(leave_status="4") | Q(leave_status="8") | Q(leave_status="9")).order_by('-modified_date_time')
                elif (user_data['leave_category_code'] == "All" and user_data['leave_status_code'] == "All" and user_data['emp_id_value'] != "All"):
                    leave_requests_details_edp = LeaveRequestsEDP.objects.filter(approver_emp_id=emp_id, requestor_emp_id=user_data['emp_id_value'], from_date__year=current_year_ist, is_deleted=False).exclude(
                        Q(leave_status="0") | Q(leave_status="1") | Q(leave_status="2") | Q(leave_status="3") | Q(leave_status="4") | Q(leave_status="8") | Q(leave_status="9")).order_by('-modified_date_time')
                elif (user_data['leave_category_code'] == "All" and user_data['leave_status_code'] != "All" and user_data['emp_id_value'] == "All"):
                    leave_requests_details_edp = LeaveRequestsEDP.objects.filter(approver_emp_id=emp_id, from_date__year=current_year_ist, leave_status=user_data['leave_status_code'], is_deleted=False).exclude(
                        Q(leave_status="0") | Q(leave_status="1") | Q(leave_status="2") | Q(leave_status="3") | Q(leave_status="4") | Q(leave_status="8") | Q(leave_status="9")).order_by('-modified_date_time')
                elif (user_data['leave_category_code'] == "All" and user_data['leave_status_code'] != "All" and user_data['emp_id_value'] != "All"):
                    leave_requests_details_edp = LeaveRequestsEDP.objects.filter(approver_emp_id=emp_id, requestor_emp_id=user_data['emp_id_value'], from_date__year=current_year_ist, leave_status=user_data['leave_status_code'], is_deleted=False).exclude(
                        Q(leave_status="0") | Q(leave_status="1") | Q(leave_status="2") | Q(leave_status="3") | Q(leave_status="4") | Q(leave_status="8") | Q(leave_status="9")).order_by('-modified_date_time')
                elif (user_data['leave_category_code'] != "All" and user_data['leave_status_code'] == "All" and user_data['emp_id_value'] == "All"):
                    leave_requests_details_edp = LeaveRequestsEDP.objects.filter(approver_emp_id=emp_id, from_date__year=current_year_ist, leave_category=user_data['leave_category_code'], is_deleted=False).exclude(
                        Q(leave_status="0") | Q(leave_status="1") | Q(leave_status="2") | Q(leave_status="3") | Q(leave_status="4") | Q(leave_status="8") | Q(leave_status="9")).order_by('-modified_date_time')
                elif (user_data['leave_category_code'] != "All" and user_data['leave_status_code'] == "All" and user_data['emp_id_value'] != "All"):
                    leave_requests_details_edp = LeaveRequestsEDP.objects.filter(approver_emp_id=emp_id, requestor_emp_id=user_data['emp_id_value'], from_date__year=current_year_ist, leave_category=user_data['leave_category_code'], is_deleted=False).exclude(
                        Q(leave_status="0") | Q(leave_status="1") | Q(leave_status="2") | Q(leave_status="3") | Q(leave_status="4") | Q(leave_status="8") | Q(leave_status="9")).order_by('-modified_date_time')
                elif (user_data['leave_category_code'] != "All" and user_data['leave_status_code'] != "All" and user_data['emp_id_value'] == "All"):
                    leave_requests_details_edp = LeaveRequestsEDP.objects.filter(approver_emp_id=emp_id, from_date__year=current_year_ist, leave_category=user_data['leave_category_code'], leave_status=user_data['leave_status_code'], is_deleted=False).exclude(
                        Q(leave_status="0") | Q(leave_status="1") | Q(leave_status="2") | Q(leave_status="3") | Q(leave_status="4") | Q(leave_status="8") | Q(leave_status="9")).order_by('-modified_date_time')
                elif (user_data['leave_category_code'] != "All" and user_data['leave_status_code'] != "All" and user_data['emp_id_value'] != "All"):
                    leave_requests_details_edp = LeaveRequestsEDP.objects.filter(approver_emp_id=emp_id, requestor_emp_id=user_data['emp_id_value'], from_date__year=current_year_ist, leave_category=user_data['leave_category_code'], leave_status=user_data['leave_status_code'], is_deleted=False).exclude(
                        Q(leave_status="0") | Q(leave_status="1") | Q(leave_status="2") | Q(leave_status="3") | Q(leave_status="4") | Q(leave_status="8") | Q(leave_status="9")).order_by('-modified_date_time')
                else:
                    leave_requests_details_edp = LeaveRequestsEDP.objects.filter(approver_emp_id=emp_id, requestor_emp_id=user_data['emp_id_value'], from_date__year=current_year_ist, leave_category=user_data['leave_category_code'], leave_status=user_data['leave_status_code'], is_deleted=False).exclude(
                        Q(leave_status="0") | Q(leave_status="1") | Q(leave_status="2") | Q(leave_status="3") | Q(leave_status="4") | Q(leave_status="8") | Q(leave_status="9")).order_by('-modified_date_time')
            else:
                leave_requests_details_edp = LeaveRequestsEDP.objects.filter(approver_emp_id=emp_id, from_date__year=current_year_ist, is_deleted=False).exclude(Q(leave_status="0") | Q(
                    leave_status="1") | Q(leave_status="2") | Q(leave_status="3") | Q(leave_status="4") | Q(leave_status="8") | Q(leave_status="9")).order_by('-modified_date_time')
        if leave_requests_details_edp:
            leave_requests_details_edp_json = get_serialize_data(
                leave_requests_details_edp)

            for data in leave_requests_details_edp_json:
                # This is to get employee name from employee servives
                user = {
                    "emp_id": data['requestor_emp_id']
                }
                data_to_be_serialized = requests.post(config.get_edp_employee_details, headers=headers, data=json.dumps(user))
                user_details_json = data_to_be_serialized.json()
                print(user_details_json)

                # To add employee name in json
                data['requestor_name'] = user_details_json['user_details'][0]['CompName']

                # to get leave category text
                leave_category_code = data['leave_category']
                data['leave_category'] = get_leave_category_text(
                    user_details_json['user_details'][0]['PersArea'], user_details_json['user_details'][0]['PSubarea'], leave_category_code)
                data['leave_category_code'] = leave_category_code

                #This is used to leave category color by code.
                leave_category_color_data = PSGroupLeaveCategoryMapping.objects.filter(leave_category_code=leave_category_code).first()
                if leave_category_color_data:
                    data['leave_category_color'] = leave_category_color_data.leave_categrory_color
                else:
                    data['leave_category_color'] = ''

                # To get leave type text
                leave_type_code = data['leave_type']
                leave_type_details = LeaveType.objects.filter(
                    leave_type_code=leave_type_code).first()
                if leave_type_details:
                    data['leave_type'] = leave_type_details.leave_type_text
                else:
                    data['leave_type'] == ""

                data['leave_type_code'] = leave_type_code

                # To get leave status text
                leave_status_code = data['leave_status']
                leave_status_details = LeaveStatus.objects.filter(
                    leave_status_code=leave_status_code).first()
                if leave_status_details:

                    data['leave_status_code'] = leave_status_code
                    data['leave_status'] = leave_status_details.leave_status_text
                    data['leave_status_color'] = leave_status_details.leave_status_color
                else:
                    data['leave_status_code'] = ""
                    data['leave_status'] == ""
                    data['leave_status_color'] = ''

            result = {
                "status_code": "200",
                "message": "",
                "data": {
                    "leave_requests_approval": leave_requests_details_edp_json,
                }
            }
            return JsonResponse(result, safe=False)
        else:
            result = {
                "status_code": "200",
                "message": "",
                "data": {
                    "leave_requests_approval": [],
                }
            }
            return JsonResponse(result, safe=False)
    except (Exception) as error:
        print(error)
        result = {
            "status_code": "500",
            "message": "Something went wrong"
        }
        return JsonResponse(result, safe=False)

# This function is to aprrove leave
@csrf_exempt
def leave_request_approval(request):
    # This is to check is post request or simple function call
    if type(request) is dict:
        leave_request_data = request
    else:
        leave_request_data = json.loads(request.body)
    if bool(leave_request_data):
        try:
            print('leave_request_data', leave_request_data)
            platform = "Other"
            if 'platform' in leave_request_data:
                platform = "chat-bot"
            for data in leave_request_data['data']:
                # This is to update status in leave request edp table
                leave_request_details = LeaveRequestsEDP.objects.filter(
                    leave_request_id=data['leave_request_id']).first()
                notification_to_id = data['requestor_emp_id']
                user = {
                        "emp_id": data['requestor_emp_id']
                }
                response = session.post(config.get_edp_employee_details, data=json.dumps(user))
                user_details = response.content.decode("utf-8")
                user_details_json = json.loads(user_details)
                emp_name = user_details_json['user_details'][0]['CompName']

                if leave_request_details:
                    # if leave_request_data['approval_type'] == "leave_request":
                    if leave_request_data['action'] == "0":
                        leave_status = "1"
                    else:
                        leave_status = "3"

                    leave_request_details.leave_status = leave_status
                    leave_request_details.modified_date_time = datetime.now()
                    leave_request_details.modified_by = leave_request_data['emp_id']
                    leave_request_details.save()

                    # Get the from date and to date for push notification request body
                    leave_from_date = leave_request_details.from_date
                    leave_to_date = leave_request_details.to_date
                    leave_category_code = leave_request_details.leave_category
                    leave_type_code = leave_request_details.leave_type
                    requestor_email = leave_request_details.requestor_email
                    approver_email = leave_request_details.approver_email

                print("before approved")
                # This is to add record in leave approval table
                leave_approval_details = LeaveApproval(
                    leave_approval_id=uuid.uuid4(),
                    leave_request_id=data['leave_request_id'],
                    requestor_emp_id=data['requestor_emp_id'],
                    action_taken=leave_request_data['action'],
                    action_owner=leave_request_data['emp_id'],
                    approval_type=leave_request_data['approval_type'],
                    created_date_time=datetime.now(),
                    modified_date_time=datetime.now(),
                    created_by=leave_request_data['emp_id'],
                    modified_by=leave_request_data['emp_id'],
                )
                leave_approval_details.save()
                print("approved")

                # This is to add approved leave in table
                if leave_request_data['action'] == "0":
                    # this is to collect all approved leaves
                    approved_leave_request = ApprovedLeaveRequests(
                        leave_request_id=data['leave_request_id'],
                        created_date_time=datetime.now()
                    )
                    approved_leave_request.save()

                # This is to create leave request notification
                notification_details = {
                    "requestor_emp_id": data['requestor_emp_id'],
                    "approver_emp_id": leave_request_data['emp_id'],
                    "leave_request_id": data['leave_request_id'],
                    "notification_type": "Leave Approval",
                    "action": leave_request_data['action']
                }
                response = session.post(
                    config.create_leave_approval_notification_url, data=json.dumps(notification_details))


            if leave_request_data['action'] == "0":
                result = {
                    "status_code": "200",
                    "message": "Leaves approved sucessfully"
                }
                # InterService Call to Store Activity Log
                activity_details = {
                    "leave_request_id": data['leave_request_id'],
                    "emp_id": leave_request_data['emp_id'],
                    "browser": str(request.user_agent.browser.family),
                    "device_type": str(request.user_agent.device.family),
                    "operating_system": str(request.user_agent.os.family),
                    "action": 'Leave-Approved',
                    "platform":platform
                }
                # print("token")
                token = request.headers['Authorization'].split()[1]
                headers = {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer' + ' ' + token
                }
                response = session.post(
                    config.create_activity_log_url, headers=headers, data=json.dumps(activity_details))
                print('Activity Log', response)
                 # This is to get leave type text
                leave_type_details = LeaveType.objects.filter(leave_type_code=leave_type_code).first()
                leave_type_text = leave_type_details.leave_type_text
                print(leave_type_text)
                leave_category= get_leave_category_text_emp_id(leave_request_details.leave_category, leave_request_details.requestor_emp_id)
                print(leave_category)
                # This is used to send push notification to user
                push_notification_request_body = {
                    "notification_for": "employee",
                    "notification_to": notification_to_id,
                    "notification_content": "Your " + get_leave_category_text_emp_id(leave_category_code, leave_request_data['emp_id']) + " request has been approved from "+date_format_conversion(str(leave_from_date))+" to " + date_format_conversion(str(leave_to_date)),
                    "notification_type": "Leave",
                    "notification_title": "Leave Approval",
                    "data_content": "Your " + get_leave_category_text_emp_id(leave_category_code, leave_request_data['emp_id']) + " request has been approved from "+date_format_conversion(str(leave_from_date))+" to " + date_format_conversion(str(leave_to_date)),
                    "data_title": "Leave Approval",
                    "data_type":  "Leave Request",
                    "screen_type": "LeaveListing",
                    "request_from":"show_leave_approve_reject",

                } 
                print('push_notification_request -->', push_notification_request_body)
                push_notification_response = insert_push_notification(
                    json.dumps(push_notification_request_body))
                # This is for call kafka producer  
                leave_text_card_notification={
                    "eventType":constants.LEAVE_APPROVAL_NOTIFICATION,
                    "adaptiveCardType":constants.TEXT_CARD,
                    "employeeId":leave_request_details.requestor_emp_id,
                    "emailId":leave_request_details.requestor_email,
                    "receiverId":leave_request_details.requestor_emp_id,  
                    "leaveType": leave_category,
                    "absenceType":leave_type_text ,
                    "startDate":str(leave_request_details.from_date),
                    "endDate": str(leave_request_details.to_date),
                    "leaveReason":leave_request_details.reason,
                    "comp_code":constants.TMCV
                     }
                print("approve",leave_text_card_notification)
                kafka_text_card_leave = requests.post(config.producer_leave_notification, headers=headers,timeout = 5, data=json.dumps(leave_text_card_notification))

            else:
                result = {
                    "status_code": "200",
                    "message": "Leaves rejected sucessfully"
                }
                # InterService Call to Store Activity Log
                activity_details = {
                    "leave_request_id": data['leave_request_id'],
                    "emp_id": leave_request_data['emp_id'],
                    "browser": str(request.user_agent.browser.family),
                    "device_type": str(request.user_agent.device.family),
                    "operating_system": str(request.user_agent.os.family),
                    "action": 'Leave-Rejected',
                    "platform":platform
                }
                token = request.headers['Authorization'].split()[1]
                headers = {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer' + ' ' + token
                }
                response = session.post(
                    config.create_activity_log_url, headers=headers, data=json.dumps(activity_details))
                print('Activity Log', response)
                   # This is to get leave type text
                leave_type_details = LeaveType.objects.filter(leave_type_code=leave_type_code).first()
                leave_type_text = leave_type_details.leave_type_text
                print(leave_type_text)
                leave_category= get_leave_category_text_emp_id(leave_request_details.leave_category, leave_request_details.requestor_emp_id)
                print(leave_category)
                # This is used to send push notification to employee
                push_notification_request_body = {
                    "notification_for": "employee",
                    "notification_to": notification_to_id,
                    "notification_content": "Your " + get_leave_category_text_emp_id(leave_category_code, leave_request_data['emp_id']) + " request has been rejected from "+date_format_conversion(str(leave_from_date))+" to " + date_format_conversion(str(leave_to_date)),
                    "notification_type": "Leave",
                    "notification_title": "Leave Rejected",
                    "data_content": "Your " + get_leave_category_text_emp_id(leave_category_code, leave_request_data['emp_id']) + " request has been rejected from "+date_format_conversion(str(leave_from_date))+" to " + date_format_conversion(str(leave_to_date)),
                    "data_title": "Leave Rejected",
                    "data_type":  "Leave Request",
                    "screen_type": "LeaveListing",
                    "request_from":"show_leave_approve_reject",

                }
                push_notification_response = insert_push_notification(
                    json.dumps(push_notification_request_body))
                  # This is for call kafka producer  
                leave_text_card_notification={
                    "eventType":constants.LEAVE_REJECT,
                    "adaptiveCardType":constants.TEXT_CARD,
                    "employeeId":leave_request_details.requestor_emp_id,
                    "emailId":leave_request_details.requestor_email,
                    "receiverId":leave_request_details.requestor_emp_id,  
                    "leaveType": leave_category,
                    "absenceType":leave_type_text ,
                    "startDate":str(leave_request_details.from_date),
                    "endDate": str(leave_request_details.to_date),
                    "leaveReason":leave_request_details.reason,
                    "comp_code":constants.TMCV
                }
                print("REJECT",leave_text_card_notification)
                kafka_text_card_leave = requests.post(config.producer_leave_notification, headers=headers, timeout = 5 ,data=json.dumps(leave_text_card_notification))

                #Request Body for leave request application mail template - NOT IN USE FOR NOW..
                request_body_for_mail_template = {
                    constants.LEAVE_CATEGORY_MAIL: constants.LEAVE_REJECT,
                    constants.EMP_ID:leave_request_details.requestor_emp_id,
                    constants.EMP_NAME:emp_name,
                    constants.LEAVE_TYPE:leave_category,
                    constants.ABSENCE_TYPE:leave_type_text,
                    constants.START_DATE:str(leave_request_details.from_date),
                    constants.END_DATE:  str(leave_request_details.to_date),
                    constants.LEAVE_REASON: leave_request_details.reason,
                    constants.TO_MAIL_ADDRESS:requestor_email,
                    constants.CC_MAIL_ADDRESS:approver_email,
                    constants.LEAVE_REQUESTOR_ROLE : constants.EMPLOYEE_ROLE,
                    # constants.LEAVE_REQUEST_UNIQUE_ID: leave_request_id
                }
                mail_response = leave_application_mail(request_body_for_mail_template)
                print("mail response",mail_response)              
            # This is to check is post request or simple function call
            if type(request) is dict:
                return result
            else:
                return JsonResponse(result, safe=False)

        except (Exception) as error:
            print_error_v1("leave_request_approval", error)
            result = {
                "status_code": "500",
                "message": "Failed to approve leaves"
            }
            # This is to check is post request or simple function call
            if type(request) is dict:
                return result
            else:
                return JsonResponse(result, safe=False)
    else:
        result = {
            "status_code": "500",
            "message": ""
        }
        # This is to check is post request or simple function call
        if type(request) is dict:
            return result
        else:
            return JsonResponse(result, safe=False)

# This function is to aprrove leave


@csrf_exempt
def auto_leave_request_approval(request):
    # This is to check is post request or simple function call
    if type(request) is dict:
        leave_request_data = request
    else:
        leave_request_data = json.loads(request.body)

    if bool(leave_request_data):
        try:
            # token = request.headers['Authorization'].split()[1]
            # headers = {
            #         'Content-Type': 'application/json',
            #         'Authorization': 'Bearer' + ' ' + token
            # }
            for data in leave_request_data['data']:
                # This is to update status in leave request edp table
                leave_request_details = LeaveRequestsEDP.objects.filter(
                    leave_request_id=data['leave_request_id']).first()
                if leave_request_details:
                    # if leave_request_data['approval_type'] == "leave_request":
                    notification_to_id = data['requestor_emp_id']
                    if leave_request_data['action'] == "0":
                        leave_status = "1"
                    else:
                        leave_status = "3"
                    # else:
                    #     if leave_request_data['action'] == "0":
                    #         leave_status = "6"
                    #     else:
                    #         leave_status = "4"

                    leave_request_details.leave_status = leave_status
                    leave_request_details.modified_date_time = datetime.now()
                    leave_request_details.modified_by = leave_request_data['emp_id']
                    leave_request_details.save()

                    # Get the from date and to date for push notification request body
                    leave_from_date = leave_request_details.from_date
                    leave_to_date = leave_request_details.to_date
                    leave_category_code = leave_request_details.leave_category
                    leave_type_code = leave_request_details.leave_type

                # This is to add record in leave approval table
                leave_approval_details = LeaveApproval(
                    leave_approval_id=uuid.uuid4(),
                    leave_request_id=data['leave_request_id'],
                    requestor_emp_id=data['requestor_emp_id'],
                    action_taken=leave_request_data['action'],
                    action_owner=leave_request_data['emp_id'],
                    approval_type=leave_request_data['approval_type'],
                    created_date_time=datetime.now(),
                    modified_date_time=datetime.now(),
                    created_by=leave_request_data['emp_id'],
                    modified_by=leave_request_data['emp_id'],
                )
                leave_approval_details.save()

                # This is to add approved leave in table
                if leave_request_data['action'] == "0":
                    # this is to collect all approved leaves
                    approved_leave_request = ApprovedLeaveRequests(
                        leave_request_id=data['leave_request_id'],
                        created_date_time=datetime.now()
                    )
                    approved_leave_request.save()

                # This is to create leave request notification
                notification_details = {
                    "requestor_emp_id": data['requestor_emp_id'],
                    "approver_emp_id": leave_request_data['emp_id'],
                    "leave_request_id": data['leave_request_id'],
                    "notification_type": "Leave Auto Approval",
                    "action": leave_request_data['action']
                }
                response = session.post(
                    config.create_leave_approval_notification_url, data=json.dumps(notification_details))

                # This is for team bot notification api
                # team_notification_action = "Approved" if leave_request_data[
                #     'action'] == "0" else "Rejected"

                # request_body_teams = [
                #     {
                #         "Type": "Leave Request",
                #         "Contents": [
                #                 {
                #                     "req_id": leave_request_details.requestor_emp_id,
                #                     "leave_type": leave_request_details.leave_category,
                #                     "from_date": str(leave_request_details.from_date),
                #                     "to_date": str(leave_request_details.to_date),
                #                     "action_by": leave_request_details.approver_email
                #                 }
                #         ],
                #         "Action": team_notification_action,
                #         "Reason": "",
                #         "Recipient": leave_request_details.requestor_email,
                #     }
                # ]
                # teams_notification_response = teams_notification(
                #     json.dumps(request_body_teams))

                # This is for create push notification
                  # This is to get leave type text
                leave_type_details = LeaveType.objects.filter(leave_type_code=leave_type_code).first()
                leave_type_text = leave_type_details.leave_type_text
                print(leave_type_text)
                leave_category= get_leave_category_text_emp_id(leave_request_details.leave_category, leave_request_details.requestor_emp_id)
                print(leave_category)
                push_notification_request_body = {
                    "notification_for": "employee",
                    "notification_to": notification_to_id,
                    "notification_content":  "Your " + get_leave_category_text_emp_id(leave_category_code, data['requestor_emp_id']) + " request has been auto approved from "+date_format_conversion(str(leave_from_date))+" to "+date_format_conversion(str(leave_to_date)),
                    "notification_type": "Leave",
                    "notification_title": "Leave Auto Approval",
                    "data_content": "Your " + get_leave_category_text_emp_id(leave_category_code, data['requestor_emp_id']) + " request has been auto approved from "+date_format_conversion(str(leave_from_date))+" to "+date_format_conversion(str(leave_to_date)),
                    "data_title": "Leave Auto Approval",
                    "data_type":  "Leave Request",
                    "screen_type": "LeaveListing",
                    "request_from":"show_leave_approve_reject",


                }
                push_notification_response = insert_push_notification(
                    json.dumps(push_notification_request_body))
                leave_text_card_notification={
                    "eventType":constants.LEAVE_AUTO_APPROVED,
                    "adaptiveCardType":constants.TEXT_CARD,
                    "employeeId":leave_request_details.requestor_emp_id,
                    "emailId":leave_request_details.requestor_email,
                    "receiverId":leave_request_details.requestor_emp_id,  
                    "leaveType": leave_category,
                    "absenceType":leave_type_text ,
                    "startDate":str(leave_request_details.from_date),
                    "endDate": str(leave_request_details.to_date),
                    "leaveReason":leave_request_details.reason,
                    "comp_code":constants.TMCV
                }
                print("auto-approve",leave_text_card_notification)
                kafka_text_card_leave = requests.post(config.producer_leave_notification,timeout = 5 , data=json.dumps(leave_text_card_notification))
            if leave_request_data['action'] == "0":
                result = {
                    "status_code": "200",
                    "message": "Leaves approved sucessfully"
                }
            else:
                result = {
                    "status_code": "200",
                    "message": "Leaves rejected sucessfully"
                }

            # This is to check is post request or simple function call
            if type(request) is dict:
                return result
            else:
                return JsonResponse(result, safe=False)

        except (Exception) as error:
            print(error)
            result = {
                "status_code": "500",
                "message": "Failed to approve leaves"
            }
            # This is to check is post request or simple function call
            if type(request) is dict:
                return result
            else:
                return JsonResponse(result, safe=False)
    else:
        result = {
            "status_code": "500",
            "message": ""
        }
        # This is to check is post request or simple function call
        if type(request) is dict:
            return result
        else:
            return JsonResponse(result, safe=False)

# This is to auto approve leave request and delete leave request.


@csrf_exempt
def leave_request_auto_approval():
    try:
        scheduler_name = constants.LEAVE_REQUEST_AUTO_APPROVAL
        start_scheduler = LeaveSchedulerConfig.objects.filter(scheduler_name = scheduler_name).first()
        if not start_scheduler or (start_scheduler.is_active == False):
            print("Scheduler stopped due to executing leave without pay program.")
            status = constants.STOPPED
            description = message.SCHEDULER_STOPPED
            leave_scheduler_logs(scheduler_name,status,description)
            return return_response_func(request, return_object_func(constants.HTTP_400_BAD_REQUEST, message.SCHEDULER_STOPPED, {}))
        print("approval start ")
        # This is to calculate auto approval date
        current_date = datetime.now().date()
        auto_approval_date = current_date - \
            timedelta(days=config.auto_approval_days)

        # This is to check pending leave request
        leave_requests_details = LeaveRequestsEDP.objects.filter(Q(leave_status="0", applied_date__lte=auto_approval_date, is_deleted=False) |
                                                                 Q(leave_status="5", applied_date__lte=auto_approval_date, is_deleted=False))

        if leave_requests_details:
            leave_requests_details_json = get_serialize_data(
                leave_requests_details)
            print("leave_requests_details_json", leave_requests_details_json)
            for data in leave_requests_details_json:

                # this is to covert single object into list
                request_details = []
                request_details.append(data)

                if data['leave_status'] == "0":
                    request = {
                        "emp_id": data['approver_emp_id'],
                        "data": request_details,
                        "action": "0",
                        "approval_type": "leave_request"
                    }
                    auto_leave_request_approval(request)
                if data['leave_status'] == "5":
                    request = {
                        "emp_id": data['approver_emp_id'],
                        "data": request_details,
                        "action": "0",
                        "approval_type": "leave_request"
                    }
                    auto_delete_leave_request_approval(request)
    except Exception as error:
        print(error)
######################################### Leave Approval Section end   #######################################

######################################### Delete Leave Section Start #######################################
# This function is to delete leave request in edp


@csrf_exempt
def delete_leave_request(request):
    try:
        delete_leave_request_data = json.loads(request.body)
        print("delete_leave_request_data",delete_leave_request_data)
        if bool(delete_leave_request_data):
            platform = "Other"
            if 'platform' in delete_leave_request_data:
                platform = "chat-bot"

            #This is to check cross company manager 
            if 'emp_company_code' in delete_leave_request_data and 'manager_company_code' in delete_leave_request_data:
                if delete_leave_request_data['emp_company_code'] != delete_leave_request_data['manager_company_code']:
                    result = cross_company_reporting_delete_leave_request(request)
                    return JsonResponse(result, safe=False)

            # leave_request_id = delete_leave_request_data['leave_request_id']
            emp_id = delete_leave_request_data['emp_id']
            from_date = delete_leave_request_data['from_date']
            to_date = delete_leave_request_data['to_date']
            leave_status = delete_leave_request_data['leave_status']
            pa = delete_leave_request_data['pa']
            psa = delete_leave_request_data['psa']
            leave_request_id = delete_leave_request_data['leave_request_id']
            if leave_status == "9":
                result = {
                    "status_code": "200",
                    "message": "You are not allowed to delete this leave request. Please contact time-office for further details"
                }
                return JsonResponse(result, safe=False)

            if leave_status == "3" or leave_status == "5" or leave_status == "6":
                result = {
                    "status_code": "200",
                    "message": "You are not allowed to delete this leave request."
                }
                return JsonResponse(result, safe=False)

            # This is to get leave request details
            delete_leave_status = ['3','7','9','8']
            leave_requests_details_edp = LeaveRequestsEDP.objects.filter(
                requestor_emp_id=emp_id, from_date=from_date, to_date=to_date, is_deleted=False).exclude(leave_status__in=delete_leave_status).first()
            # leave_requests_details_edp = LeaveRequestsEDP.objects.filter(requestor_emp_id=emp_id, from_date=from_date, to_date=to_date,is_deleted=False,leave_status=leave_status).first()
            # leave_requests_details_edp = LeaveRequestsEDP.objects.filter(requestor_emp_id=emp_id,leave_request_id=leave_request_id).first()
            if bool(leave_requests_details_edp):

                # This is to delete leaves in status pending for approval and error in posting
                if leave_requests_details_edp.leave_status == "0" or leave_requests_details_edp.leave_status == "8":
                    leave_requests_details_edp.is_deleted = True
                    leave_requests_details_edp.leave_status = "7"
                    leave_requests_details_edp.save()

                    leave_againest_lwop_details = LeaveAgainstLWOP.objects.filter(
                        leave_request_id=leave_requests_details_edp.leave_request_id).first()
                    if leave_againest_lwop_details:
                        leave_againest_lwop_details.delete()

                    approved_leave_requests_details = ApprovedLeaveRequests.objects.filter(
                        leave_request_id=leave_requests_details_edp.leave_request_id).first()
                    if approved_leave_requests_details:
                        approved_leave_requests_details.delete()

                    # This is to insert leave requst timestamp
                    sap_posting_details = SAPPostingDetails.objects.filter(
                        leave_request_id=leave_requests_details_edp.leave_request_id).first()
                    if sap_posting_details:
                        sap_posting_details.delete_leave_datetime = datetime.now()
                        sap_posting_details.created_by = "SYSTEM"
                        sap_posting_details.modified_by = "SYSTEM"
                        sap_posting_details.save()

                    result = {
                        "status_code": "200",
                        "message": "Leave request sucessfully deleted"
                    }
                    return JsonResponse(result, safe=False)
                else:
                    # This is to delete the leave having status other pending for approval
                    leave_requests_details_edp.leave_status = "5"
                    leave_requests_details_edp.save()

                    approved_leave_request_details = ApprovedLeaveRequests.objects.filter(
                        leave_request_id=leave_requests_details_edp.leave_request_id).first()
                    if approved_leave_request_details:
                        approved_leave_request_details.delete()

                    # # # This is to remove the approved leave in table
                    # approved_leave_request_details = ApprovedLeaveRequests.objects.filter(leave_request_id = leave_request_id).first()
                    # if approved_leave_request_details:
                    #     approved_leave_request_details.delete()

                    # this is check the approval_email is empty or not and if it's empty assign
                    if "approver_email" not in delete_leave_request_data:
                        delete_leave_request_data['approver_email'] = "drishti-alerts@tatamotors.com"

                    if delete_leave_request_data['approver_email'] != "":
                        leave_category_text = ""
                        leave_type_text = ""
                        # To create email subject
                        current_datetime_ist = datetime.now() + timedelta(hours=5, minutes=30)
                        current_date_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).date()
                        email_subject = delete_leave_request_data['emp_id'] + """ - """ + delete_leave_request_data['emp_name'] + \
                            """ - Delete Leave Request Notification - """ + \
                            str(current_datetime_ist.date())

                        # This is to get leave category text
                        ps_group_details = PAPSAGroupMapping.objects.filter(
                            pa_code=pa, psa_code=psa).first()
                        if ps_group_details:
                            leave_category_details = PSGroupLeaveCategoryMapping.objects.filter(
                                pa_psa_group=ps_group_details.pa_psa_group, leave_category_code=delete_leave_request_data['leave_category_code'], valid_from__lte=current_date_ist, valid_to__gte=current_date_ist).first()
                            if leave_category_details:
                                leave_category_text = leave_category_details.leave_category_text

                        # This is to get leave type text
                        leave_type_details = LeaveType.objects.filter(
                            leave_type_code=delete_leave_request_data['leave_type_code']).first()
                        if leave_type_details:
                            leave_type_text = leave_type_details.leave_type_text

                            
                        #Request Body - Delete leave application mail
                        request_body_for_mail_template = {
                            constants.LEAVE_CATEGORY_MAIL: constants.LEAVE_DELETE,
                            constants.EMP_ID:delete_leave_request_data['emp_id'],
                            constants.EMP_NAME:delete_leave_request_data['emp_name'],
                            constants.LEAVE_TYPE:leave_category_text,
                            constants.ABSENCE_TYPE:leave_type_text,
                            constants.START_DATE: delete_leave_request_data['from_date'],
                            constants.END_DATE:  delete_leave_request_data['to_date'],
                            constants.LEAVE_REASON: delete_leave_request_data['reason'],
                            constants.TO_MAIL_ADDRESS:delete_leave_request_data['approver_email'],
                            constants.CC_MAIL_ADDRESS:leave_requests_details_edp.requestor_email,
                            constants.LEAVE_REQUESTOR_ROLE : constants.MANAGER_ROLE
                            
                        }
                        mail_response = leave_application_mail(request_body_for_mail_template)
                        print("Delete Leave Application response",mail_response)

                        # # to create a email body
                        # email_body = template.delete_leave_request_email_template
                        # email_body = email_body.replace(
                        #     'emp_id', delete_leave_request_data['emp_id'])
                        # email_body = email_body.replace(
                        #     'emp_name', delete_leave_request_data['emp_name'])
                        # email_body = email_body.replace(
                        #     'leave_type', leave_category_text)
                        # email_body = email_body.replace(
                        #     'absence_type', leave_type_text)
                        # email_body = email_body.replace(
                        #     'start_date', delete_leave_request_data['from_date'])
                        # email_body = email_body.replace(
                        #     'end_date', delete_leave_request_data['to_date'])
                        # email_body = email_body.replace(
                        #     'leave_reason', delete_leave_request_data['reason'])

                        # # To send attendance email to manager
                        # send_email_notification(
                        #     delete_leave_request_data['approver_email'], leave_requests_details_edp.requestor_email, email_body, email_subject)

                    notification_details = {
                        "emp_id": delete_leave_request_data['emp_id'],
                        "emp_name": delete_leave_request_data['emp_name'],
                        "reporting_manager": delete_leave_request_data['approver'],
                        "leave_request_id": leave_requests_details_edp.leave_request_id,
                        "notification_type": "Delete Leave Request"
                    }
                    print(notification_details['reporting_manager'])
                    # This is to create leave request notification
                    response = session.post(
                        config.create_leave_request_notification_url, data=json.dumps(notification_details))

                    # Team chatbot notification call.
                    # request_body_teams = [
                    #     {
                    #         "recipient": delete_leave_request_data['approver_email'],
                    #         "type": [{"todo": "Delete Request Pending",
                    #                   "pending": "Y"}]
                    #     }]
                    # team_chatbot_response = team_chatbot_notification(
                    #     request_body_teams)

                    # This is to insert leave requst timestamp
                    sap_posting_details = SAPPostingDetails.objects.filter(
                        leave_request_id=leave_requests_details_edp.leave_request_id).first()
                    if sap_posting_details:
                        sap_posting_details.delete_leave_datetime = datetime.now()
                        sap_posting_details.created_by = "SYSTEM"
                        sap_posting_details.modified_by = "SYSTEM"
                        sap_posting_details.save()

                    result = {
                        "status_code": "200",
                        "message": "Delete leave request created successfully"
                    }

                    # InterService Call to Store Activity Log
                    activity_details = {
                        "leave_request_id": leave_requests_details_edp.leave_request_id,
                        "emp_id": emp_id,
                        "browser": str(request.user_agent.browser.family),
                        "device_type": str(request.user_agent.device.family),
                        "operating_system": str(request.user_agent.os.family),
                        "action": 'Delete-Leave',
                        "platform":platform
                    }
                    token = request.headers['Authorization'].split()[1]
                    headers = {
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer' + ' ' + token
                    }
                    response = session.post(
                        config.create_activity_log_url, headers=headers, data=json.dumps(activity_details))

                    # This is used to send the delete push notification.
                    push_notification_request_body = {
                        "notification_for": "manager",
                        "notification_to": delete_leave_request_data['emp_id'],
                        "notification_content": delete_leave_request_data['emp_name'] + " has requested to delete "+leave_category_text + " from " + date_format_conversion(str(delete_leave_request_data['from_date'])) + " to " + date_format_conversion(str(delete_leave_request_data['to_date'])),
                        "notification_type": "Leave",
                        "notification_title": "Delete Request",
                        "data_content": delete_leave_request_data['emp_name'] + " has requested to delete "+leave_category_text + " from " + delete_leave_request_data['from_date'] + " to " + delete_leave_request_data['to_date'],
                        "data_title": "Delete Request",
                        "data_type":  "Delete Request",
                        "screen_type": "LeaveApprovals",
                        "request_from":"show_leave_apply_delete",
                    }
                    push_notification_response = insert_push_notification(
                        json.dumps(push_notification_request_body))

                    leave_task_module_notification={
                    "eventType":constants.LEAVE_DELETE,
                    "adaptiveCardType":constants.TASK_MODULE,
                    "receiverId":delete_leave_request_data['approver'],
                    "comp_code":constants.TMCV
                }
                    kafka_task_module_leave = requests.post(config.producer_leave_notification, headers=headers,timeout = 5 , data=json.dumps(leave_task_module_notification))
                    return JsonResponse(result, safe=False)
                    
            else:
                result = {
                    "status_code": "200",
                    "message": "You are not allowed to delete this leave request"
                }
                return JsonResponse(result, safe=False)
        else:
            result = {
                "status_code": "500",
                "message": "No data found"
            }
            return JsonResponse(result, safe=False)
    except Exception as error:
        print(error)
        result = {
            "status_code": "500",
            "message": "Something went wrong"
        }
        return JsonResponse(result, safe=False)

# This function is to cross company reporting delete leave request in edp
@csrf_exempt
def cross_company_reporting_delete_leave_request(request):
    try:
        delete_leave_request_data = json.loads(request.body)
        
        if bool(delete_leave_request_data):
            platform = "Other"
            if 'platform' in delete_leave_request_data:
                platform = "chat-bot"

            emp_id = delete_leave_request_data['emp_id']
            from_date = delete_leave_request_data['from_date']
            to_date = delete_leave_request_data['to_date']
            leave_status = delete_leave_request_data['leave_status']
            leave_category_code = delete_leave_request_data['leave_category_code']
            pa = delete_leave_request_data['pa']
            psa = delete_leave_request_data['psa']
            leave_request_id = delete_leave_request_data['leave_request_id']
            
            if leave_status == "9":
                result = {
                    "status_code": "200",
                    "message": "You are not allowed to delete this leave request. Please contact time-office for further details"
                }
                return result

            if leave_status == "3" or leave_status == "5" or leave_status == "6":
                result = {
                    "status_code": "200",
                    "message": "You are not allowed to delete this leave request."
                }
                return result

            # This is to get leave request details
            delete_leave_status = ['3','7','9','8']
            leave_requests_details_edp = LeaveRequestsEDP.objects.filter(
                requestor_emp_id=emp_id, from_date=from_date, to_date=to_date, is_deleted=False).exclude(leave_status__in=delete_leave_status).first()
            print("1")
            if bool(leave_requests_details_edp):
                # This is to delete leaves in status pending for approval and error in posting
                if leave_requests_details_edp.leave_status == "1" or leave_requests_details_edp.leave_status == "8":
                    leave_requests_details_edp.is_deleted = True
                    leave_requests_details_edp.leave_status = "7"
                    leave_requests_details_edp.save()

                    leave_againest_lwop_details = LeaveAgainstLWOP.objects.filter(
                        leave_request_id=leave_requests_details_edp.leave_request_id).first()
                    if leave_againest_lwop_details:
                        leave_againest_lwop_details.delete()

                    approved_leave_requests_details = ApprovedLeaveRequests.objects.filter(
                        leave_request_id=leave_requests_details_edp.leave_request_id).first()
                    if approved_leave_requests_details:
                        approved_leave_requests_details.delete()

                    # This is to insert leave requst timestamp
                    sap_posting_details = SAPPostingDetails.objects.filter(
                        leave_request_id=leave_requests_details_edp.leave_request_id).first()
                    if sap_posting_details:
                        sap_posting_details.delete_leave_datetime = datetime.now()
                        sap_posting_details.created_by = "SYSTEM"
                        sap_posting_details.modified_by = "SYSTEM"
                        sap_posting_details.save()

                    result = {
                        "status_code": "200",
                        "message": "Leave request sucessfully deleted"
                    }
                    return result
                else:
                    # This is to delete the leave having status other pending for approval
                    leave_requests_details_edp.leave_status = "6"
                    leave_requests_details_edp.save()

                    approved_leave_request_details = ApprovedLeaveRequests.objects.filter(
                        leave_request_id=leave_requests_details_edp.leave_request_id).first()
                    if approved_leave_request_details:
                        approved_leave_request_details.delete()

                
                    # This is to create leave deletion notification
                    notification_details = {
                        "requestor_emp_id": emp_id,
                        "approver_emp_id": "",
                        "leave_request_id": leave_requests_details_edp.leave_request_id,
                        "notification_type": "Delete Leave Auto Approval",
                        "action": "0"
                    }
                    response = session.post(
                        config.create_leave_approval_notification_url, data=json.dumps(notification_details))

                    # This is used to send push notification to employee
                    push_notification_request_body = {
                        "notification_for": "employee",
                        "notification_to": emp_id,
                        "notification_content":  "Your delete " + get_leave_category_text_emp_id(leave_category_code, emp_id)+ " request has been auto approved from "+date_format_conversion(str(from_date))+" to "+date_format_conversion(str(to_date)),
                        "notification_type": "Leave",
                        "notification_title": "Delete Leave Auto Approval",
                        "data_content": "Your delete " + get_leave_category_text_emp_id(leave_category_code,emp_id) + " request has been auto approved from "+date_format_conversion(str(from_date))+" to "+date_format_conversion(str(to_date)),
                        "data_title": "Delete Leave Auto Approval",
                        "data_type":  "Delete Leave Request",
                        "screen_type": "LeaveListing",
                        "request_from":"show_leave_apply_delete",
                    }
                    push_notification_response = insert_push_notification(
                        json.dumps(push_notification_request_body))
                    print("2")
                     # InterService Call to Store Activity Log
                    activity_details = {
                        "leave_request_id": leave_request_id,
                        "emp_id": emp_id,
                        "browser": str(request.user_agent.browser.family),
                        "device_type": str(request.user_agent.device.family),
                        "operating_system": str(request.user_agent.os.family),
                        "action": 'Cross-Company-Reporting-Delete-Leave',
                        "platform":platform
                    }
                    token = request.headers['Authorization'].split()[1]
                    headers = {
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer' + ' ' + token
                    }
                    response = session.post(
                        config.create_activity_log_url, headers=headers, data=json.dumps(activity_details))

                    result = {
                        "status_code": "200",
                        "message": "Delete leave request created sucessfully"
                    }
                    return result
            else:
                result = {
                    "status_code": "200",
                    "message": "You are not allowed to delete this leave request"
                }
                return 
        else:
            result = {
                "status_code": "500",
                "message": "No data found"
            }
            return result
    except Exception as error:
        print(error)
        result = {
            "status_code": "500",
            "message": "Something went wrong"
        }
        return result

# This function is to aprrove leave
@csrf_exempt
def delete_leave_request_approval(request):
    # This is to check is post request or simple function call
    if type(request) is dict:
        leave_request_data = request
    else:
        leave_request_data = json.loads(request.body)

    if bool(leave_request_data):
        try:
            platform = "Other"
            if 'platform' in leave_request_data:
                platform = "chat-bot"
            for data in leave_request_data['data']:
                # This is to update status in leave request edp table
                leave_request_details = LeaveRequestsEDP.objects.filter(
                    leave_request_id=data['leave_request_id']).first()
                if leave_request_details:
                    notification_to = data['requestor_emp_id']

                    # Get the from date and to date for push notification request body
                    leave_from_date = leave_request_details.from_date
                    leave_to_date = leave_request_details.to_date
                    leave_category_code = leave_request_details.leave_category
                    leave_type_code = leave_request_details.leave_type
                    # if leave_request_data['approval_type'] == "leave_request":
                    #     if leave_request_data['action'] == "0":
                    #         leave_status = "1"
                    #     else:
                    #         leave_status = "3"
                    # else:
                    leave_requests_details_sap = LeaveRequestsSAP.objects.filter(
                        requestor_emp_id=data['requestor_emp_id'], from_date=leave_request_details.from_date, to_date=leave_request_details.to_date, is_deleted=False).first()
                    if leave_request_data['action'] == "0":
                        # # This is to remove the approved leave in table
                        if not leave_requests_details_sap:
                            # approved_leave_request_details.delete()
                            leave_status = "7"
                            leave_request_details.is_deleted = True
                        else:
                            leave_status = "6"
                            # This is to add approved leave in table
                            approved_leave_request = ApprovedLeaveRequests(
                                leave_request_id=data['leave_request_id'],
                                created_date_time=datetime.now()
                            )
                            approved_leave_request.save()
                    else:
                        if not leave_requests_details_sap:
                            leave_status = "1"
                            approved_leave_request = ApprovedLeaveRequests(
                                leave_request_id=data['leave_request_id'],
                                created_date_time=datetime.now()
                            )
                            approved_leave_request.save()
                        else:
                            if leave_requests_details_sap.leave_category in constants.sap_leave_category_status:
                                # or leave_requests_details_sap.leave_category == "Z0" \
                                # or leave_requests_details_sap.leave_category == "X0" or leave_requests_details_sap.leave_category == "X0P":
                                leave_status = "1"
                                approved_leave_request = ApprovedLeaveRequests(
                                    leave_request_id=data['leave_request_id'],
                                    created_date_time=datetime.now()
                                )
                                approved_leave_request.save()
                            else:
                                leave_status = "2"

                    leave_request_details.leave_status = leave_status
                    leave_request_details.modified_date_time = datetime.now()
                    leave_request_details.modified_by = leave_request_data['emp_id']
                    leave_request_details.save()
                    leave_type_code = leave_request_details.leave_type

                # This is to add record in leave approval table
                leave_approval_details = LeaveApproval(
                    leave_approval_id=uuid.uuid4(),
                    leave_request_id=data['leave_request_id'],
                    requestor_emp_id=data['requestor_emp_id'],
                    action_taken=leave_request_data['action'],
                    action_owner=leave_request_data['emp_id'],
                    approval_type=leave_request_data['approval_type'],
                    created_date_time=datetime.now(),
                    modified_date_time=datetime.now(),
                    created_by=leave_request_data['emp_id'],
                    modified_by=leave_request_data['emp_id'],
                )
                leave_approval_details.save()

                # # This is to add approved leave in table
                # if leave_request_data['action'] == "0":
                #     # this is to collect all approved leaves
                #     approved_leave_request = ApprovedLeaveRequests(
                #         leave_request_id = data['leave_request_id'],
                #         created_date_time = datetime.now()
                #     )
                #     approved_leave_request.save()

                # This is to create leave deletion notification
                notification_details = {
                    "requestor_emp_id": data['requestor_emp_id'],
                    "approver_emp_id": leave_request_data['emp_id'],
                    "leave_request_id": data['leave_request_id'],
                    "notification_type": "Delete Leave Approval",
                    "action": leave_request_data['action']
                }
                response = session.post(
                    config.create_leave_approval_notification_url, data=json.dumps(notification_details))

               

            if leave_request_data['action'] == "0":
                result = {
                    "status_code": "200",
                    "message": "Delete leave request approved sucessfully"
                }
                # InterService Call to Store Activity Log
                activity_details = {
                    "leave_request_id": data['leave_request_id'],
                    "emp_id": leave_request_data['emp_id'],
                    "browser": str(request.user_agent.browser.family),
                    "device_type": str(request.user_agent.device.family),
                    "operating_system": str(request.user_agent.os.family),
                    "action": 'Delete-Leave-Approved',
                    "platform":platform
                }
                
                leave_type_details = LeaveType.objects.filter(leave_type_code=leave_type_code).first()
                leave_type_text = leave_type_details.leave_type_text
                print(leave_type_text)
                leave_category= get_leave_category_text_emp_id(leave_request_details.leave_category, leave_request_details.requestor_emp_id)
                print(leave_category)
                token = request.headers['Authorization'].split()[1]
                headers = {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer' + ' ' + token
                }
                response = session.post(
                    config.create_activity_log_url, headers=headers, data=json.dumps(activity_details))
                print('Activity Log', response)


                # This is used to send push notification to user
                push_notification_request_body = {
                    "notification_for": "employee",
                    "notification_to": notification_to,
                    "notification_content": "Your delete " + get_leave_category_text_emp_id(leave_category_code, leave_request_data['emp_id']) + " request has been approved from "+date_format_conversion(str(leave_from_date))+" to " + date_format_conversion(str(leave_to_date)),
                    "notification_type": "Leave",
                    "notification_title": "Leave Approval",
                    "data_content": "Your delete " + get_leave_category_text_emp_id(leave_category_code, leave_request_data['emp_id']) + " request has been approved from "+date_format_conversion(str(leave_from_date))+" to " + date_format_conversion(str(leave_to_date)),
                    "data_title": "Leave Approval",
                    "data_type":  "Leave Request",
                    "screen_type": "LeaveListing",
                    "request_from":"show_leave_approve_reject",

                } 
                print('push_notification_request -->', push_notification_request_body)
                push_notification_response = insert_push_notification(
                    json.dumps(push_notification_request_body))

                leave_text_card_notification={
                    "eventType":constants.LEAVE_DELETE_APPROVE,
                    "adaptiveCardType":constants.TEXT_CARD,
                    "employeeId":leave_request_details.requestor_emp_id,
                    "emailId":leave_request_details.requestor_email,
                    "receiverId":leave_request_details.requestor_emp_id,  
                    "leaveType": leave_category,
                    "absenceType":leave_type_text ,
                    "startDate":str(leave_request_details.from_date),
                    "endDate": str(leave_request_details.to_date),
                    "leaveReason":leave_request_details.reason,
                    "comp_code":constants.TMCV
                }
                print("delete-approve",leave_text_card_notification)
                kafka_text_card_leave = requests.post(config.producer_leave_notification, headers=headers,timeout = 5 , data=json.dumps(leave_text_card_notification))
            else:
                result = {
                    "status_code": "200",
                    "message": "Delete leave request rejected sucessfully"
                }
                # InterService Call to Store Activity Log
                activity_details = {
                    "leave_request_id": data['leave_request_id'],
                    "emp_id": leave_request_data['emp_id'],
                    "browser": str(request.user_agent.browser.family),
                    "device_type": str(request.user_agent.device.family),
                    "operating_system": str(request.user_agent.os.family),
                    "action": 'Delete-Leave-Rejected',
                    "platform":platform
                }
                token = request.headers['Authorization'].split()[1]
                headers = {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer' + ' ' + token
                }
                response = session.post(
                    config.create_activity_log_url, headers=headers, data=json.dumps(activity_details))
                print('Activity Log', response)
                 
                leave_type_details = LeaveType.objects.filter(leave_type_code=leave_type_code).first()
                leave_type_text = leave_type_details.leave_type_text
                print(leave_type_text)
                leave_category= get_leave_category_text_emp_id(leave_request_details.leave_category, leave_request_details.requestor_emp_id)
                print(leave_category)

                # This is used to send push notification to user
                push_notification_request_body = {
                    "notification_for": "employee",
                    "notification_to": notification_to,
                    "notification_content": "Your delete " + get_leave_category_text_emp_id(leave_category_code, leave_request_data['emp_id']) + " request has been rejected from "+date_format_conversion(str(leave_from_date))+" to " + date_format_conversion(str(leave_to_date)),
                    "notification_type": "Leave",
                    "notification_title": "Leave Approval",
                    "data_content": "Your delete " + get_leave_category_text_emp_id(leave_category_code, leave_request_data['emp_id']) + " request has been rejected from "+date_format_conversion(str(leave_from_date))+" to " + date_format_conversion(str(leave_to_date)),
                    "data_title": "Leave Approval",
                    "data_type":  "Leave Request",
                    "screen_type": "LeaveListing",
                    "request_from":"show_leave_approve_reject",

                } 
                print('push_notification_request -->', push_notification_request_body)
                push_notification_response = insert_push_notification(
                    json.dumps(push_notification_request_body))

                leave_text_card_notification={
                    "eventType":constants.LEAVE_DELETE_REJECT,
                    "adaptiveCardType":constants.TEXT_CARD,
                    "employeeId":leave_request_details.requestor_emp_id,
                    "emailId":leave_request_details.requestor_email,
                    "receiverId":leave_request_details.requestor_emp_id,  
                    "leaveType": leave_category,
                    "absenceType":leave_type_text ,
                    "startDate":str(leave_request_details.from_date),
                    "endDate": str(leave_request_details.to_date),
                    "leaveReason":leave_request_details.reason,
                    "comp_code":constants.TMCV
                }
                kafka_text_card_leave = requests.post(config.producer_leave_notification, headers=headers,timeout = 5 ,data=json.dumps(leave_text_card_notification))
            # This is to check is post request or simple function call
            if type(request) is dict:
                return result
            else:
                return JsonResponse(result, safe=False)

        except (Exception) as error:
            print_error_v1("delete_leave_request_approval",error)
            result = {
                "status_code": "500",
                "message": "Failed to approve delete leave request"
            }
            # This is to check is post request or simple function call
            if type(request) is dict:
                return result
            else:
                return JsonResponse(result, safe=False)
    else:
        result = {
            "status_code": "500",
            "message": ""
        }
        # This is to check is post request or simple function call
        if type(request) is dict:
            return result
        else:
            return JsonResponse(result, safe=False)

# This function is to aprrove leave


@csrf_exempt
def auto_delete_leave_request_approval(request):
    # This is to check is post request or simple function call
    if type(request) is dict:
        leave_request_data = request
    else:
        leave_request_data = json.loads(request.body)

    if bool(leave_request_data):
        try:
            # token = request.headers['Authorization'].split()[1]
            # headers ={
            #     'Content-Type': 'application/json',
            #     'Authorization': 'Bearer' + ' ' + token
            # }
            for data in leave_request_data['data']:
                # This is to update status in leave request edp table
                leave_request_details = LeaveRequestsEDP.objects.filter(
                    leave_request_id=data['leave_request_id']).first()
                if leave_request_details:
                    # if leave_request_data['approval_type'] == "leave_request":
                    #     if leave_request_data['action'] == "0":
                    #         leave_status = "1"
                    #     else:
                    #         leave_status = "3"
                    # else:
                    leave_requests_details_sap = LeaveRequestsSAP.objects.filter(
                        requestor_emp_id=data['requestor_emp_id'], from_date=leave_request_details.from_date, to_date=leave_request_details.to_date, is_deleted=False).first()
                    if leave_request_data['action'] == "0":
                        # # This is to remove the approved leave in table
                        if not leave_requests_details_sap:
                            # approved_leave_request_details.delete()
                            leave_status = "7"
                            leave_request_details.is_deleted = True
                        else:
                            leave_status = "6"
                            # This is to add approved leave in table
                            approved_leave_request = ApprovedLeaveRequests(
                                leave_request_id=data['leave_request_id'],
                                created_date_time=datetime.now()
                            )
                            approved_leave_request.save()
                    else:
                        if not leave_requests_details_sap:
                            leave_status = "1"
                            approved_leave_request = ApprovedLeaveRequests(
                                leave_request_id=data['leave_request_id'],
                                created_date_time=datetime.now()
                            )
                            approved_leave_request.save()
                        else:
                            if leave_requests_details_sap.leave_category in constants.sap_leave_category_status:
                                # or leave_requests_details_sap.leave_category == "Z0" \
                                # or leave_requests_details_sap.leave_category == "X0" or leave_requests_details_sap.leave_category == "X0P":
                                leave_status = "1"
                                approved_leave_request = ApprovedLeaveRequests(
                                    leave_request_id=data['leave_request_id'],
                                    created_date_time=datetime.now()
                                )
                                approved_leave_request.save()
                            else:
                                leave_status = "2"

                    leave_request_details.leave_status = leave_status
                    leave_request_details.modified_date_time = datetime.now()
                    leave_request_details.modified_by = leave_request_data['emp_id']
                    leave_request_details.save()

                    # Get the from date and to date for push notification request body
                    leave_from_date = leave_request_details.from_date
                    leave_to_date = leave_request_details.to_date
                    leave_category_code = leave_request_details.leave_category
                    leave_type_code = leave_request_details.leave_type

                # This is to add record in leave approval table
                leave_approval_details = LeaveApproval(
                    leave_approval_id=uuid.uuid4(),
                    leave_request_id=data['leave_request_id'],
                    requestor_emp_id=data['requestor_emp_id'],
                    action_taken=leave_request_data['action'],
                    action_owner=leave_request_data['emp_id'],
                    approval_type=leave_request_data['approval_type'],
                    created_date_time=datetime.now(),
                    modified_date_time=datetime.now(),
                    created_by=leave_request_data['emp_id'],
                    modified_by=leave_request_data['emp_id'],
                )
                leave_approval_details.save()

                # # This is to add approved leave in table
                # if leave_request_data['action'] == "0":
                #     # this is to collect all approved leaves
                #     approved_leave_request = ApprovedLeaveRequests(
                #         leave_request_id = data['leave_request_id'],
                #         created_date_time = datetime.now()
                #     )
                #     approved_leave_request.save()

                # This is to create leave deletion notification
                notification_details = {
                    "requestor_emp_id": data['requestor_emp_id'],
                    "approver_emp_id": leave_request_data['emp_id'],
                    "leave_request_id": data['leave_request_id'],
                    "notification_type": "Delete Leave Auto Approval",
                    "action": leave_request_data['action']
                }
                response = session.post(
                    config.create_leave_approval_notification_url, data=json.dumps(notification_details))

                # This is for team bot notification api
                # team_notification_action = "Approved" if leave_request_data[
                #     'action'] == "0" else "Rejected"
                # request_body_teams = [
                #     {
                #         "Type": "Delete Request",
                #         "Contents": [
                #                 {
                #                     "req_id": leave_request_details.requestor_emp_id,
                #                     "leave_type": leave_request_details.leave_category,
                #                     "from_date": str(leave_request_details.from_date),
                #                     "to_date": str(leave_request_details.to_date),
                #                     "action_by": leave_request_details.approver_email
                #                 }
                #         ],
                #         "Action": team_notification_action,
                #         "Reason": leave_request_details.reason,
                #         "Recipient": leave_request_details.requestor_email,
                #     }
                # ]
                # teams_notification_response = teams_notification(
                #     json.dumps(request_body_teams))
                 
                leave_type_details = LeaveType.objects.filter(leave_type_code=leave_type_code).first()
                leave_type_text = leave_type_details.leave_type_text
                print(leave_type_text)
                leave_category= get_leave_category_text_emp_id(leave_request_details.leave_category, leave_request_details.requestor_emp_id)
                print(leave_category)
                # This is used to send push notification to employee
                push_notification_request_body = {
                    "notification_for": "employee",
                    "notification_to": leave_request_data['emp_id'],
                    "notification_content":  "Your delete " + get_leave_category_text_emp_id(leave_category_code, data['requestor_emp_id']) + " request has been auto approved from "+date_format_conversion(str(leave_from_date))+" to "+date_format_conversion(str(leave_to_date)),
                    "notification_type": "Leave",
                    "notification_title": "Delete Leave Auto Approval",
                    "data_content": "Your delete " + get_leave_category_text_emp_id(leave_category_code, data['requestor_emp_id']) + " request has been auto approved from "+date_format_conversion(str(leave_from_date))+" to "+date_format_conversion(str(leave_to_date)),
                    "data_title": "Delete Leave Auto Approval",
                    "data_type":  "Delete Leave Request",
                    "screen_type": "LeaveListing",
                    "request_from":"show_leave_apply_delete",


                }
                push_notification_response = insert_push_notification(
                    json.dumps(push_notification_request_body))
                leave_text_card_notification={
                    "eventType":constants.LEAVE_DELETE_AUTO_APPROVE,
                    "adaptiveCardType":constants.TEXT_CARD,
                    "employeeId":leave_request_details.requestor_emp_id,
                    "emailId":leave_request_details.requestor_email,
                    "receiverId":leave_request_details.requestor_emp_id,  
                    "leaveType": leave_category,
                    "absenceType":leave_type_text ,
                    "startDate":str(leave_request_details.from_date),
                    "endDate": str(leave_request_details.to_date),
                    "leaveReason":leave_request_details.reason,
                    "comp_code":constants.TMCV
                }
                print("delete-auto-approve",leave_text_card_notification)
                kafka_text_card_leave = requests.post(config.producer_leave_notification,timeout = 5 ,data=json.dumps(leave_text_card_notification))
            if leave_request_data['action'] == "0":
                result = {
                    "status_code": "200",
                    "message": "Delete leave request approved sucessfully"
                }
            else:
                result = {
                    "status_code": "200",
                    "message": "Delete leave request rejected sucessfully"
                }

            # This is to check is post request or simple function call
            if type(request) is dict:
                return result
            else:
                return JsonResponse(result, safe=False)

        except (Exception) as error:
            print_error_v1("auto_delete_leave_request_approval",error)
            result = {
                "status_code": "500",
                "message": "Failed to approve delete leave request"
            }
            # This is to check is post request or simple function call
            if type(request) is dict:
                return result
            else:
                return JsonResponse(result, safe=False)
    else:
        result = {
            "status_code": "500",
            "message": ""
        }
        # This is to check is post request or simple function call
        if type(request) is dict:
            return result
        else:
            return JsonResponse(result, safe=False)


######################################### Delete Leave Section Start end #######################################

######################################### Attendance Enquiry Section Start ####################################
# This function is to get attendacne enquiry
@csrf_exempt
def get_attendance_enquiry(request):
    week_offs = []
    public_holidays = []
    # This is to get attendacne enquiry from SAP
    sap_response = get_attendance_enquiry_sap(request)

    # This is to check wheather th response is in string
    is_string = isinstance(sap_response, str)
    if is_string == True:
        result = {
            "status_code": "500",
            "message": ""
        }
        return JsonResponse(result, safe=False)
    print(sap_response)
    # This is if SAP gives success response
    if sap_response != None and sap_response.status_code == 200:
        attendance_enquiry_details_sap = json.dumps(xmltodict.parse(
            sap_response.content))  # to convert xml response into dictionary
        attendance_enquiry_details_sap_json = json.loads(
            attendance_enquiry_details_sap)

        # check if single record for attendance enquiry
        is_single_attendance_enquiry = isinstance(
            attendance_enquiry_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0016Response']['OUTPUT']['item'], dict)
        if is_single_attendance_enquiry == False:
            for data in attendance_enquiry_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0016Response']['OUTPUT']['item']:
                # This is to make date in YYYY-MM-DD format
                if 'LDATE' in data:
                    date = data['LDATE'].strip()
                    data['LDATE'] = date[:4] + "-" + date[4:6] + "-" + date[6:]

                    # This is to get week off list in selected month
                    if ('DAY_TYPE' in data and data['DAY_TYPE'] == "O"):
                        week_offs.append(data['LDATE'])

                    # This is to get public holidays list in selected month
                    if ('DAY_TYPE' in data and data['DAY_TYPE'] == "P"):
                        public_holidays.append(data['LDATE'])

            result = {
                "status_code": "200",
                "message": "Data captured successfully!",
                "attendance_enquiry_details": attendance_enquiry_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0016Response']['OUTPUT']['item'],
                "week_offs": week_offs,
                "public_holidays": public_holidays
            }
            return JsonResponse(result, safe=False)
        else:
            result = {
                "status_code": "500",
                "message": ""
            }
            return JsonResponse(result, safe=False)
    else:
        result = {
            "status_code": "500",
            "message": "No response from SAP"
        }
        return JsonResponse(result, safe=False)

# This function is to get attendacne enquiry from SAP


@csrf_exempt
def get_attendance_enquiry_sap(request):
    attendance_enquiry_data = json.loads(request.body)
    if bool(attendance_enquiry_data):
        format = '%Y-%m-%d'
        month = attendance_enquiry_data['month']
        year = attendance_enquiry_data['year']
        date_of_joining = ""
        
        if 'date_of_joining' in attendance_enquiry_data:
            date_of_joining = attendance_enquiry_data['date_of_joining']

        last_day = calendar.monthrange(int(year), int(month))[1]
        from_date = str(year) + "-" + str(month) + "-" + "01"
        to_date = str(year) + "-" + str(month) + "-" + str(last_day)
        
        if date_of_joining != "":
            # conevert from  date into datetime format
            formatted_doj = datetime.strptime(date_of_joining, format)    
            print("formatted_doj", formatted_doj)
            # Convert joining date in required format 
            formatted_from_date = datetime.strptime(from_date, format)
            print("formatted_from_date",formatted_from_date)
            # chceck if from date is less than joining date 
            if formatted_from_date < formatted_doj:
                temp_date = date_of_joining.split("-")
                from_date = str(year) + "-" + str(month) + "-" + str(temp_date[2])
                print(from_date)

        headers = {'content-type': 'text/xml'}
        request_body = common_request_body.attendance_enquiry_request_body

        request_body = request_body.replace(
            "emp_id", attendance_enquiry_data['emp_id'])
        request_body = request_body.replace("from_date", from_date)
        request_body = request_body.replace("to_date", to_date)
        response = requests.post(config.attendance_enquiry_request_url, data=request_body, headers=headers, auth=(
            config.cv_sap_webservice_id, config.cv_sap_webservice_password))
        print("get_attendance_enquiry", response.text)
        return response
    else:
        return None

# This is to get working days


@csrf_exempt
def get_working_days(request):
    try:
        total_working_days = 0
        leave_data = request
        headers = {'content-type': 'text/xml'}
        request_body = common_request_body.attendance_enquiry_request_body

        request_body = request_body.replace("emp_id", leave_data['emp_id'])
        request_body = request_body.replace(
            "from_date", leave_data['from_date'])
        request_body = request_body.replace("to_date", leave_data['to_date'])

        sap_response = requests.post(config.attendance_enquiry_request_url, data=request_body, headers=headers, auth=(
            config.cv_sap_webservice_id, config.cv_sap_webservice_password))

        if sap_response != None and sap_response.status_code == 200:
            attendance_enquiry_details_sap = json.dumps(xmltodict.parse(
                sap_response.content))  # to convert xml response into dictionary
            attendance_enquiry_details_sap_json = json.loads(
                attendance_enquiry_details_sap)

            # check if single record for attendance enquiry
            is_single_attendance_enquiry = isinstance(
                attendance_enquiry_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0016Response']['OUTPUT']['item'], dict)
            print(attendance_enquiry_details_sap_json)
            if is_single_attendance_enquiry == False:
                for data in attendance_enquiry_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0016Response']['OUTPUT']['item']:
                    if 'LDATE' in data:
                        # This is to get week off list in selected month
                        if (data['DAY_TYPE'] == "W"):
                            total_working_days = total_working_days + 1
                        # else:
                        #     total_working_days = total_working_days
                result = {
                    "status_code": "200",
                    "attendance_enquiry_details": attendance_enquiry_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0016Response']['OUTPUT']['item'],
                    "total_working_days": total_working_days
                }
                return result
            if is_single_attendance_enquiry == True:
                if attendance_enquiry_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0016Response']['OUTPUT']['item']:
                    for data in attendance_enquiry_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0016Response']['OUTPUT']['item']:
                        if 'LDATE' in data:
                            # This is to get week off list in selected month
                            if (attendance_enquiry_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0016Response']['OUTPUT']['item']['DAY_TYPE'] == "W"):
                                if leave_data['leave_type_code'] == "FD":
                                    total_working_days = total_working_days + 1
                                else:
                                    total_working_days = total_working_days + 0.5
                            else:
                                total_working_days = total_working_days
                    result = {
                        "status_code": "200",
                        "attendance_enquiry_details": attendance_enquiry_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0016Response']['OUTPUT']['item'],
                        "total_working_days": total_working_days
                    }
                    return result
                else:
                    result = {
                        "status_code": "500",
                    }
                    return result
            else:
                result = {
                    "status_code": "500",
                }
                return result
        else:
            result = {
                "status_code": "500",
            }
            return result
    except (Exception) as error:
        print(error)
        result = {
            "status_code": "500",
        }
        return result

######################################### Attendance Enquiry Section end #######################################

######################################### Common Section Start #########################################
# This function is to get leave category list


@csrf_exempt
def get_leave_category_text(pa, psa, leave_category_code):
    # This is to get current date IST
    leave_category_text = ""
    current_date_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).date()

    ps_group_details = PAPSAGroupMapping.objects.filter(
        pa_code=pa, psa_code=psa).first()
    if ps_group_details:
        leave_category_details = PSGroupLeaveCategoryMapping.objects.filter(
            pa_psa_group=ps_group_details.pa_psa_group, leave_category_code=leave_category_code, valid_from__lte=current_date_ist, valid_to__gte=current_date_ist).first()
        if leave_category_details:
            return leave_category_details.leave_category_text
        else:
            return leave_category_text
    else:
        return leave_category_text

# This function is to get leave category list -- extended leave categories


# This is used to get the leave category text by emp id and leave cateogory text
def get_leave_category_text_emp_id(leave_category_code, emp_id):
    employee_detail = []
    get_user_details_query = """SELECT * FROM edp_employee_details WHERE "Perno"='{}'""".format(
        emp_id)
    cursor = connection.cursor()
    cursor.execute(get_user_details_query)
    records = cursor.fetchall()
    columnNames = [column[0] for column in cursor.description]
    for record in records:
        employee_detail.append(dict(zip(columnNames, record)))
    print(employee_detail)
    cursor.close()
    if employee_detail:
        employee_exit_form_details = employee_detail[0]
        employee_person_area = employee_exit_form_details['PersArea']
        employee_sub_area = employee_exit_form_details['PSubarea']
        leave_categroy_text = get_leave_category_text(
            employee_person_area, employee_sub_area, leave_category_code)
        print("leave categroy text", leave_categroy_text)
        return leave_categroy_text
    else:
        return leave_category_code


@csrf_exempt
def get_extended_leave_category_text(pa, psa, leave_category_code):
    # This is to get current date IST
    leave_category_text = ""
    current_date_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).date()

    ps_group_details = PAPSAGroupMapping.objects.filter(
        pa_code=pa, psa_code=psa).first()
    if ps_group_details:
        leave_category_details = ExtendedPSGroupLeaveCategoryMapping.objects.filter(
            pa_psa_group=ps_group_details.pa_psa_group, leave_category_code=leave_category_code, valid_from__lte=current_date_ist, valid_to__gte=current_date_ist).first()
        if leave_category_details:
            return leave_category_details.leave_category_text
        else:
            return leave_category_text
    else:
        return leave_category_text

# This function is to get leave category and leave type text


@csrf_exempt
def get_leave_request_details(request):
    leave_category_text = ""
    leave_type_text = ""
    leave_request_details = ""
    leave_request_details_json = ""
    leave_request_data = json.loads(request.body)
    print("notification id", leave_request_data['notification_details_id'])

    if bool(leave_request_data):
        leave_request_details = LeaveRequestsEDP.objects.filter(
            leave_request_id=leave_request_data['notification_details_id'])
        print("leave_request details", leave_request_details)
        if leave_request_details:
            leave_request_details_json = get_serialize_data(
                leave_request_details)
            print(leave_request_details_json)
            # This is to get current date IST
            current_date_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).date()

            # This is IMP -- Do Not Delete
            # ps_group_details = PAPSAGroupMapping.objects.filter(pa_code = leave_request_data['pa'] , psa_code = leave_request_data['psa']).first()
            # if ps_group_details:
            #     leave_category_details = PSGroupLeaveCategoryMapping.objects.filter(pa_psa_group = ps_group_details.pa_psa_group , leave_category_code = leave_request_details_json[0]['leave_category'],valid_from__lte = current_date_ist , valid_to__gte = current_date_ist).first()
            #     if leave_category_details:
            #         leave_category_text =  leave_category_details.leave_category_text

            # This is to get leave category text from extended leave category tables
            ps_group_details = PAPSAGroupMapping.objects.filter(
                pa_code=leave_request_data['pa'], psa_code=leave_request_data['psa']).first()
            if ps_group_details:
                leave_category_details = ExtendedPSGroupLeaveCategoryMapping.objects.filter(
                    pa_psa_group=ps_group_details.pa_psa_group, leave_category_code=leave_request_details_json[0]['leave_category'], valid_from__lte=current_date_ist, valid_to__gte=current_date_ist).first()
                if leave_category_details:
                    leave_category_text = leave_category_details.leave_category_text

            leave_type_details = LeaveType.objects.filter(
                leave_type_code=leave_request_details_json[0]['leave_type']).first()
            if leave_type_details:
                leave_type_text = leave_type_details.leave_type_text

            # # To add leave category text and leave type text in json
            leave_request_details_json[0]['leave_category_text'] = leave_category_text
            leave_request_details_json[0]['leave_type_text'] = leave_type_text

        result = {
            "leave_request_details": leave_request_details_json,
        }
        return JsonResponse(result, safe=False)

# This function is to insert data into pa psa group mapping table


@csrf_exempt
def insert_pa_psa_group_mapping(request):
    pa_code = []
    psa_code = []
    pa_psa_group = []
    data = json.loads(request.body)
    if bool(data):
        for value in data:
            pa_code.append(value['pa_code'].strip())
            psa_code.append(value['psa_code'].strip())
            pa_psa_group.append(value['pa_psa_group'].strip())

        for x in range(len(pa_code)):
            try:
                pa_psa_group_mapping_details = PAPSAGroupMapping(
                    pa_code=pa_code[x],
                    psa_code=psa_code[x],
                    pa_psa_group=pa_psa_group[x],
                )
                pa_psa_group_mapping_details.save()
                result = {
                    "statusCode": "200",
                    "message": "data insert success",
                }
            except (Exception) as error:
                print(error)
                result = {
                    "statusCode": "200",
                    "message": "data insert fail"
                }
    else:
        result = {
            "statusCode": "200",
            "message": "incorrect request body"
        }
    return JsonResponse(result, safe=False)

# This function is to insert data into ps group and leave category mapping table


@csrf_exempt
def insert_ps_group_leave_category_mapping(request):
    leave_category_code = []
    leave_category_text = []
    leave_group = []
    valid_from = []
    valid_to = []
    pa_psa_group = []
    leave_categrory_color = []
    data = json.loads(request.body)
    if bool(data):
        for value in data:
            valid_from_date = value['valid_from'].strip().replace('.', '')
            valid_from_date = valid_from_date[4:] + "-" + \
                valid_from_date[2:4] + "-" + valid_from_date[0:2]
            valid_to_date = value['valid_to'].strip().replace('.', '')
            valid_to_date = valid_to_date[4:] + "-" + \
                valid_to_date[2:4] + "-" + valid_to_date[0:2]

            leave_category_code.append(value['leave_category_code'].strip())
            leave_category_text.append(value['leave_category_text'].strip())
            leave_group.append(value['leave_group'].strip())
            valid_from.append(valid_from_date)
            valid_to.append(valid_to_date)
            pa_psa_group.append(value['pa_psa_group'].strip())
            leave_categrory_color.append(value['leave_categrory_color'].strip())

        for x in range(len(leave_category_code)):
            try:
                ps_group_leave_category_mapping_details = PSGroupLeaveCategoryMapping(
                    leave_category_code=leave_category_code[x],
                    leave_category_text=leave_category_text[x],
                    leave_group=leave_group[x],
                    valid_from=valid_from[x],
                    pa_psa_group=pa_psa_group[x],
                    valid_to=valid_to[x],
                    leave_categrory_color=leave_categrory_color[x]
                )
                ps_group_leave_category_mapping_details.save()
                result = {
                    "statusCode": "200",
                    "message": "data insert success",
                }
            except (Exception) as error:
                print(error)
                result = {
                    "statusCode": "200",
                    "message": "data insert fail"
                }
    else:
        result = {
            "statusCode": "200",
            "message": "incorrect request body"
        }
    return JsonResponse(result, safe=False)

# This function is to insert data into ps group and leave category mapping table -- extended leave categories


@csrf_exempt
def insert_extended_ps_group_leave_category_mapping(request):
    leave_category_code = []
    leave_category_text = []
    leave_group = []
    valid_from = []
    valid_to = []
    pa_psa_group = []

    data = json.loads(request.body)
    if bool(data):
        for value in data:
            valid_from_date = value['valid_from'].strip().replace('.', '')
            valid_from_date = valid_from_date[4:] + "-" + \
                valid_from_date[2:4] + "-" + valid_from_date[0:2]
            valid_to_date = value['valid_to'].strip().replace('.', '')
            valid_to_date = valid_to_date[4:] + "-" + \
                valid_to_date[2:4] + "-" + valid_to_date[0:2]

            leave_category_code.append(value['leave_category_code'].strip())
            leave_category_text.append(value['leave_category_text'].strip())
            leave_group.append(value['leave_group'].strip())
            valid_from.append(valid_from_date)
            valid_to.append(valid_to_date)
            pa_psa_group.append(value['pa_psa_group'].strip())

        for x in range(len(leave_category_code)):
            try:
                ps_group_leave_category_mapping_details = ExtendedPSGroupLeaveCategoryMapping(
                    leave_category_code=leave_category_code[x],
                    leave_category_text=leave_category_text[x],
                    leave_group=leave_group[x],
                    valid_from=valid_from[x],
                    pa_psa_group=pa_psa_group[x],
                    valid_to=valid_to[x],
                )
                ps_group_leave_category_mapping_details.save()
                result = {
                    "statusCode": "200",
                    "message": "data insert success",
                }
            except (Exception) as error:
                print(error)
                result = {
                    "statusCode": "200",
                    "message": "data insert fail"
                }
    else:
        result = {
            "statusCode": "200",
            "message": "incorrect request body"
        }
    return JsonResponse(result, safe=False)

# This function is to insert data into approved leave request table


@csrf_exempt
def insert_approved_leave_requests(request):
    leave_request_id = []

    data = json.loads(request.body)
    if bool(data):
        for value in data:
            leave_request_id.append(value['leave_request_id'])

        for x in range(len(leave_request_id)):
            try:
                is_present = ApprovedLeaveRequests.objects.filter(
                    leave_request_id=leave_request_id[x]).first()
                if not is_present:
                    approved_leave_requests_details = ApprovedLeaveRequests(
                        leave_request_id=leave_request_id[x],
                        created_date_time=datetime.now()
                    )
                    approved_leave_requests_details.save()
                result = {
                    "statusCode": "200",
                    "message": "data insert success",
                }
            except (Exception) as error:
                print(error)
                result = {
                    "statusCode": "200",
                    "message": "data insert fail"
                }
    else:
        result = {
            "statusCode": "200",
            "message": "incorrect request body"
        }
    return JsonResponse(result, safe=False)

######################################### Common Section end #######################################

# function for serialize data


def get_serialize_data(data):
    data = serializers.serialize("json", data)
    data = json.loads(data)
    result = []
    for i in range(len(data)):
        detail_data = data[i]['fields']
        result.append(detail_data)
    return result

# This function is to send mail


@csrf_exempt
def send_email_notification(to_email, from_email, email_body, email_subject):
    # send_mail(
    #     email_subject,
    #     "Hi,\n\n",
    #     'drishti-alerts@tatamotors.com',
    #     [to_email],
    #     html_message = email_body,
    # )
    # print("mail sent successfully")
    email = EmailMultiAlternatives(
        email_subject,
        "Hi,\n\n",
        'drishti-alerts@tatamotors.com',
        [to_email],
        cc=[from_email]
    )
    email.attach_alternative(email_body, "text/html")
    email.send()
    print("mail sent successfully")

############################################### Force Run Section Start #######################################
# This function is to force run get leave quota


@csrf_exempt
def force_run_get_leave_quota(request):
    try:
        leave_quota = []
        active_quota_code = []
        emp_id = request

        # This is to get current year IST
        active_year_details = ActiveYear.objects.filter(is_active=True).first()
        current_year_ist = int(active_year_details.active_year)
        # current_year_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).year

        valid_from = str(current_year_ist) + "-01-01"
        valid_to = str(current_year_ist) + "-12-31"

        # To get leave quota from SAP
        response = get_leave_quota_sap_request(emp_id, valid_from, valid_to)

        # This is to check wheather th response is in string
        is_string = isinstance(response, str)
        if is_string == True:
            return False

        # This is when sap webservices gives success as response
        if response.status_code == 200:
            leave_quota_details_sap = json.dumps(
                xmltodict.parse(response.content))
            leave_quota_details_sap_json = json.loads(leave_quota_details_sap)

            # check if single record for leave quota
            is_single_leave_quota = isinstance(
                leave_quota_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0014Response']['QUOTA_OVERVIEW']['item'], dict)

            if is_single_leave_quota == False:
                # This is to delete leave quota
                leave_quota_details = LeaveQuota.objects.filter(emp_id=emp_id)
                if leave_quota_details:
                    leave_quota_details.delete()

                # This is reset active leave quota code
                active_quota_details = ActiveQuotaDetails.objects.filter(
                    emp_id=emp_id).first()
                if active_quota_details:
                    active_quota_details.delete()

                for data in leave_quota_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0014Response']['QUOTA_OVERVIEW']['item']:
                    quota_value = 0
                    display_quota_value = 0

                    # This is to neglect first item in the body
                    if not (data['KTEXT'] == "" or data['KTEXT'] == None):
                        total_leaves = data['ANZHL']
                        display_total_leaves = data['ANZHL']
                        available_leaves = float(data['ANZHL_CLOSE'])
                        display_available_leaves = data['ANZHL_CLOSE']
                        quota_valid_from = data['BEGDA']
                        quota_valid_to = data['ENDDA']

                        # to get leave quoto text
                        leave_quota_code = data['KTEXT'].strip()
                        leave_quota_details = Quota.objects.filter(
                            quota_code=leave_quota_code).first()
                        if leave_quota_details:
                            leave_quota_text = leave_quota_details.quota_text
                        else:
                            leave_quota_text = ""

                        # # This is set active leave quota code
                        active_quota_code.append(leave_quota_code)

                        unique_quota_id = emp_id + "-" + leave_quota_code + \
                            "-" + quota_valid_from + "-" + quota_valid_to

                        if available_leaves != 0:
                            # This is to find quota applicable leave categories
                            leave_category_details = QuotaLeaveCategoryMapping.objects.filter(
                                quota_code=leave_quota_code)
                            if leave_category_details:
                                leave_category_details_json = get_serialize_data(
                                    leave_category_details)
                                for data in leave_category_details_json:
                                    total_days = 0

                                    # #This is to calulate availble leave quota against leave applied from edp
                                    # leave_history_edp = LeaveRequestsEDP.objects.filter(requestor_emp_id = emp_id ,leave_category = data['leave_category'],from_date__year = current_year_ist,is_deleted = False).exclude(Q(leave_status = "2") | Q(leave_status = "3") | Q(leave_status = "4") |Q(leave_status = "5") | Q(leave_status = "6") | Q(leave_status = "7"))
                                    # if leave_history_edp:
                                    #     leave_history_edp_json = get_serialize_data(leave_history_edp)

                                    #     for data in leave_history_edp_json:
                                    #         if not (data['total_days'] == "" or data['total_days'] == None):
                                    #             total_days = total_days + float(data['total_days'])

                                    # This is to calulate availble leave quota against leave applied from edp
                                    leave_history_edp = LeaveRequestsEDP.objects.filter(
                                        Q(requestor_emp_id=emp_id, leave_category=data['leave_category'], from_date__year=current_year_ist,
                                          is_deleted=False, from_date__gte=quota_valid_from, to_date__lte=quota_valid_to, unique_quota_id=unique_quota_id)
                                        # Q(requestor_emp_id = emp_id ,leave_category = data['leave_category'],from_date__year = current_year_ist,is_deleted = False,from_date__gte = quota_valid_to, to_date__lte = quota_valid_to,unique_quota_id = unique_quota_id)
                                        # Q(requestor_emp_id = emp_id ,leave_category = data['leave_category'],from_date__year = current_year_ist,is_deleted = False,from_date__lte = quota_valid_from, to_date__gte = quota_valid_to,unique_quota_id = unique_quota_id)
                                    ).exclude(Q(leave_status="2") | Q(leave_status="3") | Q(leave_status="4") | Q(leave_status="5") | Q(leave_status="6") | Q(leave_status="7")).order_by("from_date")

                                    if leave_history_edp:
                                        leave_history_edp_json = get_serialize_data(
                                            leave_history_edp)

                                        for data in leave_history_edp_json:
                                            if not (data['total_days'] == "" or data['total_days'] == None):
                                                total_days = total_days + \
                                                    float(data['total_days'])

                                    available_leaves = available_leaves - total_days

                            # This is to haldle divide by zero error
                            if (total_leaves == "0" or total_leaves == "" or total_leaves == None or total_leaves == "0.0"):
                                quota_value = 0
                                display_quota_value = 0
                            else:
                                quota_value = available_leaves / \
                                    float(total_leaves)
                                display_quota_value = float(
                                    display_available_leaves)/float(display_total_leaves)

                        # This is to insert into leave quota table
                        leave_quota_details = LeaveQuota(
                            leave_quota_id=uuid.uuid4(),
                            unique_quota_id=unique_quota_id,
                            emp_id=emp_id,
                            quota_code=leave_quota_code,
                            quota_valid_from=quota_valid_from,
                            quota_valid_to=quota_valid_to,
                            total_leaves=total_leaves,
                            available_leaves=str(available_leaves),
                            created_date_time=datetime.now(),
                            modified_date_time=datetime.now(),
                            created_by=emp_id,
                            modified_by=emp_id
                        )
                        leave_quota_details.save()

                        quota_data = {
                            "leave_quota_code": leave_quota_code,
                            "leave_quota_text": leave_quota_text,
                            "quota_valid_from": str(quota_valid_from),
                            "quota_valid_to": str(quota_valid_to),
                            "total_leaves": display_total_leaves,
                            "available_leaves": display_available_leaves,
                            "quota_value": display_quota_value
                        }
                        leave_quota.append(quota_data)

                # This is to add active leave quota codes in table
                active_quota_details = ActiveQuotaDetails(
                    active_quota_details_id=uuid.uuid4(),
                    emp_id=emp_id,
                    active_quota_code=active_quota_code,
                    created_date_time=datetime.now(),
                    modified_date_time=datetime.now(),
                    created_by=emp_id,
                    modified_by=emp_id
                )
                active_quota_details.save()

                return True
            else:
                return False
        else:
            return False

    except (Exception) as error:
        print(error)
        return False

# This function is to force run get leave quota


@csrf_exempt
def update_quota_unique_id(request):
    try:
        leave_request_details = LeaveRequestsEDP.objects.all()
        count = 0
        for leave in leave_request_details:

            if leave.unique_quota_id == None or leave.unique_quota_id == "":
                result = force_run_get_leave_quota(leave.requestor_emp_id)
                if result == True:
                    # This is to check leave category againest active quota
                    active_quota_details = ActiveQuotaDetails.objects.filter(
                        emp_id=leave.requestor_emp_id).first()
                    for quota_code in active_quota_details.active_quota_code:
                        leave_quota = QuotaLeaveCategoryMapping.objects.filter(
                            leave_category=leave.leave_category, quota_code=quota_code).first()
                        if leave_quota:
                            break

                    if leave_quota:
                        leave_quota_deatils = LeaveQuota.objects.filter(
                            emp_id=leave.requestor_emp_id,
                            quota_code=leave_quota.quota_code
                        ).order_by('quota_valid_from')

                        if leave_quota_deatils:
                            if leave_quota_deatils.count() <= 1:
                                for leave_data in leave_quota_deatils:
                                    leave.unique_quota_id = leave_data.unique_quota_id
                                    leave.save()

            count += 1
            print(count)

        result = {
            "statusCode": "200",
            "message": "success"
        }
        return JsonResponse(result, safe=False)

    except Exception as error:
        print(error)
        result = {
            "statusCode": "500",
            "message": "fail"
        }
        return JsonResponse(result, safe=False)

# This function is to force run get leave quota


@csrf_exempt
def update_total_leave_days(request):
    try:
        leave_request_details = LeaveRequestsEDP.objects.all()
        count = 0
        for leave in leave_request_details:

            # This is to calulate total woking days
            if leave.leave_type == "FD":
                if leave.from_date == leave.to_date:
                    total_days = 1.0
                else:
                    leave_from_date = datetime.strptime(
                        str(leave.from_date), "%Y-%m-%d").date()
                    leave_to_date = datetime.strptime(
                        str(leave.to_date), "%Y-%m-%d").date()

                    delta = leave_to_date - leave_from_date
                    total_days = float(delta.days) + 1.0
            else:
                total_days = 0.5

            leave.total_days = str(total_days)
            leave.save()

            count += 1
            print(count)

        result = {
            "statusCode": "200",
            "message": "success"
        }
        return JsonResponse(result, safe=False)

    except Exception as error:
        print(error)
        result = {
            "statusCode": "500",
            "message": "fail"
        }
        return JsonResponse(result, safe=False)

# This function is to force run get leave quota


@csrf_exempt
def update_quota_unique_id_using_leave_id(request):
    try:
        leave_data = json.loads(request.body)

        count = 0
        for data in leave_data:
            leave_request_details = LeaveRequestsEDP.objects.filter(
                leave_request_id=data['leave_request_id']).first()

            if leave_request_details:
                if leave_request_details.unique_quota_id == None or leave_request_details.unique_quota_id == "":
                    leave_request_details.unique_quota_id = data['unique_quota_id']
                    leave_request_details.save()
                    count += 1
                    print(count)

        result = {
            "statusCode": "200",
            "message": "success"
        }
        return JsonResponse(result, safe=False)

    except Exception as error:
        print(error)
        result = {
            "statusCode": "500",
            "message": "fail"
        }
        return JsonResponse(result, safe=False)

# This function is to force run get leave quota


@csrf_exempt
def update_leave_status(request):
    try:
        leave_data = json.loads(request.body)
        count = 0
        for data in leave_data:
            leave_request_details = LeaveRequestsEDP.objects.filter(
                leave_request_id=data['leave_request_id']).first()
            if leave_request_details:
                if leave_request_details.leave_status == "8":
                    leave_request_details.leave_status = "2"
                    # leave_request_details.is_deleted = True
                    leave_request_details.save()

                    leave_againest_lwop_details = LeaveAgainstLWOP.objects.filter(
                        leave_request_id=data['leave_request_id']).first()
                    if leave_againest_lwop_details:
                        leave_againest_lwop_details.delete()

                    approved_leave_requests_details = ApprovedLeaveRequests.objects.filter(
                        leave_request_id=data['leave_request_id']).first()
                    if approved_leave_requests_details:
                        approved_leave_requests_details.delete()

                    # is_present_lwop = LeaveAgainstLWOP.objects.filter(leave_request_id = data['leave_request_id']).first()
                    # if not is_present_lwop:
                    #     leave_against_lwop_details = LeaveAgainstLWOP(
                    #         leave_request_id =  data['leave_request_id'],
                    #         created_date_time = datetime.now(),
                    #         is_deleted = False,
                    #         is_posted = False
                    #     )
                    #     leave_against_lwop_details.save()

                    # is_present = ApprovedLeaveRequests.objects.filter(leave_request_id = data['leave_request_id']).first()
                    # if not is_present:
                    #     approved_leave_requests_details = ApprovedLeaveRequests(
                    #         leave_request_id =  data['leave_request_id'],
                    #         created_date_time = datetime.now()
                    #     )
                    #     approved_leave_requests_details.save()

                    count += 1
                    print(count)

        result = {
            "statusCode": "200",
            "message": "success"
        }
        return JsonResponse(result, safe=False)

    except Exception as error:
        print(error)
        result = {
            "statusCode": "500",
            "message": "fail"
        }
        return JsonResponse(result, safe=False)

# This function is to force run get leave quota


@csrf_exempt
def update_delete_posting_timestamp(request):
    try:
        leave_data = json.loads(request.body)

        count = 0
        for data in leave_data:
            sap_posting_details = SAPPostingDetails.objects.filter(
                leave_request_id=data['leave_request_id']).first()

            if sap_posting_details:
                if sap_posting_details.delete_leave_posting_datetime != None:
                    sap_posting_details.delete_leave_posting_datetime = None
                    sap_posting_details.save()
                    count += 1
                    print(count)

        result = {
            "statusCode": "200",
            "message": "success"
        }
        return JsonResponse(result, safe=False)

    except Exception as error:
        print(error)
        result = {
            "statusCode": "500",
            "message": "fail"
        }
        return JsonResponse(result, safe=False)

# This function is to force run get leave quota


@csrf_exempt
def update_lwop_leave_status(request):
    try:
        leave_data = json.loads(request.body)

        count = 0
        for data in leave_data:
            leave_againest_lwop = LeaveAgainstLWOP.objects.filter(
                leave_request_id=data['leave_request_id']).first()
            if leave_againest_lwop:
                approved_leave_requests = ApprovedLeaveRequests.objects.filter(
                    leave_request_id=data['leave_request_id']).first()
                if approved_leave_requests:
                    leave_request_details = LeaveRequestsEDP.objects.filter(
                        leave_request_id=data['leave_request_id']).first()
                    if leave_request_details:
                        if leave_request_details.leave_status == "1":
                            leave_request_details.leave_status = "2"
                            leave_request_details.save()
                            leave_againest_lwop.delete()
                            approved_leave_requests.delete()
                            count += 1
                            print(count)

        result = {
            "statusCode": "200",
            "message": "success"
        }
        return JsonResponse(result, safe=False)

    except Exception as error:
        print(error)
        result = {
            "statusCode": "500",
            "message": "fail"
        }
        return JsonResponse(result, safe=False)

############################################### Force Run Section End #######################################

############################################### Active Year Start  ###############################################

# Insert Active Year


@csrf_exempt
def insert_active_year(request):
    if request.method == 'POST':
        data = json.loads(request.body)

        try:
            # This is to insert active year
            active_year = ActiveYear(
                active_year=data['active_year'],
                created_date_time=datetime.now(),
                modified_date_time=datetime.now(),
                created_by="SYSTEM",
                modified_by="SYSTEM"
            )
            active_year.save()
            result = {
                "status_code": "200",
                "message": "Active Year inserted successfully"
            }

        except Exception as e:
            result = {
                "status_code": "500",
                "message": "Active Year insertion failed"
            }
    else:
        result = {
            "status_code": "500",
            "message": "Incorrect request"
        }
    return JsonResponse(result, safe=False)


# Update into Active Year
@csrf_exempt
def update_active_year(request):
    if request.method == 'POST':
        data = json.loads(request.body)

        try:
            active_year = ActiveYear.objects.filter(
                active_year=data['current_year'])
            if active_year:
                active_year.update(
                    active_year=data['active_year'],
                    created_date_time=datetime.now(),
                    modified_date_time=datetime.now(),
                    created_by="SYSTEM",
                    modified_by="SYSTEM"
                )
                result = {
                    "status_code": "200",
                    "message": "Active Year updated successfully"
                }
            else:
                result = {
                    "status_code": "500",
                    "message": "Active updation failed"
                }

        except Exception as error:
            result = {
                "status_code": "500",
                "message": "Active updation failed"
            }
    else:
        result = {
            "status_code": "500",
            "message": "Incorrect request"
        }
    return JsonResponse(result, safe=False)


@csrf_exempt
def get_active_year(request):
    try:
        active_year = ActiveYear.objects.get().active_year
        result = {'active_year': active_year}
        return_object = return_object_func(constants.HTTP_200_OK, message.SUCCESS_RETIVED_DATA, result)
        return JsonResponse(return_object, safe=False)
    except Exception as error:
        print_error_v1('get_active_year', error)
        return_object = return_object_func(message.ERROR_STATUS_CODE, message.INVALID_REQUEST_BODY, {})
        return JsonResponse(return_object, safe=False)

############################################### Active Year End  ###############################################

############################################### Quota Recalculation Start  #####################################

# Quota recalculation on calendar change


@csrf_exempt
def quota_recalculation(request):
    if request.method == 'POST':
        data = json.loads(request.body)

        try:
            for date in data:
                changed_working_date = date['working_date']
                leave_request_working_details = LeaveRequestsEDP.objects.filter(
                    from_date__lte=changed_working_date, to_date__gte=changed_working_date, is_deleted=False)
                if leave_request_working_details:
                    for leaves in leave_request_working_details:
                        # Quota recalculation for all leave types except Relocation Leave and Maternity Leave
                        if leaves.leave_category != "RL" or leaves.leave_category != "D0":
                            data = {
                                "emp_id": leaves.requestor_emp_id,
                                "from_date": str(leaves.from_date),
                                "to_date": str(leaves.to_date)
                            }
                            working_days_details = get_working_days(data)
                            if working_days_details['status_code'] == "200":
                                leaves.total_days = working_days_details['total_working_days']
                                leaves.save()
                                result = {
                                    "status_code": working_days_details['status_code'],
                                    "message": "Recalculation successfull"
                                }
                            else:
                                result = {
                                    "status_code": working_days_details['status_code'],
                                    "message": "Recalculation unsuccessfull"
                                }
                else:
                    result = {
                        "status_code": "500",
                        "message": "Leave Not Found"
                    }

        except Exception as error:
            print(error)
            result = {
                "status_code": "500",
                "message": "Days Exception"
            }
    else:
        result = {
            "status_code": "500",
            "message": "Incorrect request"
        }
    return JsonResponse(result, safe=False)

############################################### Quota Recalculation End  #######################################

############################################### Team Bot Notification Call ######################################


@csrf_exempt
def teams_notification(request):
    try:
        teams_notification_details = json.loads(request)
        print("user_request", teams_notification_details)
        if(teams_notification_details):
            headers = {
                'Content-Type': 'application/json',
            }
            response = requests.post(config.team_bot_url, headers=headers, data=json.dumps(
                teams_notification_details),timeout=30)
            print(response)
            return JsonResponse(message.SUCCESSFULLY_WORKING, safe=False)
    except Exception as error:
        print(error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE, safe=False)


@csrf_exempt
def team_chatbot_notification(request):
    try:
        teams_notification_details = json.dumps(request)
        print("user_request", teams_notification_details)
        headers = {
            'Content-Type': 'application/json',
        }
        if teams_notification_details:
            response = requests.post(config.team_chatbot_notification,
                                     headers=headers, data=json.dumps(teams_notification_details),timeout=30)
            print(response)
            return JsonResponse(message.SUCCESSFULLY_WORKING, safe=False)
        else:
            JsonResponse(message.INVALID_REQUEST_BODY, safe=False)
    except Exception as error:
        print(error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE, safe=False)

######################################## ADMIN LEAVE DELETE ######################################


@csrf_exempt
def get_leave_cateogory_text_by_code(request):
    try:
        user_request = json.loads(request.body)
        emp_id = f'{(int(user_request["emp_id"])):08}'
        req = {
            "emp_id": emp_id
        }
        # This is used to get the token
        token = request.headers['Authorization'].split()[1]
        headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer' + ' ' + token
        }
        current_date_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).date()

        # this is used to get the pa and psa values
        response = requests.post(
            config.get_edp_employee_details, headers=headers, data=json.dumps(req))
        user_details = response.content.decode("utf-8")
        user_details_json = json.loads(user_details)
        print("user_details_json", user_details_json)
        user_detail_data = user_details_json['user_details'][0]
        PersArea_value = user_detail_data['PersArea']
        PSubarea_value = user_detail_data['PSubarea']

        # this is used to get the leave category text.
        if PersArea_value and PSubarea_value and PSubarea_value != "" and PersArea_value != "":
            ps_group_details = PAPSAGroupMapping.objects.filter(
                pa_code=PersArea_value, psa_code=PSubarea_value).first()
            # print("ps_group_details",ps_group_details.values())
            if ps_group_details:
                leave_category_details = PSGroupLeaveCategoryMapping.objects.filter(
                    pa_psa_group=ps_group_details.pa_psa_group, leave_category_code=user_request['leave_category_code'], valid_from__lte=current_date_ist, valid_to__gte=current_date_ist).first()
                # print("leave_category_details",leave_category_details.values())
                if leave_category_details:
                    leave_category_text = leave_category_details.leave_category_text
                    result = {
                        "status_code": "200",
                        "leave_category_text": leave_category_text
                    }
                    return JsonResponse(result, safe=False)
                else:
                    result = {
                        "status_code": "200",
                        "leave_category_text": "Not found"
                    }
                    return JsonResponse(result, safe=False)
            else:
                return JsonResponse(message.FAIL, safe=False)
        else:
            return JsonResponse(message.FAIL, safe=False)
    except Exception as error:
        print(error)
        return JsonResponse(message.ERROR, safe=False)


@csrf_exempt
def get_personal_area_master(request):
    try:
        pa_data = PAPSAGroupMapping.objects.values(
            'pa_code').distinct('pa_code')
        pa_serialized_data = list(pa_data)
        if(pa_data):
            result = {
                "status_code": "200",
                "message": "Data retrived successfully",
                "pa_data": pa_serialized_data,
            }
            return JsonResponse(result, safe=False)
        else:
            return JsonResponse(message.FAIL, safe=False)
    except Exception as error:
        print(error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE, safe=False)


@csrf_exempt
def get_personal_sub_area_master(request):
    try:
        personal_subarea_data_1 = [{"psa_code": "All"}]
        user_request = json.loads(request.body)
        pa_code = user_request['pa_code']
        pers_subarea = PAPSAGroupMapping.objects.filter(pa_code=pa_code)
        personal_subarea_data = personal_subarea_data_1 + \
            list(pers_subarea.values('psa_code'))
        if(personal_subarea_data):
            result = {
                "status_code": "200",
                "message": "Data retrived successfully",
                "psa_data": personal_subarea_data,
            }
            return JsonResponse(result, safe=False)
        else:
            return JsonResponse(message.FAIL, safe=False)
    except Exception as error:
        print(error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE, safe=False)


@csrf_exempt
def get_leave_request_by_time_office(request):
    try:
        user_request = json.loads(request.body)
        page_number = user_request['page_number']
        print(user_request)

        # this is used to get the current active year.
        active_year_details = ActiveYear.objects.filter(is_active=True).first()
        current_year_ist = int(active_year_details.active_year)
        current_datetime_ist = datetime.now() + timedelta(hours=5, minutes=30)
        current_date_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).date()

        # This is to get leave request details    & Q(leave_status="8") | Q(leave_status="9")
        if(user_request and user_request['month'] == "All"):
            user_leave_request_details = LeaveRequestsEDP.objects.filter(Q(from_date__year=current_year_ist) & (
                Q(leave_status="8") | Q(leave_status="9"))).order_by("leave_status")
        else:
            user_leave_request_details = LeaveRequestsEDP.objects.filter(Q(from_date__year=current_year_ist) & Q(
                from_date__month=user_request['month']) & (Q(leave_status="8") | Q(leave_status="9"))).order_by("leave_status")

        serialized_user_leave_request_details = get_serialize_data(
            user_leave_request_details)
        if(user_request['psa_code'] != "" and user_request['pa_code'] != ""):

            # this is used to get the requestor emp id field from leave_request_edp db
            token = request.headers['Authorization'].split()[1]
            headers = {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer' + ' ' + token
            }
            req = {
                "PSubarea": user_request['psa_code'],
                "PersArea": user_request['pa_code']
            }

            # this is get the employee id which is pa and psa code according to user request
            response = requests.post(
                config.get_employeeid_by_ps_and_psa, headers=headers, data=json.dumps(req))
            user_details = response.content.decode("utf-8")
            edp_common_employee_id = json.loads(user_details)

            if(edp_common_employee_id['status_code'] == "500"):
                return JsonResponse(message.EMPTY_DATA, safe=False)
            user_pa_psa_details = edp_common_employee_id['pa_psa_emp_id']

            # this is used to get store emp_id in list.
            pa_psa_emp_list = []
            for i in range(len(user_pa_psa_details)):
                pa_psa_emp_list.append(user_pa_psa_details[i]['Perno'])

            # this is used to apply filter based on pa and psa
            user_leave_details_based_on_pa_psa = []
            for data in serialized_user_leave_request_details:
                if data['requestor_emp_id'] in pa_psa_emp_list:

                    # This is used to get the status text.
                    leave_status_code = data['leave_status']
                    leave_status_data = LeaveStatus.objects.filter(
                        leave_status_code=leave_status_code).first()
                    data['leave_status'] = leave_status_data.leave_status_text

                    # This is to get the leave type text by leave code
                    leave_type_code = data['leave_type']
                    leave_type_data = LeaveType.objects.filter(
                        leave_type_code=leave_type_code).first()
                    data['leave_type'] = leave_type_data.leave_type_text

                    # this is used to get leave categroy text.
                    req = {
                        "emp_id": f'{(int(data["requestor_emp_id"])):08}'}
                    # This is used to get the token
                    token = request.headers['Authorization'].split()[1]
                    headers = {
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer' + ' ' + token
                    }
                    # this is used to get the pa and psa values
                    response = requests.post(
                        config.get_edp_employee_details, headers=headers, data=json.dumps(req))
                    print("response", response)

                    user_details = response.content.decode("utf-8")
                    user_details_json = json.loads(user_details)
                    user_detail_data = user_details_json['user_details'][0]
                    PersArea_value = user_detail_data['PersArea']
                    PSubarea_value = user_detail_data['PSubarea']

                    ps_group_details = PAPSAGroupMapping.objects.filter(
                        pa_code=PersArea_value, psa_code=PSubarea_value).first()
                    if ps_group_details:
                        leave_category_details = PSGroupLeaveCategoryMapping.objects.filter(
                            pa_psa_group=ps_group_details.pa_psa_group, leave_category_code=data['leave_category'], valid_from__lte=current_date_ist, valid_to__gte=current_date_ist).first()
                        if leave_category_details:
                            leave_category_text = leave_category_details.leave_category_text
                    data['leave_category'] = leave_category_text

                    user_leave_details_based_on_pa_psa.append(data)

        # This is used to get the pagination based leave request details
        if(user_leave_details_based_on_pa_psa):
            page = request.GET.get('page', int(page_number))
            paginator = Paginator(user_leave_details_based_on_pa_psa, 10)
            pagination_based_response_data = paginator.page(page)
            total_pages = str(paginator.num_pages)
            total_leave_request_count = str(paginator.count)
            pagination_based_leave_response = pagination_based_response_data.object_list
        else:
            return JsonResponse(message.EMPTY_DATA, safe=False)

        # pa_psa_employee_id =
        if(pagination_based_leave_response):
            result = {
                "status_code": "200",
                "message": "Leave detail retirved successfully",
                "user_leave_request": pagination_based_leave_response,
                "total_leave_request_count": total_leave_request_count,
                "total_page": total_pages
            }
            return JsonResponse(result, safe=False)
        else:
            return JsonResponse(message.FAIL, safe=False)
    except Exception as error:
        print(error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE, safe=False)

# this is used to get leave request from edp for particular or all months.


@csrf_exempt
def get_edp_leave_request(request):
    try:
        user_request = json.loads(request.body)
        print("req body", user_request)
        # this is used to get the current active year.
        active_year_details = ActiveYear.objects.filter(is_active=True).first()
        current_year_ist = int(active_year_details.active_year)

        # This is to get leave request details    & Q(leave_status="8") | Q(leave_status="9")
        if user_request['leave_status'] != "" and user_request['month'] == "All":
            user_leave_request_details = LeaveRequestsEDP.objects.filter(Q(from_date__year=current_year_ist) & (
                Q(leave_status=user_request['leave_status']))).order_by("leave_status", "from_date")
        elif user_request['leave_status'] != "":
            user_leave_request_details = LeaveRequestsEDP.objects.filter(Q(from_date__year=current_year_ist) & Q(
                from_date__month=user_request['month']) & (Q(leave_status=user_request['leave_status']))).order_by("leave_status", "from_date")
        elif user_request and user_request['month'] == "All":
            user_leave_request_details = LeaveRequestsEDP.objects.filter(Q(from_date__year=current_year_ist) & (
                Q(leave_status="8") | Q(leave_status="9"))).order_by("leave_status", "from_date")
        else:
            user_leave_request_details = LeaveRequestsEDP.objects.filter(Q(from_date__year=current_year_ist) & Q(
                from_date__month=user_request['month']) & (Q(leave_status="8") | Q(leave_status="9"))).order_by("leave_status", "from_date")

        if(user_leave_request_details):
            serialized_user_leave_request_details = get_serialize_data(
                user_leave_request_details)
            result = {
                "status_code": "200",
                "epd_leave_request": serialized_user_leave_request_details
            }
            return JsonResponse(result, safe=False)
        else:
            return JsonResponse(message.SERVER_ERROR_MESSAGE, safe=False)
    except Exception as error:
        print(error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE, safe=False)

# This is used to get leave request based on Personal Area and Personal Subarea.


@csrf_exempt
def get_leave_request_based_on_pa_psa(request):
    try:
        user_request = json.loads(request.body)
        if not user_request:
            return JsonResponse(message.SERVER_ERROR_MESSAGE, safe=False)

        headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer' + ' ' + user_request['token']
        }
        serialized_user_leave_request_details = user_request['serialized_user_leave_request_details']
        pa_psa_emp_list = user_request['pa_psa_emp_list']
        token = user_request['token']

        current_datetime_ist = datetime.now() + timedelta(hours=5, minutes=30)
        current_date_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).date()

        # this is used to apply filter based on pa and psa
        user_leave_details_based_on_pa_psa = []
        for data in serialized_user_leave_request_details:
            if data['requestor_emp_id'] in pa_psa_emp_list:

                # This is used to get the status text.
                leave_status_code = data['leave_status']
                leave_status_data = LeaveStatus.objects.filter(
                    leave_status_code=leave_status_code).first()
                data['leave_status'] = leave_status_data.leave_status_text

                # This is to get the leave type text by leave code
                leave_type_code = data['leave_type']
                leave_type_data = LeaveType.objects.filter(
                    leave_type_code=leave_type_code).first()
                data['leave_type'] = leave_type_data.leave_type_text

                # this is used to get leave categroy text.
                req = {
                    "emp_id": f'{(int(data["requestor_emp_id"])):08}'}

                # this is used to get the pa and psa values
                response = requests.post(
                    config.get_edp_employee_details, headers=headers, data=json.dumps(req))
                print("response", response)
                user_details = response.content.decode("utf-8")
                user_details_json = json.loads(user_details)
                user_detail_data = user_details_json['user_details'][0]
                PersArea_value = user_detail_data['PersArea']
                PSubarea_value = user_detail_data['PSubarea']

                ps_group_details = PAPSAGroupMapping.objects.filter(
                    pa_code=PersArea_value, psa_code=PSubarea_value).first()
                if ps_group_details:
                    leave_category_details = PSGroupLeaveCategoryMapping.objects.filter(
                        pa_psa_group=ps_group_details.pa_psa_group, leave_category_code=data['leave_category'], valid_from__lte=current_date_ist, valid_to__gte=current_date_ist).first()
                    if leave_category_details:
                        leave_category_text = leave_category_details.leave_category_text
                data['leave_category'] = leave_category_text

                user_leave_details_based_on_pa_psa.append(data)
        result = {
            "status_code": "200",
            "user_leave_details_based_on_pa_psa": user_leave_details_based_on_pa_psa
        }
        return JsonResponse(result, safe=False)
    except Exception as error:
        print(error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE, safe=False)


@csrf_exempt
def get_all_edp_leave_request(request):
    try:
        user_request = json.loads(request.body)
        print("user_request", user_request)
        if user_request:
            emp_id = f'{(int(user_request["emp_id"])):08}'
            # this is used to get user and manager details
            req = {
                "emp_id": f'{(int(user_request["emp_id"])):08}'
            }
            # This is used to get the token
            token = request.headers['Authorization'].split()[1]
            headers = {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer' + ' ' + token
            }
            # this is used to get the pa and psa values
            response = requests.post(
                config.get_edp_employee_details, headers=headers, data=json.dumps(req))
            user_details = response.content.decode("utf-8")
            user_details_json = json.loads(user_details)

            if not 'user_details' in user_details_json:
                return JsonResponse(message.EMPTY_DATA, safe=False)
            print(user_details_json)
            user_detail_data = user_details_json['user_details'][0]
            PersArea_value = user_detail_data['PersArea']
            PSubarea_value = user_detail_data['PSubarea']

            # this is used to get the current active year.
            active_year_details = ActiveYear.objects.filter(
                is_active=True).first()
            current_year_ist = int(active_year_details.active_year)
            current_datetime_ist = datetime.now() + timedelta(hours=5, minutes=30)
            current_date_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).date()

            # This is to get leave request details
            if(user_request['month'] == "All"):
                user_leave_request_details = LeaveRequestsEDP.objects.filter(
                    requestor_emp_id=emp_id, from_date__year=current_year_ist).order_by("leave_status", "from_date")
            else:
                user_leave_request_details = LeaveRequestsEDP.objects.filter(
                    requestor_emp_id=emp_id, from_date__year=current_year_ist, from_date__month=user_request['month']).order_by("leave_status", "from_date")
            user_leave_details = get_serialize_data(user_leave_request_details)
            if bool(user_leave_details):
                for data in user_leave_details:

                    # This is to get the leave type text
                    leave_type_code = data['leave_type']
                    leave_type_data = LeaveType.objects.filter(
                        leave_type_code=leave_type_code).first()
                    data['leave_type'] = leave_type_data.leave_type_text

                    # this is used to get the leave category text.
                    ps_group_details = PAPSAGroupMapping.objects.filter(
                        pa_code=PersArea_value, psa_code=PSubarea_value).first()
                    # print("ps_group_details",ps_group_details.values())
                    if ps_group_details:
                        leave_category_details = PSGroupLeaveCategoryMapping.objects.filter(
                            pa_psa_group=ps_group_details.pa_psa_group, leave_category_code=data['leave_category'], valid_from__lte=current_date_ist, valid_to__gte=current_date_ist).first()
                        # print("leave_category_details",leave_category_details.values())
                        if leave_category_details:
                            leave_category_text = leave_category_details.leave_category_text
                    data['leave_category'] = leave_category_text

                    # This is used to get the status text.
                    leave_status_code = data['leave_status']
                    leave_status_data = LeaveStatus.objects.filter(
                        leave_status_code=leave_status_code).first()
                    data['leave_status'] = leave_status_data.leave_status_text
                result = {
                    "status_code": "200",
                    "message": "Leave detail retirved successfully",
                    "user_leave_request": user_leave_details
                }
                return JsonResponse(result, safe=False)
            else:
                return JsonResponse(message.EMPTY_DATA, safe=False)
        else:
            return JsonResponse(message.INVALID_REQUEST_BODY, safe=False)
    except Exception as error:
        print(error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE, safe=False)


# This is used for delete leave request by support & admin portal.
@csrf_exempt
def delete_leave_request_by_admin(request):
    try:
        user_request_body = json.loads(request.body)
        print(user_request_body)
        if bool(user_request_body):
            emp_id = f'{(int(user_request_body["emp_id"])):08}'
            from_date = user_request_body['from_date']
            to_date = user_request_body['to_date']

            # This is to get leave request details
            delete_leave_status = ['3','7','9','8']
            leave_requests_details_edp = LeaveRequestsEDP.objects.filter(
                requestor_emp_id=emp_id, from_date=from_date, to_date=to_date, is_deleted=False).exclude(leave_status__in =delete_leave_status).first()
            if leave_requests_details_edp:
                leave_status = leave_requests_details_edp.leave_status
                print("leave_status",leave_status)
                if str(leave_status) == "2":
                    leave_requests_details_edp.leave_status = "7"
                    leave_requests_details_edp.is_deleted = True
                    leave_requests_details_edp.modified_date_time = datetime.now()
                    leave_requests_details_edp.save()

                    leave_againest_lwop_details = LeaveAgainstLWOP.objects.filter(
                        leave_request_id=user_request_body['leave_request_id']).first()
                    if leave_againest_lwop_details:
                        leave_againest_lwop_details.delete()
                    return JsonResponse(message.SUCCESSFULLY_WORKING, safe=False)
                else:
                    return JsonResponse(message.DELETE_LEAVE_ACCESS_ERROR, safe=False)
            else:
                return JsonResponse(message.UNABLE_TO_DELETE_LEAVE, safe=False)
    except Exception as error:
        print(error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE, safe=False)


@csrf_exempt
def insert_push_notification(request):
    try:
        print(type(request))
        if type(request) is str:
            user_request = json.loads(request)
        else:
            user_request = json.loads(request.body)
        # user_request = json.loads(request)
        request_from = user_request['request_from']
        if user_request["notification_to"]:
            employee_manage_details = []
            # This is used to get the manager employee id by emp id
            if user_request['notification_for'] == "manager":
                user_details = """SELECT * FROM edp_employee_details WHERE "Perno"='{}'""".format(
                    user_request['notification_to'])
                cursor = connection.cursor()
                cursor.execute(user_details)
                records = cursor.fetchall()
                columnNames = [column[0] for column in cursor.description]
                for record in records:
                    employee_manage_details.append(
                        dict(zip(columnNames, record)))
                cursor.close()
                notification_to = employee_manage_details[0]['Reporting']
            else:
                notification_to = user_request["notification_to"]

            # This is used to FCM TOKEN emp by emp id
            print('notification_to', notification_to)
            employee_push_notification_details = EmployeePushNotification.objects.filter(
                emp_id=notification_to).first()

            # This is used to check employee token is present or not.
            if not employee_push_notification_details:
                print("FCM token not present")
                return JsonResponse(message.FAIL, safe=False)

            employee_fcm_token = employee_push_notification_details.emp_fcm_token
            plaftform = employee_push_notification_details.platform
            notification_allowed = employee_push_notification_details.notification_allowed
            notification_access = employee_push_notification_details.notification_access
            show_leave_apply_delete = notification_access["show_leave_apply_delete"]
            show_leave_approve_reject = notification_access["show_leave_approve_reject"]

            #This is used to check the employee push notification is enable/disable 
            if request_from=="show_leave_apply_delete":
                if notification_allowed == constants.NO:
                    print("permission not allowed for sending push notification")
                    return JsonResponse(message.FAIL,safe=False)
                elif notification_allowed == constants.YES:
                    if show_leave_apply_delete==constants.NO:
                        print("permission not allowed for sending push notification")
                        return JsonResponse(message.FAIL,safe=False)
            elif request_from=="show_leave_approve_reject":
                if notification_allowed == constants.NO:
                    print("permission not allowed for sending push notification")
                    return JsonResponse(message.FAIL,safe=False)
                elif notification_allowed == constants.YES:
                    if show_leave_approve_reject==constants.NO:
                        print("permission not allowed for sending push notification")
                        return JsonResponse(message.FAIL,safe=False)
                
            # Request body of push notification.
            if employee_fcm_token:
                push_notification_request_body = {
                    "to": employee_fcm_token,
                    "notification": {
                        "body": user_request["notification_content"],
                        "type": user_request["notification_type"],
                        "title": user_request['notification_title'],
                        "content_available":  True,
                        "priority": "High"
                    },
                    "data": {
                        "body": user_request['data_content'],
                        "title": user_request['data_title'],
                        "type":  user_request['data_type'],
                        "screen_type": user_request['screen_type'],
                        "content_available": True,
                        "priority": "high"
                    }
                }
                if plaftform == "ios":
                    FIREBASE_SECRET_KEY = constants.IOS_FIREBASE_SECRET_KEY
                else:
                    FIREBASE_SECRET_KEY = constants.ANDROID_FIREBASE_SECRET_KEY
                headers = {
                    'Content-Type': 'application/json',
                    'Authorization': 'key=' + FIREBASE_SECRET_KEY
                }
                response = requests.post(constants.PUSH_NOTIFICATION_URL, headers=headers, data=json.dumps(
                    push_notification_request_body))
                push_notification_response = response.content.decode("utf-8")
                push_notification_response_json = json.loads(
                    push_notification_response)
                print("PUSH NOTIFICATION STATUS",
                      push_notification_response_json)
                result = {
                    "status_code": "200",
                    "message": "successfully working",
                    "push_notification_response_json": push_notification_response_json
                }
                return JsonResponse(result, safe=False)
            else:
                return JsonResponse(message.FAIL, safe=False)
        else:
            return JsonResponse(message.FAIL, safe=False)
    except Exception as error:
        print(error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE, safe=False)

# This is used to store employee fcm token in edp db


@csrf_exempt
def insert_employee_fcm_token(request):
    try:
        user_request = json.loads(request.body)
        print("user_request",user_request)
        notification_access = {
                "show_leave_approve_reject":"YES",
                "show_leave_apply_delete":"YES"
            }
        if user_request:
            emp_id = f'{(int(user_request["emp_id"])):08}'
            employee_details = EmployeePushNotification.objects.filter(
                emp_id=emp_id)
            if employee_details:
                employee_details.update(
                    emp_id=user_request['emp_id'],
                    emp_fcm_token=user_request['token'],
                    platform=user_request['platform'],
                    modified_date_time=datetime.now()
                )
                result = {
                    "status_code": "200",
                    "message": "FCM Token update successfully"
                }
                return JsonResponse(result, safe=False)
            else:
                employee_details = EmployeePushNotification(
                    employee_unique_id=str(uuid.uuid4()),
                    emp_id=user_request['emp_id'],
                    platform=user_request['platform'],
                    emp_fcm_token=user_request['token'],
                    create_by=user_request['emp_id'],
                    notification_allowed = constants.YES,
                    announcement_notification = constants.YES,
                    organization_notification = constants.YES,
                    notification_access = notification_access,
                    create_datetime=datetime.now(),
                    modified_date_time=datetime.now(),
                )
                employee_details.save()
                result = {
                    "status_code": "200",
                    "message": "FCM Token insert successfully"
                }
                return JsonResponse(result, safe=False)
        else:
            return JsonResponse(message.SERVER_ERROR_MESSAGE, safe=False)
    except Exception as error:
        print(error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE, safe=False)

@csrf_exempt
def push_notification_customization(request):
    try:
        user_request = json.loads(request.body)
        print(user_request)
        if not user_request or 'action' not in user_request:
            return JsonResponse(message.SERVER_ERROR_MESSAGE,safe=False)
        if user_request['action']=="SET":
            emp_id,notification_allowed,organization_notification,announcement_notification,show_leave_approve_reject,show_leave_apply_delete =  user_request['emp_id'],  user_request['notification_allowed'],user_request['organization_notification'],user_request['announcement_notification'],user_request['show_leave_approve_reject'],user_request['show_leave_apply_delete']
            notification_access = {
                "show_leave_approve_reject":show_leave_approve_reject,
                "show_leave_apply_delete":show_leave_apply_delete
                }
            customized_push_notification = EmployeePushNotification.objects.filter(emp_id=emp_id).first()
            if customized_push_notification:
                customized_push_notification.notification_allowed = notification_allowed
                customized_push_notification.notification_access = notification_access
                customized_push_notification.announcement_notification = announcement_notification
                customized_push_notification.organization_notification = organization_notification
                customized_push_notification.save()
                result = {
                    "status_code":"200",
                    "message":"Your request has been updated"
                }
                return JsonResponse(result,safe=False)
            else:
                return JsonResponse(message.SERVER_ERROR_MESSAGE,safe=False)
        elif user_request['action']=='GET':
            emp_id = user_request['emp_id']
            employee_push_notication = EmployeePushNotification.objects.filter(emp_id=emp_id)
            if employee_push_notication:
                result = {
                    "status_code":"200",
                    "message":"Date captured successfully!",
                    "data":get_serialize_data(employee_push_notication)[0]
                }
                print(get_serialize_data(employee_push_notication)[0])
                return JsonResponse(result,safe=False)
            else:
                return JsonResponse(message.SERVER_ERROR_MESSAGE,safe=False)
        else:
            return JsonResponse(message.SERVER_ERROR_MESSAGE,safe=False)
    except Exception as error:
        print(error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE,safe=False)

#######################################Common section ###################################
# This is used to convert the date time format from yy-mm--dd to dd-mm--yy
def date_format_conversion(date):
    today_date = date.split(" ")[0]
    date_month_year = today_date.split("-")
    formatted_date_time = "-".join(date_month_year[::-1])
    print(formatted_date_time)
    return formatted_date_time

@csrf_exempt
def error_in_deletion_force_run(request):
    try:
        file_name = "errorInPosting.txt"
        file = open(file_name, "w")
        #This is used to get all error in deletion leave request.
        error_in_deletion_leave_data = LeaveRequestsEDP.objects.filter(
            leave_status="9")
        error_in_delection_leave_data_json = get_serialize_data(
            error_in_deletion_leave_data)
        if error_in_delection_leave_data_json:
            for data in error_in_delection_leave_data_json:
                requestor_emp_id = data['requestor_emp_id']
                leave_type = data['leave_type']
                from_date = data['from_date']
                to_date = data['to_date']
                leave_request_id = data['leave_request_id']

                file.write(data['leave_request_id'] + "\n")
                file.write("\n")

                #This is used to check the error in deletion leave is present in sap table.
                sap_leave_request = LeaveRequestsSAP.objects.filter(
                    requestor_emp_id=requestor_emp_id, from_date=from_date, to_date=to_date, leave_type=leave_type)
                # if not sap_leave_request:
                #     leave_request_edp = LeaveRequestsEDP.objects.filter(
                #             leave_request_id=leave_request_id).first()
                #     if leave_request_edp.leave_status == "9":
                #         leave_request_edp.leave_status = "7"
                #         leave_request_edp.is_deleted = True
                #         leave_request_edp.modified_date_time =datetime.now()
                #         leave_request_edp.save()
                            
                #         leave_againest_lwop_details = LeaveAgainstLWOP.objects.filter(
                #                 leave_request_id=leave_request_id).first()
                #         if leave_againest_lwop_details:
                #             leave_againest_lwop_details.delete()

                #         approved_leave_requests_details = ApprovedLeaveRequests.objects.filter(
                #                 leave_request_id=leave_request_id).first()
                #         if approved_leave_requests_details:
                #             approved_leave_requests_details.delete()
                #     else:
                #         print("Cannot delete leave", leave_request_id)
                if sap_leave_request:
                    sap_leave_request_json = get_serialize_data(
                        sap_leave_request)    
                    if str(sap_leave_request_json[0]['leave_category']) in constants.sap_leave_category_status:
                        leave_request_edp = LeaveRequestsEDP.objects.filter(
                            leave_request_id=leave_request_id).first()
                        if leave_request_edp:
                            leave_request_edp.leave_status = "7"
                            leave_request_edp.is_deleted = True
                            leave_request_edp.modified_date_time =datetime.now()
                            leave_request_edp.save()
                            
                            leave_againest_lwop_details = LeaveAgainstLWOP.objects.filter(
                                leave_request_id=leave_request_id).first()
                            if leave_againest_lwop_details:
                                leave_againest_lwop_details.delete()

                            approved_leave_requests_details = ApprovedLeaveRequests.objects.filter(
                                leave_request_id=leave_request_id).first()
                            if approved_leave_requests_details:
                                approved_leave_requests_details.delete()
                        else:
                            print("Leave not found in EDP", leave_request_id)
                    elif not str(sap_leave_request_json[0]['leave_category']) in constants.sap_leave_category_status:
                        leave_request_edp = LeaveRequestsEDP.objects.filter(
                            leave_request_id=leave_request_id).first()
                        if leave_request_edp:
                            leave_request_edp.leave_status = "6"
                            leave_request_edp.is_deleted = False
                            leave_request_edp.modified_date_time =datetime.now()
                            leave_request_edp.save()

                            is_present = ApprovedLeaveRequests.objects.filter(
                                leave_request_id=leave_request_id).first()
                            if not is_present:
                                approved_leave_requests_details = ApprovedLeaveRequests(
                                    leave_request_id=leave_request_id,
                                    created_date_time=datetime.now()
                                )
                                approved_leave_requests_details.save()
                        else:
                            continue
                    else:
                        continue
                else:
                    continue
                    # delete from date duration leave.
            file.close()
            print("SUCESSSSSSSSSSSSSSSSSSS")
            return JsonResponse(message.SUCCESS,safe=False)
        else:
            return JsonResponse(message.FAIL, safe=False)
    except Exception as error:
        print_error_v1("error_in_deletion_force_run",error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE, safe=False)

#This is used to employee landinge page availed leave quota
@csrf_exempt
def get_availed_leaves_data(request):
    try:
        user_request = json.loads(request.body)

        #This is used to syn the employee leave quota
        sync_employee_leave_quota = get_leave_quota(request)
        print(sync_employee_leave_quota)

        emp_id = f'{(int(user_request["emp_id"])):08}'
        available_outcome = 0
        total_outcome = 0
        employee_availed_list = []
        employee_leave_quota = list(LeaveQuota.objects.filter(emp_id=emp_id).values('quota_code','total_leaves','available_leaves'))
        if employee_leave_quota:
            for data in range(len(employee_leave_quota)):
                leave_code = employee_leave_quota[data]['quota_code']
                leave_code_data = Quota.objects.filter(quota_code = leave_code,home_page_visibility=True).first()
                if leave_code_data:
                    leave_category_text = leave_code_data.quota_text
                    employee_leave_quota[data]['leave_category_text'] = leave_category_text
                    total_outcome = total_outcome + float(employee_leave_quota[data]['total_leaves'])
                    available_outcome = available_outcome + float(employee_leave_quota[data]['available_leaves'])
                    employee_leave_quota[data]['leave_category_color'] = leave_code_data.quota_color_text
                    employee_availed_list.append(employee_leave_quota[data])
                else:
                    # employee_leave_quota.pop(data)
                    continue
            result = {
                "status_code":"200",
                "message":"Date captured successfully",
                "leave_quota":list(employee_availed_list),
                "available_outcome":available_outcome,
                "total_outcome":total_outcome
            }
            return JsonResponse(result,safe=False)
        else:
            result = {
                "status_code":"500",
                "message":"Quota not available",
                "leave_quota":employee_availed_list,
                "available_outcome":available_outcome,
                "total_outcome":total_outcome
            }
            return JsonResponse(result,safe=False)
    except Exception as error:
        print(error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE,safe=False)
############################################Previous Year Leave Section Start#######################
@csrf_exempt
def create_previous_year_leave_request_edp(request):
    try:
        leave_request_data = json.loads(request.body)
        # print("create leave request",leave_request_data)
        
        for data in leave_request_data['data']:
            from_date=data['from_date']
            to_date=data['to_date']
            leave_type_code = data['leave_type_code']
            leave_start_date = datetime.strptime(from_date,"%Y-%m-%d")
            leave_end_date = datetime.strptime(to_date,"%Y-%m-%d")
            startdate,enddate=datetime(2021,12,21),datetime(2021,12,31)

            if leave_start_date>=startdate and leave_end_date<= enddate:
                # Validation to check if the leave is already applied on date
                emp_id = f'{(int(leave_request_data["emp_id"])):08}'
                
                leave_requests_details = PreviousYearLeaveRequests.objects.filter(
                Q(requestor_emp_id=emp_id, from_date__lte=from_date, to_date__gte=from_date) |
                Q(requestor_emp_id=emp_id, from_date__lte=to_date, to_date__gte=to_date) |
                Q(requestor_emp_id=emp_id, from_date__gte=from_date,
                  to_date__lte=to_date)).exclude(leave_status="3")

                if leave_requests_details:
                    leave_requests_details_json = get_serialize_data(
                        leave_requests_details)
                    for data1 in leave_requests_details_json:
                        # This is to validate if Leave Type FD,FH or SH is already present
                        if(data1['leave_type'] == leave_type_code):
                            result = {
                                "status_code": "500",
                                "message": "Leave is already applied on selected days"
                            }
                            return JsonResponse(result, safe=False)

                        # This is to validate if Leave Type FD is already present and
                        # Employee is applying for FH or SH
                        if(data1['leave_type'] == "FD" and data1['leave_type'] != leave_type_code):
                            result = {
                                "status_code": "500",
                                "message": "Leave is already applied on selected days"
                            }
                            return JsonResponse(result, safe=False)

                        # This is to validate if Leave Type FH or SH is already present and
                        # Employee is applying for FD
                        if((leave_requests_details_json[0]['leave_type'] == "FH" and leave_type_code == "FD")
                                or (leave_requests_details_json[0]['leave_type'] == "SH" and leave_type_code == "FD")):
                            result = {
                                "status_code": "500",
                                "message": "Leave is already applied on selected days"
                            }
                            return JsonResponse(result, safe=False)
                
                # This is to get current year in IST
                current_date_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).date()
                
                # This is to create unique leave request id
                leave_request_id = str(uuid.uuid4())

                if not "approver_email" in data:
                    data['approver_email'] = constants.system_approver_email
                print("!@@#",leave_request_data)
                print(data['approver'])
                
                # This is to create new leave requests
                leave_request_details = PreviousYearLeaveRequests(
                    leave_request_id=leave_request_id,
                    requestor_emp_id=emp_id,
                    requestor_email=data['requestor_email'],
                    approver_emp_id=data['approver'],
                    approver_email=data['approver_email'],
                    leave_category=data['leave_category_code'],
                    leave_type=data['leave_type_code'],
                    from_date=data['from_date'],
                    to_date=data['to_date'],    
                    reason=data['reason'],
                    total_days=data['total_days'],
                    unique_quota_id=data['unique_quota_id'],
                    leave_status="0",
                    applied_date=current_date_ist,
                    is_deleted=False,
                    created_date_time=datetime.now(),
                    modified_date_time=datetime.now(),
                    created_by=leave_request_data['emp_id'],
                    modified_by=leave_request_data['emp_id'],
                )
                leave_request_details.save()
                            
                if data['approver_email'] != "":
                    leave_category_text = ""
                    leave_type_text = ""

                    # To create email subject
                    current_datetime_ist = datetime.now() + timedelta(hours=5, minutes=30)
                    current_date_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).date()
                    email_subject = leave_request_data['emp_id'] + """ - """ + leave_request_data['emp_name'] + \
                    """ - Leave Request Notification - """ + \
                    str(current_datetime_ist.date())

                    # This is to get leave category text
                    ps_group_details = PAPSAGroupMapping.objects.filter(
                        pa_code=leave_request_data['pa'], psa_code=leave_request_data['psa']).first()
                    if ps_group_details:
                        leave_category_details = PSGroupLeaveCategoryMapping.objects.filter(
                            pa_psa_group=ps_group_details.pa_psa_group, leave_category_code=data['leave_category_code'], valid_from__lte=current_date_ist, valid_to__gte=current_date_ist).first()
                    if leave_category_details:
                        leave_category_text = leave_category_details.leave_category_text

                    # To create a email body
                    email_body = template.leave_request_email_template
                    email_body = email_body.replace(
                        'emp_id', leave_request_data['emp_id'])
                    email_body = email_body.replace(
                        'emp_name', leave_request_data['emp_name'])
                    email_body = email_body.replace(
                        'leave_type', leave_category_text)
                    email_body = email_body.replace(
                        'absence_type', leave_type_text)
                    email_body = email_body.replace(
                        'start_date', data['from_date'])
                    email_body = email_body.replace(
                        'end_date', data['to_date'])
                    email_body = email_body.replace(
                        'leave_reason', data['reason'])

                    # To send attendance email  to manager
                    # send_email_notification(
                    #     data['approver_email'], data['requestor_email'], email_body, email_subject)
                    result = {
                        "status_code": "200",
                        "message": "Leave requests submitted successfully"
                    }
            else:
                result = {
                    "status_code": "200",
                    "message": "Previous year leave regularization is not applicable for selected date."
                }
            return JsonResponse(result, safe=False)
    except (Exception) as error:
        print(error)
        result = {
            "status_code": "500",
            "message": "Unable to Submit leave request"
        }
        return JsonResponse(result, safe=False)
    
#preavious yearleave list
@csrf_exempt
def get_previous_year_leave_requests(request):
    try:
        user_data = json.loads(request.body)
        # To check if employee id is present in json or not
        if user_data["emp_id"] != "":
            emp_id = f'{(int(user_data["emp_id"])):08}'
            previous_year_leave_requests_details = PreviousYearLeaveRequests.objects.filter(requestor_emp_id = emp_id)
            
            if previous_year_leave_requests_details:

                previous_year_leave_requests_details_json= get_serialize_data(previous_year_leave_requests_details)

                for data in previous_year_leave_requests_details_json:
                    # to get leave category text
                    leave_category_code = data['leave_category']
                    data['leave_category'] = get_extended_leave_category_text(
                        user_data['pa'], user_data['psa'], leave_category_code)
                    data['leave_category_code'] = leave_category_code

                    # To get leave type text
                    leave_type_code = data['leave_type']
                    leave_type_details = LeaveType.objects.filter(
                        leave_type_code=leave_type_code).first()
                    if leave_type_details:
                        data['leave_type'] = leave_type_details.leave_type_text
                    else:
                        data['leave_type'] == ""

                    data['leave_type_code'] = leave_type_code

                    # To get leave status text
                    leave_status_code = data['leave_status']
                    leave_status_details = LeaveStatus.objects.filter(
                        leave_status_code=leave_status_code).first()
                    if leave_status_details:
                        data['leave_status'] = leave_status_details.leave_status_text
                    else:
                        data['leave_status'] == ""

                    data['leave_status_code'] = leave_status_code
            
                result = {
                    "status_code": "200",
                    "message": "",
                    "leave_requests": previous_year_leave_requests_details_json,
                    
                }
                return JsonResponse(result, safe=False)
            else:
                result = {
                    "status_code": "200",
                    "message": "",
                    "leave_requests": [],
                    
                }
                return JsonResponse(result, safe=False)
        else:
            result = {
                "status_code": "500",
                "message": "Unable to fetch leave history"
            }
            return JsonResponse(result, safe=False)
    except (Exception) as error:
        print(error)
        result = {
            "status_code": "500",
            "message": "Unable to fetch leave history"
        }
        return JsonResponse(result, safe=False) 

# this is to get previous year leave approvals
@csrf_exempt
def get_previous_year_leave_request_approval(request):
    try:
        user_data = json.loads(request.body)
        token = request.headers['Authorization'].split()[1]
        headers = {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer' + ' ' + token
            }
        # To check if employee id is present in json or not
        if user_data["emp_id"] != "":
            emp_id = user_data["emp_id"]
        else:
            result = {
                "status_code": "500",
                "message": "Invalid employee id"
            }
            return JsonResponse(result, safe=False)

        # This is to get current year IST
        current_year_ist = 2021
    
        if user_data['approval_type'] == "Leave Request":  
            previous_year_leave_requests_details_edp = PreviousYearLeaveRequests.objects.filter(approver_emp_id=emp_id, from_date__year=current_year_ist, is_deleted=False,leave_status="0").order_by('-modified_date_time')
       
        if previous_year_leave_requests_details_edp:
            previous_year_leave_requests_details_edp_json = get_serialize_data(
                previous_year_leave_requests_details_edp)

            for data in previous_year_leave_requests_details_edp_json:
                # This is to get employee name from employee servives
                user = {
                    "emp_id": data['requestor_emp_id']
                }
                data_to_be_serialized = requests.post(config.get_edp_employee_details, headers=headers, data=json.dumps(user))
                user_details_json = data_to_be_serialized.json()
                print(user_details_json)

                # To add employee name in json
                data['requestor_name'] = user_details_json['user_details'][0]['CompName']

                # to get leave category text
                leave_category_code = data['leave_category']
                data['leave_category'] = get_leave_category_text(
                    user_details_json['user_details'][0]['PersArea'], user_details_json['user_details'][0]['PSubarea'], leave_category_code)
                data['leave_category_code'] = leave_category_code

                # To get leave type text
                leave_type_code = data['leave_type']
                leave_type_details = LeaveType.objects.filter(
                    leave_type_code=leave_type_code).first()
                if leave_type_details:
                    data['leave_type'] = leave_type_details.leave_type_text
                else:
                    data['leave_type'] == ""

                data['leave_type_code'] = leave_type_code

                # To get leave status text
                leave_status_code = data['leave_status']
                leave_status_details = LeaveStatus.objects.filter(
                    leave_status_code=leave_status_code).first()
                if leave_status_details:
                    data['leave_status'] = leave_status_details.leave_status_text
                else:
                    data['leave_status'] == ""

                data['leave_status_code'] = leave_status_code

            result = {
                "status_code": "200",
                "message": "",
                "data": {
                    "leave_requests_approval": previous_year_leave_requests_details_edp_json,
                }
            }
            return JsonResponse(result, safe=False)
        else:
            result = {
                "status_code": "200",
                "message": "",
                "data": {
                    "leave_requests_approval": [],
                }
            }
            return JsonResponse(result, safe=False)
    except (Exception) as error:
        print(error)
        result = {
            "status_code": "500",
            "message": "Something went wrong"
        }
        return JsonResponse(result, safe=False)

#This is to approve or reject prevois year leave
@csrf_exempt
def previous_year_leave_request_approval(request):
    
    leave_request_data = json.loads(request.body)
    try: 
        for data in leave_request_data['data']:
            # This is to update status in leave request edp table
            previous_year_leave_request_details = PreviousYearLeaveRequests.objects.filter(
                leave_request_id=data['leave_request_id']).first()
            if previous_year_leave_request_details:
                # if leave_request_data['approval_type'] == "leave_request":
                if leave_request_data['action'] == "0":
                    leave_status = "4"
                else:
                    leave_status = "3"

                previous_year_leave_request_details.leave_status = leave_status
                previous_year_leave_request_details.modified_date_time = datetime.now()
                previous_year_leave_request_details.modified_by = leave_request_data['emp_id']
                previous_year_leave_request_details.save()

            # This is to add record in leave approval table
            previous_year_leave_approval_details = PreviousYearLeaveApproval(
                leave_approval_id=uuid.uuid4(),
                leave_request_id=data['leave_request_id'],
                requestor_emp_id=data['requestor_emp_id'],#'requestor_emp_id'
                action_taken=leave_request_data['action'],
                action_owner=leave_request_data['emp_id'],
                approval_type=leave_request_data['approval_type'],
                created_date_time=datetime.now(),
                modified_date_time=datetime.now(),
                created_by=leave_request_data['emp_id'],
                modified_by=leave_request_data['emp_id'],
            )
            previous_year_leave_approval_details.save()

            if leave_request_data['action'] == "0":
                email_subject = """ Previous Year Leave Approval Notification """
                # to get leave category text
                leave_category_text = get_extended_leave_category_text(
                            leave_request_data['pa'], leave_request_data['psa'], previous_year_leave_request_details.leave_category)
                
                # To get leave type text
                leave_type_details = LeaveType.objects.filter(
                        leave_type_code=previous_year_leave_request_details.leave_type).first()
                if leave_type_details:
                    leave_type_text = leave_type_details.leave_type_text
                else:
                    leave_type_text == ""

                
                email_body = template.leave_approval_email_template
                # to create a email body
                email_body = email_body.replace(
                'emp_id', previous_year_leave_request_details.requestor_emp_id)
                email_body = email_body.replace(
                                         'leave_type', leave_category_text)
                email_body = email_body.replace(
                                        'absence_type', leave_type_text)
                email_body = email_body.replace(
                                        'start_date', str(previous_year_leave_request_details.from_date))
                email_body = email_body.replace(
                                        'end_date', str(previous_year_leave_request_details.to_date))
                email_body = email_body.replace(
                                        'leave_reason', previous_year_leave_request_details.reason)

                                    # To send attendance email to manager
                send_email_notification(
                                        previous_year_leave_request_details.requestor_email,
                                        previous_year_leave_request_details.approver_email, email_body, email_subject)

                        
                result = {
                    "status_code": "200",
                    "message": "Leaves approved sucessfully"
                }   
            else:
                result = {
                    "status_code": "200",
                    "message": "Leaves rejected sucessfully"
                }

        return JsonResponse(result, safe=False)

    except (Exception) as error:
        print(error)
        result = {
            "status_code": "500",
            "message": "Failed to approve leaves"
        }
        return JsonResponse(result, safe=False)

@csrf_exempt
def get_previous_year_leave_requests_master(request):
    try:
        user_data = json.loads(request.body)
        leave_category_values = []
        leave_category_text = ""
        current_date_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).date()

        ps_group_details = PAPSAGroupMapping.objects.filter(
            pa_code=user_data['pa'], psa_code=user_data['psa']).first()
        if ps_group_details:
            leave_category_details = PSGroupLeaveCategoryMapping.objects.filter(
                pa_psa_group=ps_group_details.pa_psa_group, valid_from__lte=current_date_ist, valid_to__gte=current_date_ist,leave_group="1")

            if leave_category_details:
                leave_category_details_json = get_serialize_data(
                    leave_category_details)

                for data in leave_category_details_json:
                    leave_category_data = {
                        "value": data['leave_category_text'],
                        "code": data['leave_category_code']
                    }
                    leave_category_values.append(leave_category_data)
            else:
                result = {
                    "status_code": "500",
                    "message": "",
                }
                return JsonResponse(result, safe=False)
        else:
            result = {
                "status_code": "500",
                "message": "",
            }
            return JsonResponse(result, safe=False)

        result = {
            "status_code": "200",
            "message": "",
            "data": {
                "leave_category": leave_category_values,
            }
        }
        return JsonResponse(result, safe=False)
    except (Exception) as error:
        print(error)
        result = {
            "status_code": "500",
            "message": "",
        }
        return JsonResponse(result, safe=False)

############################################Previous Year Leave Section End#######################

######################## Manager Site Leave Records ##############################################
#Author: Ankush Aher  
#Description: This is used to get month wise employee leaves  
@csrf_exempt
def get_month_wise_employee_leaves(request):
    try:
        user_request = json.loads(request.body)
        emp_id = user_request['emp_id']
        month = user_request['month']
        # this is used to get the current active year.
        active_year_details = ActiveYear.objects.filter(is_active=True).first()
        current_year_ist = int(active_year_details.active_year)

        user_leave_request_details = LeaveRequestsEDP.objects.filter(requestor_emp_id = emp_id, 
        from_date__month=month, from_date__year=current_year_ist).order_by("from_date")
        if(user_leave_request_details):
            serialized_user_leave_request_details = get_serialize_data(
                user_leave_request_details)
            result = {
                "status_code": "200",
                "epd_leave_request": serialized_user_leave_request_details
            }
            return JsonResponse(result, safe=False)
        else:
            return JsonResponse(message.SERVER_ERROR_MESSAGE, safe=False)   
    except (Exception) as error:
        print(error)
        result = {
            "status_code": "500",
            "message": "",
        }
        return JsonResponse(result, safe=False)
#This is used to get attendance leave details 
@csrf_exempt
def get_attendance_leave_details(request):
    try:
        user_request = json.loads(request.body)
        emp_id = user_request['emp_id']
        attendanc_details_response = get_attendance_enquiry(request)
        attendanc_details = attendanc_details_response.content.decode("utf-8")
        user_details_json = json.loads(attendanc_details)
        if user_details_json['status_code']=="200":
            attendance_enquiry_details = user_details_json['attendance_enquiry_details']
            attendance_week_offs = user_details_json['week_offs']
            attendance_public_holidays = user_details_json['public_holidays']
            for attendance_index in range(len(attendance_enquiry_details)):
                attendance_date = attendance_enquiry_details[attendance_index]['LDATE']
                first_half_attendance = attendance_enquiry_details[attendance_index]['FH']
                second_half_attendance = attendance_enquiry_details[attendance_index]['SH']
                attendance_enquiry_details[attendance_index]['start'] = attendance_enquiry_details[attendance_index]['LDATE'] + ' 00:00'
                attendance_enquiry_details[attendance_index]['end'] = attendance_enquiry_details[attendance_index]['LDATE'] + ' 23:59'

                if attendance_date in attendance_week_offs:
                    attendance_enquiry_details[attendance_index]['title'] = constants.WEEKLY_OFF_TEXT
                    attendance_enquiry_details[attendance_index]['hexColor'] = constants.WEEKLY_OFF_COLOR
                    continue

                if attendance_date in attendance_public_holidays:
                    attendance_enquiry_details[attendance_index]['title'] = constants.PUBLIC_HOLIDAY_TEXT
                    attendance_enquiry_details[attendance_index]['hexColor'] = constants.PUBLIC_HOLIDAY_COLOR
                    continue

                leave_details= LeaveRequestsEDP.objects.filter(requestor_emp_id=emp_id, from_date__lte=attendance_date, to_date__gte=attendance_date,is_deleted=False).first()
                if leave_details:
                    leave_status = leave_details.leave_status
                    leave_status_text = LeaveStatus.objects.filter(leave_status_code=leave_status).first()
                    attendance_enquiry_details[attendance_index]['title'] = leave_status_text.leave_status_text
                    attendance_enquiry_details[attendance_index]['hexColor'] = leave_status_text.leave_status_color
                else:
                    attendance_enquiry_details[attendance_index]['hexColor'] = constants.EMPTY_ATTENDANCE_COLOR
                    if not first_half_attendance is None and not second_half_attendance is None:
                        leave_status_text = 'FH: ' + first_half_attendance + '\n' + 'SH: ' + second_half_attendance +'\n'
                        attendance_enquiry_details[attendance_index]['title'] = leave_status_text
                    elif first_half_attendance is None:
                        if not second_half_attendance is None:
                            leave_status_text = 'FH: ' + second_half_attendance 
                            attendance_enquiry_details[attendance_index]['title'] = leave_status_text
                        else:
                            attendance_enquiry_details[attendance_index]['title'] = ""
                    elif second_half_attendance is None:
                        if not first_half_attendance is None:
                            leave_status_text = 'SH: ' + first_half_attendance 
                            attendance_enquiry_details[attendance_index]['title'] = leave_status_text
                        else:
                            attendance_enquiry_details[attendance_index]['title'] = ""
                    else:
                        attendance_enquiry_details[attendance_index]['title'] = ""
            return JsonResponse(user_details_json)
        else:
            return JsonResponse(user_details_json,safe=False)
    except Exception as error:
        print(error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE,safe=False)

# Author: Harish Tambe 
# Description: To get planned leaves of all the reportees of manager
@csrf_exempt
def get_reportees_planned_leaves_details(request):
    try:
        user_request = json.loads(request.body)
        manager_emp_id = f'{(int(user_request["manager_emp_id"])):08}'
        month_filter = user_request['month']
        today_date = date.today()
        current_month = today_date.month
        print(current_month)

        if month_filter!=constants.All_MONTH and int(current_month)>int(month_filter):
            return JsonResponse(message.INVALID_REQUEST_BODY,safe=False)

        reportees_emp_id = []
        token = request.headers['Authorization'].split()[1]
        headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer' + ' ' + token
        }   
        # Interservice call to get reportees data 
        token = request.headers['Authorization'].split()[1]
        headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer' + ' ' + token
        }

        if user_request:     
            user_req = {"emp_id": manager_emp_id}

            # This is used to validate the employee ID.   
            success_factor_response = requests.post(config.get_success_factor_user_details, headers = headers, data = json.dumps(user_req))
            success_factor_details = success_factor_response.content.decode("utf-8")
            success_factor_details_json = json.loads(success_factor_details)
            direct_reportees = success_factor_details_json['user_details']['direct_reportees']
            matrix_reportees = success_factor_details_json['user_details']['matrix_reportees']
            if direct_reportees:
                for data in direct_reportees:
                    reportees_emp_id.append(f'{(int(data["empId"])):08}')
            if matrix_reportees:
                for data in matrix_reportees:
                    reportees_emp_id.append(f'{(int(data["empId"])):08}')
            if month_filter==constants.All_MONTH:
                planned_leaves_data = LeaveRequestsEDP.objects.filter(from_date__month__gte = current_month,leave_status=constants.APPORVED_LEAVE,requestor_emp_id__in =reportees_emp_id, leave_category__in = constants.PLANNED_LEAVE_CATEGORY).values()
            else:
                planned_leaves_data = LeaveRequestsEDP.objects.filter(from_date__month = month_filter,leave_status=constants.APPORVED_LEAVE,requestor_emp_id__in =reportees_emp_id,leave_category__in = constants.PLANNED_LEAVE_CATEGORY).values()

            for data in list(planned_leaves_data):
                user = {
                    "emp_id": data['requestor_emp_id']
                }
                data_to_be_serialized = requests.post(config.get_edp_employee_details, headers=headers, data=json.dumps(user))
                user_details_json = data_to_be_serialized.json()

                # To add employee name in json
                data['requestor_name'] = user_details_json['user_details'][0]['CompName']
                emp_id_list = []
                emp_id_list.append(data['requestor_emp_id'])
                
                #This is used to get employee profile image.
                requesy_body = {"emp_id_list": emp_id_list}
                data_to_be_serialized = requests.post(config.get_profile_picture, headers=headers, data=json.dumps(requesy_body))
                employee_profile_picture = data_to_be_serialized.json()
                if employee_profile_picture['status_code']=="200":
                    data['employee_profile_picture'] = employee_profile_picture['profile_photos'][0]['profile_img']
                else:
                    data['employee_profile_picture']=""
            if planned_leaves_data:
                result = {
                    "status_code": "200",
                    "message": "Data received successfully.",
                    "planned_leaves_data": list(planned_leaves_data)
                }
                return JsonResponse(result, safe=False)
            else:
                result = {
                    "status_code": "200",
                    "message": "No data found.",
                    "planned_leaves_data": []
                }
                return JsonResponse(result, safe=False)
    except Exception as error:
        print(error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE,safe=False)


# This is used to be sending a nudge to the employee to take their leaves more regularly.
@csrf_exempt
def nudge_for_leave(request):
    try:
        token = request.headers['Authorization'].split()[1]
        headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer' + ' ' + token
        }
        user_request = json.loads(request.body)
        notification_request_body = {
            "emp_id": f'{(int(user_request["emp_id"])):08}',
            "emp_name": user_request['emp_name'],
            "reporting_manager": f'{(int(user_request["reporting_manager"])):08}',
            "leave_request_id": "",
            "notification_type": constants.NUDLE_FOR_LEAVE
        }
        
        #This is used to add inapp notifications
        data_to_be_serialized = requests.post(config.add_inapp_notification, headers=headers, data=json.dumps(notification_request_body))
        inapp_notification_response = data_to_be_serialized.json()
        if inapp_notification_response['status_code']=="200":
            mail_request = {
                "emp_name": user_request['emp_name'],
                "reporting_manager": f'{(int(user_request["reporting_manager"])):08}',
                "manager_name": user_request["manager_name"],
                "to_mail_address": user_request["emp_mail"],
                "cc_mail_address": user_request["reporting_manager_mail"]
            }
            request_body_for_mail_template = mail_request
            sender = constants.SYSTEM_APPROVER_MAIL
            subject = constants.NUDGE_FOR_LEAVE_SUBJECT
            mail_salutation = ""
            emp_name = ""
            emp_name = request_body_for_mail_template['emp_name']
            to_mail_address = request_body_for_mail_template['to_mail_address']
            cc_mail_address = request_body_for_mail_template['cc_mail_address']
            mail_salutation = constants.DEAR_MSG + " " + emp_name
            manager_name = request_body_for_mail_template['manager_name']
            mail_template = template.nudge_for_leave_template
            mail_template = mail_template.replace('tata_logo', constants.tata_logo)
            mail_template = mail_template.replace('drishti_heading', constants.drishti_heading)
            mail_template = mail_template.replace('nudge_for_leave', constants.nudge_for_leave)
            mail_template = mail_template.replace('nudge_for_leave_heading', constants.nudge_for_leave_heading)
            mail_template = mail_template.replace('mail_salutation', mail_salutation)
            mail_template = mail_template.replace('nudge_for_leave_text_1', constants.nudge_for_leave_text_1)
            mail_template = mail_template.replace('nudge_for_leave_text_2', constants.nudge_for_leave_text_2)
            mail_template = mail_template.replace('manager_name', manager_name)
            if cc_mail_address != '':
                msg = EmailMultiAlternatives(subject,mail_template,sender,[to_mail_address],cc=[cc_mail_address])
            else:
                msg = EmailMultiAlternatives(subject,mail_template,sender,[to_mail_address])
            msg.attach_alternative(mail_template, "text/html")
            msg.send()
            return JsonResponse(message.NUDGE_SUCCESS,safe=False)
        return JsonResponse(message.SERVER_ERROR_MESSAGE,safe=False)
    except Exception as error:
        print("nudge_for_leave(): ", error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE,safe=False)

#This is used to get InApp leave notification filters
@csrf_exempt
def get_inapp_notification_filter(request):
    try:
        inapp_notification_fitler = {
            "read_type": constants.READ_TYPE_INAPP_NOTIFICATION,
            "approval_type": constants.APPROVAL_TYPE_INAPP_NOTIFICATION,
            "feedback_type": constants.FEEDBACK_INAPP_NOTIFICATION,
            "other_type": constants.OTHER_TYPE_INAPP_NOTIFICATION,
        }
        result = {
            "status_code": "200",
            "message": "Data captured successfully!",
            "data": inapp_notification_fitler
        }
        return JsonResponse(result, safe=False)
    except Exception as error:
        print(error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE, safe=False)

#This is used to resolved automated error in posting case..
@csrf_exempt
def export_to_excel_error_in_posting(request):
    try:
        edp_error_posting_column=[]
        sap_error_posting_column=[]
        for data in range(2):
            leave_schedule_file_name = "leave_update_schedular_0.txt" if data==0 else "leave_update_schedular_1.txt"
            error_in_positing_response = error_in_posting_force_run_v1(leave_schedule_file_name)
        
        #To Get the Error in posting leave case from leave_request_edp table
        remaining_error_in_posting_case = LeaveRequestsEDP.objects.filter(leave_status='8').values_list()
        print("before create file",format(os.getcwd()))
        print(f"File location using __file__ variable: {os.path.realpath(os.path.dirname(__file__))}")
        # os.chdir('/home/sankey/TMLBusinessLogic/i_TML_EDP/EDP-backend/leave_services/')
        # print("new path",os.getcwd())
        edp_error_in_posting = open('remainingErrorInPosting.csv','w') #r'/home/sankey/TMLBusinessLogic/i_TML_EDP/EDP-backend/leave_services/
        print("file created on path --------------->>>",os.getcwd())
        leave_error_csv_writer = csv.writer(edp_error_in_posting)

        print("testing comment #1")
        #To insert the leave error case
        column_meta_data = LeaveRequestsEDP._meta.get_fields()
        for column in column_meta_data:
            edp_error_posting_column.append(column)
        leave_error_csv_writer.writerow(edp_error_posting_column)

        #To insert the leave error case
        for leave_data in remaining_error_in_posting_case:
            leave_error_csv_writer.writerow(leave_data)
        edp_error_in_posting.close()

        print("testing comment #2")
        #Take the dump of SAP Error in posting leave case distinct employee ID.
        emp_id_error_case = LeaveRequestsEDP.objects.filter(leave_status='8').distinct('requestor_emp_id').values_list('requestor_emp_id',flat=True)
        sap_error_case = LeaveRequestsSAP.objects.filter(requestor_emp_id__in = list(emp_id_error_case)).values_list()
        sap_hr_leave_case_file = open('SAP_HR_Leave_Case.csv','w')#/home/sankey/TMLBusinessLogic/i_TML_EDP/EDP-backend/leave_services/
        sap_hr_csv_writer = csv.writer(sap_hr_leave_case_file)

        print("testing comment #2")
        #To insert the leave error case
        sap_column_meta_data = LeaveRequestsSAP._meta.get_fields()
        for column in sap_column_meta_data:
            sap_error_posting_column.append(column)
        sap_hr_csv_writer.writerow(sap_error_posting_column)

        #To insert the leave error case
        for sap_leave_data in sap_error_case:
            sap_hr_csv_writer.writerow(sap_leave_data)
        sap_hr_leave_case_file.close()

        print("Table entry generated successfully")

        #Mail sending configuration
        email = EmailMessage()
        email.subject = constants.SUBJECT_OF_ERROR_POSTING_LEAVE_MAIL
        text_file_1 = os.path.exists('leave_update_schedular_0.txt')
        text_file_2 = os.path.exists('leave_update_schedular_1.txt')
        edp_error_case_file = os.path.exists('remainingErrorInPosting.csv')
        sap_hr_file = os.path.exists('SAP_HR_Leave_Case.csv')
        email.content_subtype = "html"
        email.body =template.BODY_OF_ERROR_POSTING_LEAVE_TEMPLATE
        email.from_email = constants.system_approver_email
        email.to =config.TML_EDP_MAIL_RECIVER
        if text_file_1:
            email.attach_file('leave_update_schedular_0.txt')
        if text_file_2:
            email.attach_file('leave_update_schedular_1.txt')
        if sap_hr_file:
            email.attach_file('SAP_HR_Leave_Case.csv')
        if edp_error_case_file:
            email.attach_file('remainingErrorInPosting.csv')#/home/sankey/TMLBusinessLogic/i_TML_EDP/EDP-backend/leave_services/
        email.send()
        return JsonResponse(message.SUCCESS, safe=False)
    except Exception as error:
        print("error",error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE, safe=False)

#This is used to update leave status 8 to 1 forcefully
@csrf_exempt
def error_in_posting_force_run(leave_schedule_file_name):
    try:
        error_in_posting_leave = get_serialize_data(LeaveRequestsEDP.objects.filter(leave_status='8'))
        for data in error_in_posting_leave:
            leave_request_details = LeaveRequestsEDP.objects.filter(
                leave_request_id=data['leave_request_id']).first()

            if leave_request_details:
                if leave_request_details.leave_status == "8":
                    leave_request_details.leave_status = "1"
                    leave_request_details.save()

                    is_present = ApprovedLeaveRequests.objects.filter(leave_request_id = data['leave_request_id']).first()
                    if not is_present:
                        approved_leave_requests_details = ApprovedLeaveRequests(
                            leave_request_id =  data['leave_request_id'],
                            created_date_time = datetime.now()
                        )
                        approved_leave_requests_details.save()
        force_error_in_posting_sap_update(leave_schedule_file_name)
        result = {
            "statusCode": "200",
            "message": "Your request has been done"
        }
        return JsonResponse(result, safe=False)

    except Exception as error:
        print(error)
        result = {
            "statusCode": "500",
            "message": "fail"
        }
        return JsonResponse(result, safe=False)

# METHOD: force_error_in_posting_sap_update
# DESCRIPTION: This function is to create leave request/update in sap for Error in Posting - Old
# AUTHOR: VIkas Tomar
# Date: 22/09/2022
@csrf_exempt
def force_error_in_posting_sap_update(leave_schedule_file_name):
    try:
        approved_leave_requests_details = ApprovedLeaveRequests.objects.all()
        if approved_leave_requests_details:
            approved_leave_requests_details_json = get_serialize_data(
                approved_leave_requests_details)

            file_name = leave_schedule_file_name
            file = open(file_name, "w")

            for data in approved_leave_requests_details_json:
                try:
                    # hit sap web service to update leave request in SAP
                    leave_request_details = LeaveRequestsEDP.objects.filter(
                        leave_request_id=data['leave_request_id']).first()
                    if leave_request_details:
                        # This is to stop leave updation in case of LWOP
                        leave_against_lwop_details = LeaveAgainstLWOP.objects.filter(
                            leave_request_id=data['leave_request_id']).first()
                        if leave_against_lwop_details and leave_against_lwop_details.is_deleted == False:
                            lwop_delete_sap_response = delete_lwop_leave_request_sap_request(
                                leave_request_details)

                            if lwop_delete_sap_response != None and lwop_delete_sap_response.status_code == 200:
                                lwop_delete_leave_details_sap = json.dumps(xmltodict.parse(
                                    lwop_delete_sap_response.content))  # to convert xml response into dictionary
                                lwop_delete_leave_details_sap_json = json.loads(
                                    lwop_delete_leave_details_sap)

                                if lwop_delete_leave_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['TYPE'] == "S":
                                    leave_against_lwop_details.is_deleted = True
                                    leave_against_lwop_details.save()
                                else:
                                    if leave_request_details.applied_date < (datetime.now().date() - timedelta(days=3)):
                                        if leave_request_details.leave_status == "1":
                                            leave_request_details.leave_status = "8"
                                    continue
                            else:
                                continue

                        if leave_against_lwop_details and leave_against_lwop_details.is_posted == True:
                            continue

                        # This is to update leave in SAP
                        sap_response = update_leave_request_sap_request(
                            leave_request_details)

                        # This is to check wheather th response is in string
                        is_string = isinstance(sap_response, str)
                        if is_string == True:
                            print("SAP webservice failed")

                        if sap_response != None and sap_response.status_code == 200:

                            # to convert xml response into dictionary
                            leave_update_details_sap = json.dumps(
                                xmltodict.parse(sap_response.content))
                            leave_update_sap_json = json.loads(
                                leave_update_details_sap)

                            if leave_update_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['MESSAGE'] !=None:
                                file.write(data['leave_request_id'] + "\n")
                                file.write(leave_update_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['MESSAGE']+ "\n")

                            # This is to allow leave against LWOP
                            sap_status_code = leave_update_sap_json[
                                'soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['TYPE']
                            sap_msg_number = leave_update_sap_json[
                                'soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['NUMBER']
                            print(leave_update_sap_json['soap-env:Envelope']
                                ['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['MESSAGE'])
                            print(leave_update_sap_json['soap-env:Envelope']
                                ['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['TYPE'])
                            print(leave_update_sap_json['soap-env:Envelope']
                                ['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['NUMBER'])
                            emp_id = leave_request_details.requestor_emp_id
                            from_date = leave_request_details.from_date
                            to_date = leave_request_details.to_date

                            #This is used to sync all the leave data.
                            # req_emp_id = {
                            #     "emp_id": emp_id
                            # }
                            # get_leave_history_sap(req_emp_id)
                            # print("Employees Leaves are Synced")

                            sap_leave_request = LeaveRequestsSAP.objects.filter(
                                Q(requestor_emp_id=emp_id, from_date=from_date, to_date=to_date, \
                                  leave_category__in=constants.sap_leave_category_status, is_deleted=False) 
                                # Q(requestor_emp_id=emp_id, from_date=from_date, to_date=to_date, leave_category="Z0P", is_deleted=False) |
                                # Q(requestor_emp_id=emp_id, from_date=from_date, to_date=to_date, leave_category="X0", is_deleted=False) |
                                # Q(requestor_emp_id=emp_id, from_date=from_date, to_date=to_date, leave_category="X0P", is_deleted=False) 
                            )

                            if(sap_status_code == "E" and sap_msg_number == "080" and sap_leave_request):
                                leave_against_lwop_details = LeaveAgainstLWOP(
                                    leave_request_id=data['leave_request_id'],
                                    is_deleted=False,
                                    is_posted=False,
                                    created_date_time=datetime.now()
                                )
                                print("Adding LWOP Leave")
                                leave_against_lwop_details.save()

                            if leave_update_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['TYPE'] == "S":

                                if leave_against_lwop_details and leave_against_lwop_details.is_posted == False:
                                    leave_against_lwop_details.is_posted = True
                                    leave_against_lwop_details.save()

                                # This is to update the status after successfully udpated in SAP
                                leave_request_details = LeaveRequestsEDP.objects.filter(
                                    leave_request_id=data['leave_request_id']).first()
                                if leave_request_details:
                                    if leave_request_details.leave_status == "1":
                                        leave_request_details.leave_status = "2"

                                        # This is to insert leave requst timestamp
                                        sap_posting_details = SAPPostingDetails.objects.filter(
                                            leave_request_id=data['leave_request_id']).first()
                                        if sap_posting_details:
                                            sap_posting_details.leave_request_posting_datetime = datetime.now()
                                            sap_posting_details.created_by = "SYSTEM"
                                            sap_posting_details.modified_by = "SYSTEM"
                                            sap_posting_details.save()

                                    else:
                                        if leave_request_details.leave_status == "6":
                                            leave_request_details.leave_status = "7"
                                            leave_request_details.is_deleted = True

                                        # This is to insert leave requst timestamp
                                        sap_posting_details = SAPPostingDetails.objects.filter(
                                            leave_request_id=data['leave_request_id']).first()
                                        if sap_posting_details:
                                            sap_posting_details.delete_leave_posting_datetime = datetime.now()
                                            sap_posting_details.created_by = "SYSTEM"
                                            sap_posting_details.modified_by = "SYSTEM"
                                            sap_posting_details.save()

                                    leave_request_details.modified_date_time = datetime.now()
                                    leave_request_details.save()

                                # This is to delete the record from approved leave request table
                                approved_leave_request = ApprovedLeaveRequests.objects.filter(
                                    leave_request_id=data['leave_request_id']).delete()

                                if leave_request_details.requestor_email != "":
                                    leave_category_text = ""
                                    leave_type_text = ""

                                    # To create email subject
                                    leave_category_mail = ""
                                    current_datetime_ist = datetime.now() + timedelta(hours=5, minutes=30)
                                    if leave_request_details.leave_status == "2":
                                        leave_category_mail = constants.LEAVE_APPROVAL_NOTIFICATION
                                        email_subject = """Leave Approval Notification - """ + \
                                            str(current_datetime_ist.date())
                                        email_body = template.leave_approval_email_template
                                    else:
                                        leave_category_mail = constants.LEAVE_DELETE_APPROVE
                                        email_subject = """Delete Leave Approval Notification - """ + \
                                            str(current_datetime_ist.date())
                                        email_body = template.delete_leave_approval_email_template

                                    user = {
                                        "emp_id": leave_request_details.requestor_emp_id
                                    }
                                    response = session.post(
                                        config.get_edp_employee_details, data=json.dumps(user))
                                    user_details = response.content.decode("utf-8")
                                    user_details_json = json.loads(user_details)

                                    pa = user_details_json['user_details'][0]['PersArea']
                                    psa = user_details_json['user_details'][0]['PSubarea']
                                    emp_name = user_details_json['user_details'][0]['CompName']
                                    # This is to get leave category text
                                    current_date_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).date()
                                    ps_group_details = PAPSAGroupMapping.objects.filter(
                                        pa_code=pa, psa_code=psa).first()
                                    if ps_group_details:
                                        leave_category_details = PSGroupLeaveCategoryMapping.objects.filter(
                                            pa_psa_group=ps_group_details.pa_psa_group, leave_category_code=leave_request_details.leave_category, valid_from__lte=current_date_ist, valid_to__gte=current_date_ist).first()
                                        if leave_category_details:
                                            leave_category_text = leave_category_details.leave_category_text

                                    # This is to get leave type text
                                    leave_type_details = LeaveType.objects.filter(
                                        leave_type_code=leave_request_details.leave_type).first()
                                    if leave_type_details:
                                        leave_type_text = leave_type_details.leave_type_text

                                    #Request Body - To send leave application approval mail
                                    request_body_for_mail_template = {
                                        constants.LEAVE_CATEGORY_MAIL: leave_category_mail,
                                        constants.EMP_ID:leave_request_details.requestor_emp_id,
                                        constants.EMP_NAME:emp_name,
                                        constants.LEAVE_TYPE:leave_category_text,
                                        constants.ABSENCE_TYPE:leave_type_text,
                                        constants.START_DATE:str(leave_request_details.from_date),
                                        constants.END_DATE:str(leave_request_details.to_date),
                                        constants.LEAVE_REASON: leave_request_details.reason,
                                        constants.TO_MAIL_ADDRESS: leave_request_details.requestor_email,
                                        constants.CC_MAIL_ADDRESS:leave_request_details.approver_email,
                                        constants.LEAVE_REQUESTOR_ROLE : constants.EMPLOYEE_ROLE
                                        
                                    }
                                    mail_response = leave_application_mail(request_body_for_mail_template)
                                    print("approved mail response",mail_response)

                                print("Leave request sucuessfully updated in SAP")
                            else:
                                print("Unable to update request in SAP")

                                # This is to make leave status as error
                                current_date = datetime.now().date()
                                if leave_request_details.applied_date < (datetime.now().date() - timedelta(days=3)):
                                    if leave_request_details.leave_status == "1":
                                        leave_request_details.leave_status = "8"

                                        # This is to insert leave requst timestamp
                                        sap_posting_details = SAPPostingDetails.objects.filter(
                                            leave_request_id=data['leave_request_id']).first()
                                        if sap_posting_details:
                                            sap_posting_details.leave_request_posting_datetime = datetime.now()
                                            sap_posting_details.created_by = "SYSTEM"
                                            sap_posting_details.modified_by = "SYSTEM"
                                            sap_posting_details.save()
                                    else:
                                        leave_request_details.leave_status = "9"

                                    leave_request_details.modified_date_time = datetime.now()
                                    leave_request_details.save()

                                    # This is to delete the record from approved leave request table
                                    approved_leave_request = ApprovedLeaveRequests.objects.filter(
                                        leave_request_id=data['leave_request_id']).delete()
                        else:
                            print("SAP webservice failed.")
                    else:
                        print("leave request is not present in leave deatils table ")
                except Exception as error:
                    print("SAP posting error",error)
                    return JsonResponse(message.SERVER_ERROR_MESSAGE,safe=False)

            # This is insert data in logs table
            leave_services_logs = LeaveServicesLogs(
                log_id=str(uuid.uuid4()),
                log_type="LEAVE POSTING SCHEDULAR",
                result="SUCCESS",
                created_date_time=datetime.now(),
                modified_date_time=datetime.now(),
                created_by="SYSTEM",
                modified_by="SYSTEM"
            )
            leave_services_logs.save()
            file.close()
            print("SUCESSSSSSSSSSSSSSSSSSS")
        else:
            print("No data found to update in SAP")
        return JsonResponse(message.SERVER_ERROR_MESSAGE,safe=False)
    except (Exception) as error:
        print_error_v1("force_error_in_posting_sap_update",error)

        # This is insert data in logs table
        leave_services_logs = LeaveServicesLogs(
            log_id=str(uuid.uuid4()),
            log_type="LEAVE POSTING SCHEDULAR",
            result="FAIL",
            created_date_time=datetime.now(),
            modified_date_time=datetime.now(),
            created_by="SYSTEM",
            modified_by="SYSTEM"
        )
        leave_services_logs.save()

######################################### Admin #########################
@csrf_exempt
def get_admin_leave_insights(request):
    try:
        user_request = json.loads(request.body)
        month = user_request['month']
        date = datetime.now()
        current_year = date.year()
        print(current_year)
        leave_details = LeaveRequestsEDP.objects.filter(leave_category = 'P0')
        data = get_serialize_data(leave_details)
        print('data', data)
        result = {
            "statusCode": "200",
            "message": "Data Retrived Successfully",
            "data": data
        }
        return JsonResponse(result, safe=False)
    except (Exception) as error:
        print(error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE, safe=False)

@csrf_exempt
def get_active_employee_fcm_token(request):
    try:
        token = request.headers['Authorization'].split()[1]
        headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer' + ' ' + token
        }
        user_request = json.loads(request.body)
        notification_type = user_request['notification_type'] if 'notification_type' in user_request else ''
        request_body = {
            "comp_code": constants.COMP_CODE
        }
        data_to_be_serialized = requests.post(config.get_active_employee_list, headers=headers, data=json.dumps(request_body))
        print(data_to_be_serialized)
        print(data_to_be_serialized.status_code)
        active_emp_ids = data_to_be_serialized.json()
        print(active_emp_ids)
        active_employee_ids = active_emp_ids['active_employee_list']
        print("continue")
        # Get fcm token 
        if notification_type == constants.PLATFORM:
            android_employee_token = EmployeePushNotification.objects.filter(emp_id__in = active_employee_ids, platform='android', notification_access__contains={'platform_notification':'YES'}).values_list("emp_fcm_token", flat=True)
            ios_employee_token = EmployeePushNotification.objects.filter(emp_id__in = active_employee_ids, platform='ios', notification_access__contains={'platform_notification':'YES'}).values_list("emp_fcm_token",flat=True)
        else:
            android_employee_token = EmployeePushNotification.objects.filter(emp_id__in = active_employee_ids, platform='android', notification_access__contains={'organization_notification':'YES'}).values_list("emp_fcm_token",flat=True)
            ios_employee_token = EmployeePushNotification.objects.filter(emp_id__in = active_employee_ids, platform='ios', notification_access__contains={'organization_notification':'YES'}).values_list("emp_fcm_token" , flat=True)
        print('android_employee_token', android_employee_token)        
        print('ios_employee_token', ios_employee_token)
        result = {
            "status_code":"200",
            "message":"Success",
            "ios_token": list(ios_employee_token),
            "android_token": list(android_employee_token)
        }
        return JsonResponse(result,safe=False)
    except Exception as error:
        print(error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE,safe=False)

#NOT IN USE - TEMPERORY
@ csrf_exempt
def temp_send_leave_mail(request):
    try:
        user_data = json.loads(request.body)
        sender_mail = constants.FROM_MAIL
        employee_mails = ["vikast.ss@tatamotors.com","mahesh.s@sankeysolutions.com", "bhavik.ss@tatamotors.com", "akshay.s@sankeysolutions.com"]
        mail_text_content = ""
        mail_html_leave_text = constants.LEAVE_MAIL
        # mail_html_leave_text = user_data["leave_template"]
        # mail_html_leave_text = mail_html_leave_text.replace('leave_mail_footer', '"data:image/png;base64,'+constants.leave_mail_footer+'"')
        mail_html_leave_text = mail_html_leave_text.replace('leave_mail_header', '"data:image/png;base64,'+constants.leave_mail_header+'"')
        mail_subject = "Drishti 2.0 - CFM Mail"
        msg = EmailMultiAlternatives(mail_subject, mail_text_content, sender_mail, employee_mails)
        msg.attach_alternative(mail_html_leave_text, "text/html")
        msg.send()
        print("mail send successfully")
        return JsonResponse(message.SUCCESS,safe=False)
    except Exception as error:
        print(error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE,safe=False)

@ csrf_exempt
def temp_leave_mail(request):
    try:
        user_data = json.loads(request.body)
        hti = Html2Image(custom_flags=['--no-sandbox'],size=(540, 370))
        hti.browser_executable = "/usr/bin/google-chrome"
        html = constants.TEMP_IMAGE
        css = "body {background-color: #F0F0F0;, padding:0px;}"

        # screenshot an HTML string (css is optional)
        hti.screenshot(html_str=html, css_str=css, save_as='page.png',size=(540, 370))
        with open("./page.png", "rb") as img_file:
            central_image = base64.b64encode(img_file.read()).decode('utf-8')

        sender_mail = constants.FROM_MAIL
        employee_mails = ["shrikant.p@sankeysolutions.com","mahesh.s@sankeysolutions.com","vikast.ss@tatamotors.com","priya.s2@sankeysolutions.com","aradhana.d@sankeysolutions.com"]
        mail_text_content = ""
        mail_html_leave_text = constants.VIKAS_LEAVE_SANITY
        mail_html_leave_text = mail_html_leave_text.replace('leave_mail_header', constants.leave_mail_header)
        mail_html_leave_text = mail_html_leave_text.replace('center_image', '"data:image/png;base64,'+central_image+'"')
        mail_subject = "Work Anniversary"

        print(mail_html_leave_text)
        msg = EmailMultiAlternatives(mail_subject, mail_text_content, sender_mail, employee_mails)
        msg.attach_alternative(mail_html_leave_text, "text/html")
        msg.send()
        return JsonResponse(message.SUCCESS,safe=False)
    except Exception as error:
        print_error_v1("temp_leave_mail",error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE,safe=False)



@csrf_exempt
def get_fcm_token(request):
    try:
        print("innnnnn----")
        user_request = json.loads(request.body)
        # user_request = request
        request_from = user_request['emp_id']
        employee_push_notification_details = EmployeePushNotification.objects.filter(
            emp_id=request_from).first()

        # This is used to check employee token is present or not.
        if not employee_push_notification_details:
            print("FCM token not present")
            result = {
                "FIREBASE_SECRET_KEY":"",
                "employee_fcm_token":""
            }
            return JsonResponse(result, safe=False)

        employee_fcm_token = employee_push_notification_details.emp_fcm_token
        plaftform = employee_push_notification_details.platform
        notification_allowed = employee_push_notification_details.notification_allowed
        notification_access = employee_push_notification_details.notification_access
                
            # Request body of push notification.
        if employee_fcm_token:
            if plaftform == "ios":
                FIREBASE_SECRET_KEY = constants.IOS_FIREBASE_SECRET_KEY
            else:
                FIREBASE_SECRET_KEY = constants.ANDROID_FIREBASE_SECRET_KEY
            result = {
                "FIREBASE_SECRET_KEY":FIREBASE_SECRET_KEY,
                "employee_fcm_token":employee_fcm_token
            }
            return JsonResponse(result, safe=False)
        else:
            result = {
                "FIREBASE_SECRET_KEY":"",
                "employee_fcm_token":""
            }
            return JsonResponse(result, safe=False)
    except Exception as error:
        print("in exception ")
        print_error_v1(request.path,error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE,safe=False)

@csrf_exempt
def get_sap_data(request):
    try:
        leave_data = json.loads(request.body)
        count = 0
        leave_request_details = LeaveRequestsEDP.objects.filter(leave_status = '1')
        print(leave_request_details)
        for data in leave_request_details:
            emp_id = data['requestor_emp_id']
            from_date = data['from_date']
            print('emp_id', emp_id)
            print('date', from_date)
    except Exception as error:
        print('error', error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE, safe=False)


# Get cet data
def fetch_cet_data(request, emp_id):
    try:
        req = {
            "emp_id": emp_id
        }

        token = request['Authorization'].split()[1]
        headers = {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer' + ' ' + token
        }

        # Interservice call and getting cet data 
        response = requests.post(config.get_edp_employee_details, headers=headers, data=json.dumps(req))
        user_details = response.content.decode("utf-8")
        user_details = json.loads(user_details)
        return user_details
    except Exception as error:
        return error

# METHOD: get_leave_history_sap_v1
# DESCRIPTION: This method will sync the SAP Leave in the leave_requests_SAP
# AUTHOR: Smeet Yelve
# Date: 22/08/2023
@csrf_exempt
def get_leave_history_sap_v1(request):
    try:
        api_name = constants.GET_LEAVE_HISTORY_SAP_V1
        leave_history = []
        if type(request) is dict:
            user_data = request
        else:
            user_data = json.loads(request.body)

        action = constants.VIEW
        status = constants.FAILURE
        # To check if employee id is present in json or not
        if not all (key in user_data and user_data[key] for key in constants.SYNC_EMP_LEAVES):
            return return_response_func(request, return_object_func(constants.HTTP_400_BAD_REQUEST, message.INVALID_REQUEST_BODY, {}))
        
        emp_id = user_data["emp_id"]

        # This is to get current year IST
        active_year_obj = ActiveYear.objects.filter(is_active=True).first()
        if not active_year_obj:
            return JsonResponse(return_object_func(constants.HTTP_400_BAD_REQUEST, message.FAILURE, {}))
        current_year_ist = active_year_obj.active_year
        # current_year_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).year

        valid_from = current_year_ist + "-01-01"
        valid_to = current_year_ist + "-12-31"

        # To get leave quota from SAP
        response = get_leave_history_sap_request(emp_id, valid_from, valid_to)
        # This is to check wheather th response is in string

        if response and response.status_code != constants.HTTP_200_OK:
            print("Status Code:500")
            description = message.INTERNAL_SERVER_ERROR
            leave_error_logs(api_name,action,status,description,requestor_emp_id = emp_id)
            
        leave_history_details_sap = json.dumps(xmltodict.parse(response.content))
        leave_history_details_sap_json = json.loads(leave_history_details_sap)

        leave_details_history=leave_history_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0017Response']['OUTPUT']['item']

        if not isinstance(leave_details_history, list):
                print("Not Instance")
                description = message.NOT_SAME_COMP
                leave_error_logs(api_name,action,status,description,requestor_emp_id = emp_id)
                return JsonResponse(return_object_func(constants.HTTP_400_BAD_REQUEST, message.FAILURE,{}))

        for data in leave_details_history:
            # This is to neglect first item in the body
            if data.get('LEAVE_CODE'):
                leave_history_data = {
                    "leave_category": data.get('LEAVE_CODE'),
                    "applied_date": data.get('APPLIED_DATE'),
                    "from_date": data.get('BEGDA'),
                    "to_date": data.get('ENDDA'),
                    "leave_type": data.get('LEAVE_TYPE'),
                    "total_days": data.get('TOT_LEAVES'),
                    "approver_emp_id": data.get('APPROVER'),
                    "leave_status": data.get('STATUS')
                }
                leave_history.append(leave_history_data)

        if not leave_history:
            print("No Data found")
            description = message.NO_DATA_FOUND
            leave_error_logs(api_name,action,status,description,requestor_emp_id = emp_id)
            return JsonResponse(return_object_func(constants.HTTP_400_BAD_REQUEST, message.FAILURE,{}))

        leave_history_details = LeaveRequestsSAP.objects.filter(requestor_emp_id=emp_id).delete()

        for data in leave_history:
            try:
                leave_status_code = "4"
                leave_status = data.get('leave_status')
                if leave_status != 'Approved':
                    leave_status_data = LeaveStatus.objects.filter(leave_status_text=leave_status).first()
                    if leave_status_data:
                        leave_status_code = leave_status_data.leave_status_code

                leave_history_details = LeaveRequestsSAP(
                    leave_request_id=uuid.uuid4(),
                    requestor_emp_id=emp_id,
                    leave_category=data.get('leave_category'),
                    applied_date=data.get('applied_date'),
                    from_date=data.get('from_date'),
                    to_date=data.get('to_date'),
                    leave_type=data.get('leave_type'),
                    total_days=data.get('total_days'),
                    approver_emp_id=data.get('approver_emp_id'),
                    leave_status=leave_status_code,
                    is_deleted=False,
                    created_date_time=datetime.now(),
                    modified_date_time=datetime.now(),
                    created_by=emp_id,
                    modified_by=emp_id
                )
                leave_history_details.save()
            except (Exception) as error:
                print("Data insertion failed")
                description = error
                leave_error_logs(api_name,action,status,description,requestor_emp_id = emp_id)
                print_error_v1("get_leave_history_sap_v1",error)
                return JsonResponse(return_object_func(constants.HTTP_400_BAD_REQUEST, message.FAILURE,{}))
        
        print("Data updated successfully")
        status = constants.SUCCESS
        description = message.DATA_UPDATED
        leave_error_logs(api_name,action,status,description,requestor_emp_id = emp_id)
        return JsonResponse(return_object_func(constants.HTTP_200_OK, message.DATA_UPDATED,{}))

    except (Exception) as error:
        api_name = constants.GET_LEAVE_HISTORY_SAP_V1
        action = constants.VIEW
        status = constants.FAILURE
        description = error
        leave_error_logs(api_name,action,status,description)
        print_error_v1("get_leave_history_sap_v1", error)
        return JsonResponse(return_object_func(constants.HTTP_400_BAD_REQUEST, message.FAILURE,{}))


# METHOD: sync_leave_requests_sap
# DESCRIPTION: This method will sync the SAP Leave in the leave_requests_SAP
# AUTHOR: Smeet Yelve
# Date: 18/07/2023
@csrf_exempt
def sync_leave_requests_sap(request):
    try:
        api_name = constants.SYNC_LEAVE_REQUEST_SAP
        if type(request) is dict:
            user_request = request
        else:
            user_request = json.loads(request.body)

        #invalid_req_body
        if not all (key in user_request and user_request[key] for key in constants.SYNC_LEAVES):
            return return_response_func(request, return_object_func(constants.HTTP_400_BAD_REQUEST, message.INVALID_REQUEST_BODY, {}))
        
        leave_status = user_request['leave_status']
        if leave_status not in constants.LEAVE_STATUS:
            action = constants.VIEW
            status = constants.FAILURE
            description = message.ADD_CORRECT_LEAVE_STATUS
            leave_error_logs(api_name,action,status,description,leave_status = leave_status)
            return JsonResponse(return_object_func(constants.HTTP_400_BAD_REQUEST, message.ADD_CORRECT_LEAVE_STATUS, {}))
        
        count = 0
        error_cases = LeaveRequestsEDP.objects.filter(leave_status=leave_status).distinct('requestor_emp_id').values_list("requestor_emp_id",flat = True)
        if not error_cases:
            action = constants.VIEW
            status = constants.FAILURE
            description = message.NO_DATA_TO_UPDATE
            leave_error_logs(api_name,action,status,description,leave_status = leave_status)
            return JsonResponse(return_object_func(constants.HTTP_200_OK, message.NO_DATA_TO_UPDATE, {}))
        
        # This is to get current year IST
        active_year_obj = ActiveYear.objects.filter(is_active=True).first()
        if not active_year_obj:
            return JsonResponse(return_object_func(constants.HTTP_400_BAD_REQUEST, message.FAILURE, {}))
        current_year_ist = active_year_obj.active_year
        # current_year_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).year

        valid_from = current_year_ist + "-01-01"
        valid_to = current_year_ist + "-12-31"

        for emp_id in error_cases:
            action = constants.VIEW
            status = constants.FAILURE
            leave_history = []
            count += 1
            string = str(count) + " - " + str(emp_id)
            print(string)

            # To get leave quota from SAP
            response = get_leave_history_sap_request(emp_id, valid_from, valid_to)
            # This is to check wheather the response is in string
            
            # if isinstance(response, str):
            #     # return result
            #     print("Is String:True. Hence failed")
            #     return JsonResponse(return_object_func(constants.HTTP_400_BAD_REQUEST, message.FAILURE,{}))

            if response and response.status_code != constants.HTTP_200_OK:
                print("Status Code:500")
                description = message.INTERNAL_SERVER_ERROR
                leave_error_logs(api_name,action,status,description,requestor_emp_id = emp_id,leave_status = leave_status)
                # return JsonResponse(return_object_func(constants.HTTP_500_INTERNAL_SERVER_ERROR, message.FAILURE,{}))
                continue
            leave_history_details_sap = json.dumps(xmltodict.parse(response.content))
            leave_history_details_sap_json = json.loads(leave_history_details_sap)

            leave_details_history=leave_history_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0017Response']['OUTPUT']['item']
                        
            # check if single record for dependent
            # is_single_leave_history = isinstance(leave_details_history, dict)

            if not isinstance(leave_details_history, list):
                print("Not Instance")
                description = message.NOT_SAME_COMP
                leave_error_logs(api_name,action,status,description,requestor_emp_id = emp_id,leave_status = leave_status)
                # return JsonResponse(return_object_func(constants.HTTP_400_BAD_REQUEST, message.FAILURE,{}))
                continue
            
            for data in leave_details_history:
                if data.get('LEAVE_CODE'):
                    leave_history_data = {
                        "leave_category": data.get('LEAVE_CODE'),
                        "applied_date": data.get('APPLIED_DATE'),
                        "from_date": data.get('BEGDA'),
                        "to_date": data.get('ENDDA'),
                        "leave_type": data.get('LEAVE_TYPE'),
                        "total_days": data.get('TOT_LEAVES'),
                        "approver_emp_id": data.get('APPROVER'),
                        "leave_status": data.get('STATUS')
                    }
                    leave_history.append(leave_history_data)

            if not leave_history:
                print("No Data found")
                description = message.NO_DATA_FOUND
                leave_error_logs(api_name,action,status,description,requestor_emp_id = emp_id,leave_status = leave_status)
                return JsonResponse(return_object_func(constants.HTTP_400_BAD_REQUEST, message.FAILURE,{}))

            leave_history_details = LeaveRequestsSAP.objects.filter(requestor_emp_id=emp_id).delete()

            for data in leave_history:
                try:
                    leave_status_code = "4"
                    leave_status = data.get('leave_status')
                    if leave_status != 'Approved':
                        leave_status_data = LeaveStatus.objects.filter(leave_status_text=leave_status).first()
                        if leave_status_data:
                            leave_status_code = leave_status_data.leave_status_code

                    leave_history_details = LeaveRequestsSAP(
                        leave_request_id=uuid.uuid4(),
                        requestor_emp_id=emp_id,
                        leave_category=data.get('leave_category'),
                        applied_date=data.get('applied_date'),
                        from_date=data.get('from_date'),
                        to_date=data.get('to_date'),
                        leave_type=data.get('leave_type'),
                        total_days=data.get('total_days'),
                        approver_emp_id=data.get('approver_emp_id'),
                        leave_status=leave_status_code,
                        is_deleted=False,
                        created_date_time=datetime.now(),
                        modified_date_time=datetime.now(),
                        created_by=emp_id,
                        modified_by=emp_id
                    )
                    leave_history_details.save()
                except (Exception) as error:
                    print("Data insertion failed")
                    description = error
                    leave_error_logs(api_name,action,status,description,requestor_emp_id = emp_id)
                    print_error_v1("sync_leave_requests_sap",error)
                    return JsonResponse(return_object_func(constants.HTTP_400_BAD_REQUEST, message.FAILURE,{}))
            status = constants.SUCCESS
            description = message.LEAVES_SYNCED
            leave_error_logs(api_name,action,status,description,requestor_emp_id = emp_id,leave_status = user_request['leave_status'])
        print("Data updated successfully")
        status = constants.SUCCESS
        description = message.DATA_UPDATED
        leave_error_logs(api_name,action,status,description,leave_status = user_request['leave_status'])
        return JsonResponse(return_object_func(constants.HTTP_200_OK, message.DATA_UPDATED,{}))
    
    except (Exception) as error:
        api_name = constants.SYNC_LEAVE_REQUEST_SAP
        action = constants.VIEW
        status = constants.FAILURE
        description = error
        leave_error_logs(api_name,action,status,description)
        print_error_v1("sync_leave_requests_sap", error)
        return JsonResponse(return_object_func(constants.HTTP_400_BAD_REQUEST, message.FAILURE,{}))


# METHOD: error_in_posting_force_run_v1
# DESCRIPTION: This method will run the Error in Posting cases
# AUTHOR: Smeet Yelve
# Date: 18/07/2023
@csrf_exempt
def error_in_posting_force_run_v1(leave_schedule_file_name):
    try:
        api_name = constants.ERROR_IN_POSTING_FORCE_RUN_V1
        leave_status = {
            "leave_status":"8"
        }
        count = 0
        sync_leave_requests_sap(leave_status)
        action = constants.EDIT
        status = constants.SUCCESS
        description = message.DATA_UPDATED
        error_in_posting_leave = LeaveRequestsEDP.objects.filter(leave_status=leave_status["leave_status"])
        if not error_in_posting_leave:
            action = constants.EDIT
            status = constants.FAILURE
            description = message.NO_DATA_TO_UPDATE
            leave_error_logs(api_name,action,status,description,leave_status = leave_status["leave_status"])
            return JsonResponse(return_object_func(constants.HTTP_200_OK, message.NO_DATA_TO_UPDATE, {}))
        print(error_in_posting_leave)

        for data in error_in_posting_leave:
            count += 1
            requestor_emp_id = data.requestor_emp_id
            leave_type = data.leave_type
            leave_category = data.leave_category
            from_date = data.from_date
            to_date = data.to_date
            leave_request_id = data.leave_request_id
            print(count,"-",leave_request_id,"-",requestor_emp_id,"-",from_date,"-",to_date,"-",leave_category)
            
            sap_leave_request = LeaveRequestsSAP.objects.filter(
                requestor_emp_id=requestor_emp_id, from_date=from_date, to_date=to_date)
            if leave_category not in constants.EARLY_LATE_ATTENDANCE:
                print("Leave Category",leave_category,)
                sap_leave_request = sap_leave_request.filter(leave_type=leave_type)
            sap_leave_request = sap_leave_request.first()

            if sap_leave_request:
                if sap_leave_request.leave_category == leave_category:
                    data.leave_status = "2"
                    data.modified_date_time =datetime.now()
                    data.save()

                    sap_posting_details = SAPPostingDetails.objects.filter(leave_request_id=leave_request_id).first()
                    if sap_posting_details:
                        sap_posting_details.leave_request_posting_datetime = datetime.now()
                        sap_posting_details.created_by = "SYSTEM"
                        sap_posting_details.modified_by = "SYSTEM"
                        sap_posting_details.save()
                    
                    if data.requestor_email != "":
                        leave_category_text = ""
                        leave_type_text = ""

                        # To create email subject
                        leave_category_mail = ""
                        current_datetime_ist = datetime.now() + timedelta(hours=5, minutes=30)
                        leave_category_mail = constants.LEAVE_APPROVAL_NOTIFICATION
                        email_subject = """Leave Approval Notification - """ + str(current_datetime_ist.date())

                        user = {
                            "emp_id": requestor_emp_id
                        }
                        print("user['emp_id']",requestor_emp_id)
                        response = session.post(config.get_edp_employee_details, data=json.dumps(user))
                        user_details = response.content.decode("utf-8")
                        user_details_json = json.loads(user_details)

                        pa = user_details_json['user_details'][0]['PersArea']
                        psa = user_details_json['user_details'][0]['PSubarea']
                        emp_name = user_details_json['user_details'][0]['CompName']
                        # This is to get leave category text
                        current_date_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).date()
                        ps_group_details = PAPSAGroupMapping.objects.filter(pa_code=pa, psa_code=psa).first()
                        if ps_group_details:
                            leave_category_details = PSGroupLeaveCategoryMapping.objects.filter(
                                pa_psa_group=ps_group_details.pa_psa_group, 
                                leave_category_code=data.leave_category, 
                                valid_from__lte=current_date_ist, 
                                valid_to__gte=current_date_ist).first()
                            if leave_category_details:
                                leave_category_text = leave_category_details.leave_category_text

                        # This is to get leave type text
                        leave_type_details = LeaveType.objects.filter(leave_type_code=data.leave_type).first()
                        if leave_type_details:
                            leave_type_text = leave_type_details.leave_type_text

                        # to create a email body
                        request_body_for_mail_template = {
                            constants.LEAVE_CATEGORY_MAIL: leave_category_mail,
                            constants.EMP_ID: requestor_emp_id,
                            constants.EMP_NAME:emp_name,
                            constants.LEAVE_TYPE:leave_category_text,
                            constants.ABSENCE_TYPE:leave_type_text,
                            constants.START_DATE:str(from_date),
                            constants.END_DATE:str(to_date),
                            constants.LEAVE_REASON: data.reason,
                            constants.TO_MAIL_ADDRESS: data.requestor_email,
                            constants.CC_MAIL_ADDRESS:data.approver_email,
                            constants.LEAVE_REQUESTOR_ROLE : constants.EMPLOYEE_ROLE
                            
                        }
                        mail_response = leave_application_mail(request_body_for_mail_template)
                        print("approved mail response",mail_response)
                        leave_error_logs(api_name,action,status,description, leave_request_details= data,
                                        requestor_emp_id = requestor_emp_id,
                                        leave_status = data.leave_status)
                        continue

                else:
                    if sap_leave_request.leave_category not in constants.sap_leave_category_status:
                        data.leave_status = "7"
                        data.is_deleted = True
                        data.modified_date_time =datetime.now()
                        data.save()

                        sap_posting_details = SAPPostingDetails.objects.filter(leave_request_id=leave_request_id).first()
                        if sap_posting_details:
                            sap_posting_details.delete_leave_datetime = datetime.now()
                            sap_posting_details.created_by = "SYSTEM"
                            sap_posting_details.modified_by = "SYSTEM"
                            sap_posting_details.save()
                            continue
                        leave_error_logs(api_name,action,status,description, leave_request_details= data,
                                        requestor_emp_id = requestor_emp_id,
                                        leave_status = data.leave_status)
                    else:
                        data.leave_status = "1"
                        data.save()

                        is_present = ApprovedLeaveRequests.objects.filter(leave_request_id = leave_request_id).first()
                        if not is_present:
                            approved_leave_requests_details = ApprovedLeaveRequests(
                                leave_request_id =  leave_request_id,
                                created_date_time = datetime.now()
                            )
                            approved_leave_requests_details.save()
                        else:
                            is_present.created_date_time = datetime.now()
                            is_present.save()
                        leave_error_logs(api_name,action,status,description, leave_request_details= data,
                                        requestor_emp_id = requestor_emp_id,
                                        leave_status = data.leave_status)
            else:
                data.leave_status = "1"
                data.save()

                is_present = ApprovedLeaveRequests.objects.filter(leave_request_id = leave_request_id).first()
                if not is_present:
                    approved_leave_requests_details = ApprovedLeaveRequests(
                        leave_request_id =  leave_request_id,
                        created_date_time = datetime.now()
                    )
                    approved_leave_requests_details.save()
                else:
                    is_present.created_date_time = datetime.now()
                    is_present.save()
                leave_error_logs(api_name,action,status,description, leave_request_details= data,
                                        requestor_emp_id = requestor_emp_id,
                                        leave_status = data.leave_status)
        force_error_in_posting_sap_update_v1(leave_schedule_file_name)
        leave_error_logs(api_name,action,status,description)
        return JsonResponse(return_object_func(constants.HTTP_200_OK, message.DATA_UPDATED, {}))

    except Exception as error:
        api_name = constants.ERROR_IN_POSTING_FORCE_RUN_V1
        action = constants.EDIT
        status = constants.FAILURE
        description = error
        leave_error_logs(api_name,action,status,description)
        print_error_v1("error_in_posting_force_run_v1",error)
        return JsonResponse(return_object_func(constants.HTTP_400_BAD_REQUEST, message.FAILURE, {}))



# METHOD: error_in_deletion_force_run_v1
# DESCRIPTION: This method will run the Error in Deletion Cases
# AUTHOR: Smeet Yelve
# Date: 18/07/2023
@csrf_exempt
def error_in_deletion_force_run_v1(request):
    try:
        api_name = constants.ERROR_IN_DELETION_FORCE_RUN_V1
        file_name = "errorInPosting.txt"
        file = open(file_name, "w")
        leave_status = {
            "leave_status":"9"
        }
        count = 0
        #This is used to get all error in deletion leave request.
        sync_leave_requests_sap(leave_status)
        #This is used to get all error in deletion leave request.
        error_in_deletion_leave_data = LeaveRequestsEDP.objects.filter(leave_status=leave_status["leave_status"])
        
        if error_in_deletion_leave_data:
            action = constants.EDIT
            status = constants.SUCCESS
            description = message.DATA_UPDATED
            for data in error_in_deletion_leave_data:
                count +=1
                requestor_emp_id = data.requestor_emp_id
                leave_type = data.leave_type
                from_date = data.from_date
                to_date = data.to_date
                leave_category = data.leave_category
                leave_request_id = data.leave_request_id
                print(count,"-",leave_request_id,"-",requestor_emp_id,"-",from_date,"-",to_date)

                file.write(leave_request_id + "\n")
                file.write("\n")

                #This is used to check the error in deletion leave is present in sap table.
                sap_leave_request = LeaveRequestsSAP.objects.filter(
                    requestor_emp_id=requestor_emp_id, from_date=from_date, to_date=to_date, leave_type=leave_type).first()
                if not sap_leave_request:
                    data.leave_status = "7"
                    data.is_deleted = True
                    data.modified_date_time =datetime.now()
                    data.save()

                    LeaveAgainstLWOP.objects.filter(leave_request_id = leave_request_id).delete()

                    approved_leave_requests_details = ApprovedLeaveRequests.objects.filter(leave_request_id=leave_request_id).delete()
                    # sap_leave_request_json = get_serialize_data(
                    #     sap_leave_request)
                    sap_posting_details = SAPPostingDetails.objects.filter(leave_request_id=leave_request_id).first()
                    if sap_posting_details:
                        sap_posting_details.delete_leave_datetime = datetime.now()
                        sap_posting_details.created_by = "SYSTEM"
                        sap_posting_details.modified_by = "SYSTEM"
                        sap_posting_details.save()
                        continue
                    leave_error_logs(api_name,action,status,description, leave_request_details= data,
                                        requestor_emp_id = requestor_emp_id,
                                        leave_status = data.leave_status)
                else:
                    if sap_leave_request.leave_category in constants.sap_leave_category_status \
                        or leave_category != sap_leave_request.leave_category:
                        print(sap_leave_request.leave_category, "and", leave_category)
                        # print(bool(str(sap_leave_request_json[0]['leave_category']) in constants.sap_leave_category_status))
                        print(bool(leave_category != sap_leave_request.leave_category))
                        print("leave_request_edp: True")
                        data.leave_status = "7"
                        data.is_deleted = True
                        data.modified_date_time =datetime.now()
                        data.save()

                        LeaveAgainstLWOP.objects.filter(leave_request_id=leave_request_id).delete()

                        approved_leave_requests_details = ApprovedLeaveRequests.objects.filter(leave_request_id=leave_request_id).delete()
                        
                        sap_posting_details = SAPPostingDetails.objects.filter(leave_request_id=leave_request_id).first()
                        if sap_posting_details:
                            sap_posting_details.delete_leave_posting_datetime = datetime.now()
                            sap_posting_details.created_by = "SYSTEM"
                            sap_posting_details.modified_by = "SYSTEM"
                            sap_posting_details.save()
                        leave_error_logs(api_name,action,status,description, leave_request_details= data,
                                        requestor_emp_id = requestor_emp_id,
                                        leave_status = data.leave_status)

                    elif sap_leave_request.leave_category == leave_category:
                        print(sap_leave_request.leave_category, "and", leave_category)
                        print(bool(sap_leave_request.leave_category == leave_category))
                        data.leave_status = "6"
                        data.is_deleted = False
                        data.modified_date_time =datetime.now()
                        data.save()
                    
                        is_present = ApprovedLeaveRequests.objects.filter(
                            leave_request_id=leave_request_id).first()
                        if not is_present:
                            approved_leave_requests_details = ApprovedLeaveRequests(
                                leave_request_id=leave_request_id,
                                created_date_time=datetime.now()
                            )
                            approved_leave_requests_details.save()
                        else:
                            is_present.created_date_time = datetime.now()
                            is_present.save()
                        leave_error_logs(api_name,action,status,description, leave_request_details= data,
                                        requestor_emp_id = requestor_emp_id,
                                        leave_status = data.leave_status)
                    else:
                        print("Leave Category Not found in SAP")
                        return JsonResponse(message.FAIL, safe=False)
                    # delete from date duration leave.
            file.close()
            print("SUCESSSSSSSSSSSSSSSSSSS")
            leave_error_logs(api_name,action,status,description)
            return JsonResponse(message.SUCCESS,safe=False)
        else:
            action = constants.EDIT
            status = constants.FAILURE
            description = message.NO_DATA_TO_UPDATE
            leave_error_logs(api_name,action,status,description)
            return JsonResponse(return_object_func(constants.HTTP_200_OK, message.NO_DATA_TO_UPDATE, {}))
    except Exception as error:
        api_name = constants.ERROR_IN_DELETION_FORCE_RUN_V1
        action = constants.EDIT
        status = constants.FAILURE
        description = error
        leave_error_logs(api_name,action,status,description)
        print_error_v1("error_in_deletion_force_run",error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE, safe=False)


# METHOD: update_leave_request_sap_v1
# DESCRIPTION: This function is to create leave request/update in sap - New
# AUTHOR: Smeet Yelve
# Date: 26/08/2023
@csrf_exempt
def update_leave_request_sap_v1():
    try:
        scheduler_name = constants.UPDATE_LEAVE_REQUEST_SAP_V1
        start_scheduler = LeaveSchedulerConfig.objects.filter(scheduler_name = scheduler_name).first()
        if not start_scheduler or (start_scheduler.is_active == False):
            leave_services_logs = LeaveServicesLogs(
                log_id=str(uuid.uuid4()),
                log_type="LEAVE POSTING SCHEDULAR_NEW",
                result="STOPPED",
                created_date_time=datetime.now(),
                modified_date_time=datetime.now(),
                created_by="SYSTEM",
                modified_by="SYSTEM"
            )
            leave_services_logs.save()
            print("Leave Scheduler(New): Leave Scheduler stopped due to executing leave without pay program.")
            status = constants.STOPPED
            description = message.SCHEDULER_STOPPED_V1
            leave_scheduler_logs(scheduler_name,status,description)
            return return_response_func(request, return_object_func(constants.HTTP_400_BAD_REQUEST, message.SCHEDULER_STOPPED, {}))
        print('update start..')
        approved_leave_requests_details = ApprovedLeaveRequests.objects.all()
        if approved_leave_requests_details:
            approved_leave_requests_details_json = get_serialize_data(
                approved_leave_requests_details)

            for data in approved_leave_requests_details_json:
                try:

                    # hit sap web service to update leave request in SAP
                    leave_request_details = LeaveRequestsEDP.objects.filter(
                        leave_request_id=data['leave_request_id']).first()
                    if leave_request_details:
                        emp_id = leave_request_details.requestor_emp_id
                        from_date = leave_request_details.from_date
                        to_date = leave_request_details.to_date

                        # This is to stop leave updation in case of LWOP
                        leave_against_lwop_details = LeaveAgainstLWOP.objects.filter(
                            leave_request_id=data['leave_request_id']).first()
                        if leave_against_lwop_details and leave_against_lwop_details.is_deleted == False:
                            lwop_delete_sap_response = delete_lwop_leave_request_sap_request(
                                leave_request_details)

                            if lwop_delete_sap_response != None and lwop_delete_sap_response.status_code == 200:
                                lwop_delete_leave_details_sap = json.dumps(xmltodict.parse(
                                    lwop_delete_sap_response.content))  # to convert xml response into dictionary
                                lwop_delete_leave_details_sap_json = json.loads(
                                    lwop_delete_leave_details_sap)

                                lwop_sap_msg_code = lwop_delete_leave_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['TYPE']
                                print("Delete LWOP SAP Request MSG Code -->>",lwop_sap_msg_code)
                                lwop_sap_msg_number = lwop_delete_leave_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['NUMBER']
                                print("Delete LWOP SAP Request MSG Number -->>",lwop_sap_msg_number)
                                lwop_sap_message = lwop_delete_leave_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['MESSAGE']
                                print("Delete LWOP SAP Request Message -->>",lwop_sap_message)

                                if lwop_sap_msg_code == "S":
                                    leave_against_lwop_details.is_deleted = True
                                    leave_against_lwop_details.save()

                                    status = constants.SUCCESS
                                    description = message.UPDATE_STOPPED_DUE_TO_LWOP
                                    leave_scheduler_logs(scheduler_name, description, status,leave_request_details, 
                                                     sap_leave_post_type = constants.DEL_LEAVE_REQ, 
                                                     status_code = lwop_sap_msg_code,
                                                     status_number = lwop_sap_msg_number, 
                                                     status_message = lwop_sap_message)
                                    
                                else:
                                    if leave_request_details.applied_date < (datetime.now().date() - timedelta(days=3)):
                                        if leave_request_details.leave_status == "1":
                                            leave_request_details.leave_status = "8"
                                            status = constants.FAILURE
                                            description = message.ERROR_IN_POSTING_LWOP
                                            leave_scheduler_logs(scheduler_name, status, description, leave_request_details,
                                                            sap_leave_post_type = constants.ERROR_IN_POSTING, 
                                                            status_code = lwop_sap_msg_code, 
                                                            status_number = lwop_sap_msg_number, 
                                                            status_message = lwop_sap_message)
                                    continue
                            else:
                                status = constants.FAILURE
                                description = message.INTERNAL_SERVER_ERROR
                                leave_scheduler_logs(scheduler_name, status, description,leave_request_details,
                                                    sap_leave_post_type = constants.DEL_LEAVE_REQ)
                                continue

                        if leave_against_lwop_details and leave_against_lwop_details.is_posted == True:                        
                            status = constants.FAILURE
                            description = message.LEAVE_ALREADY_POSTED
                            leave_scheduler_logs(scheduler_name, status, description, leave_request_details, 
                                                sap_leave_post_type = constants.DEL_LEAVE_REQ)
                            continue

                        # This is to update leave in SAP
                        sap_response = update_leave_request_sap_request(
                            leave_request_details)

                        # This is to check wheather th response is in string
                        is_string = isinstance(sap_response, str)
                        if is_string == True:
                            print("SAP webservice failed")
                            status = constants.FAILURE
                            description = message.WEBSERVICE_FAILED
                            leave_scheduler_logs(scheduler_name, status, description, leave_request_details, 
                                                sap_leave_post_type = constants.POSTING)

                        if sap_response != None and sap_response.status_code == 200:

                            # to convert xml response into dictionary
                            leave_update_details_sap = json.dumps(
                                xmltodict.parse(sap_response.content))
                            leave_update_sap_json = json.loads(
                                leave_update_details_sap)

                            # This is to allow leave against LWOP
                            sap_message =leave_update_sap_json[
                                'soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['MESSAGE']
                            sap_status_code = leave_update_sap_json[
                                'soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['TYPE']
                            sap_msg_number = leave_update_sap_json[
                                'soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['NUMBER']
                            print("Requestor Employee ID -->>",leave_request_details.requestor_emp_id)
                            print("Sap Message Type -->>",sap_status_code)
                            print("Sap Message Number",sap_msg_number)
                            print("Sap Message -->>",sap_message)

                            # This is to Update the leaves in the Leave Requests SAP Table.
                            # req_emp_id = {
                            #     "emp_id": emp_id
                            # }
                            # get_leave_history_sap(req_emp_id)
                            # print("Employees Leaves are Synced")

                            sap_leave_request = LeaveRequestsSAP.objects.filter(
                                Q(requestor_emp_id=emp_id, from_date=from_date, to_date=to_date, \
                                  leave_category__in=constants.sap_leave_category_status, is_deleted=False) 
                            )

                            if(sap_status_code == "E" and sap_msg_number == "080" and sap_leave_request):
                                leave_against_lwop_details = LeaveAgainstLWOP(
                                    leave_request_id=data['leave_request_id'],
                                    is_deleted=False,
                                    is_posted=False,
                                    created_date_time=datetime.now()
                                )
                                print("Adding LWOP Leave")
                                leave_against_lwop_details.save()

                                status = constants.FAILURE
                                description = message.ADD_LWOP_LEAVE
                                leave_scheduler_logs(scheduler_name, status, description, leave_request_details,
                                                    sap_leave_post_type = constants.LWOP_LEAVE,
                                                    status_code = sap_status_code,
                                                    status_number = sap_msg_number,
                                                    status_message = sap_message)

                            if sap_status_code == "S":

                                if leave_against_lwop_details and leave_against_lwop_details.is_posted == False:
                                    leave_against_lwop_details.is_posted = True
                                    leave_against_lwop_details.save()

                                # This is to update the status after successfully udpated in SAP
                                leave_request_details = LeaveRequestsEDP.objects.filter(
                                    leave_request_id=data['leave_request_id']).first()
                                if leave_request_details:
                                    if leave_request_details.leave_status == "1":
                                        leave_request_details.leave_status = "2"

                                        # This is to insert leave requst timestamp
                                        sap_posting_details = SAPPostingDetails.objects.filter(
                                            leave_request_id=data['leave_request_id']).first()
                                        if sap_posting_details:
                                            sap_posting_details.leave_request_posting_datetime = datetime.now()
                                            sap_posting_details.created_by = "SYSTEM"
                                            sap_posting_details.modified_by = "SYSTEM"
                                            sap_posting_details.save()

                                    else:
                                        leave_request_details.leave_status = "7"
                                        leave_request_details.is_deleted = True

                                        # This is to insert leave requst timestamp
                                        sap_posting_details = SAPPostingDetails.objects.filter(
                                            leave_request_id=data['leave_request_id']).first()
                                        if sap_posting_details:
                                            sap_posting_details.delete_leave_posting_datetime = datetime.now()
                                            sap_posting_details.created_by = "SYSTEM"
                                            sap_posting_details.modified_by = "SYSTEM"
                                            sap_posting_details.save()

                                    leave_request_details.modified_date_time = datetime.now()
                                    leave_request_details.save()

                                # This is to delete the record from approved leave request table
                                approved_leave_request = ApprovedLeaveRequests.objects.filter(
                                    leave_request_id=data['leave_request_id']).delete()

                                if leave_request_details.requestor_email != "":
                                    leave_category_text = ""
                                    leave_type_text = ""

                                    # To create email subject
                                    leave_categpory_mail = ""
                                    current_datetime_ist = datetime.now() + timedelta(hours=5, minutes=30)
                                    if leave_request_details.leave_status == "2":
                                        leave_categpory_mail = constants.LEAVE_APPROVAL_NOTIFICATION
                                        email_subject = """Leave Approval Notification - """ + \
                                            str(current_datetime_ist.date())
                                        email_body = template.leave_approval_email_template
                                    else:
                                        leave_categpory_mail = constants.LEAVE_DELETE_APPROVE
                                        email_subject = """Delete Leave Approval Notification - """ + \
                                            str(current_datetime_ist.date())
                                        email_body = template.delete_leave_approval_email_template

                                    user = {
                                        "emp_id": leave_request_details.requestor_emp_id
                                    }
                                    response = session.post(
                                        config.get_edp_employee_details, data=json.dumps(user))
                                    user_details = response.content.decode("utf-8")
                                    user_details_json = json.loads(user_details)

                                    pa = user_details_json['user_details'][0]['PersArea']
                                    psa = user_details_json['user_details'][0]['PSubarea']
                                    emp_name = user_details_json['user_details'][0]['CompName']
                                    # This is to get leave category text
                                    current_date_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).date()
                                    ps_group_details = PAPSAGroupMapping.objects.filter(
                                        pa_code=pa, psa_code=psa).first()
                                    if ps_group_details:
                                        leave_category_details = PSGroupLeaveCategoryMapping.objects.filter(
                                            pa_psa_group=ps_group_details.pa_psa_group, leave_category_code=leave_request_details.leave_category, valid_from__lte=current_date_ist, valid_to__gte=current_date_ist).first()
                                        if leave_category_details:
                                            leave_category_text = leave_category_details.leave_category_text

                                    # This is to get leave type text
                                    leave_type_details = LeaveType.objects.filter(
                                        leave_type_code=leave_request_details.leave_type).first()
                                    if leave_type_details:
                                        leave_type_text = leave_type_details.leave_type_text

                                    #Request Body - To send leave application approval mail
                                    request_body_for_mail_template = {
                                        constants.LEAVE_CATEGORY_MAIL: leave_categpory_mail,
                                        constants.EMP_ID:leave_request_details.requestor_emp_id,
                                        constants.EMP_NAME:emp_name,
                                        constants.LEAVE_TYPE:leave_category_text,
                                        constants.ABSENCE_TYPE:leave_type_text,
                                        constants.START_DATE:str(leave_request_details.from_date),
                                        constants.END_DATE:str(leave_request_details.to_date),
                                        constants.LEAVE_REASON: leave_request_details.reason,
                                        constants.TO_MAIL_ADDRESS: leave_request_details.requestor_email,
                                        constants.CC_MAIL_ADDRESS:leave_request_details.approver_email,
                                        constants.LEAVE_REQUESTOR_ROLE : constants.EMPLOYEE_ROLE
                                        
                                    }
                                    mail_response = leave_application_mail(request_body_for_mail_template)
                                    print("approved mail response",mail_response)

                                print("Leave request sucuessfully updated in SAP")
                                status = constants.SUCCESS
                                description = message.LEAVE_POSTED_IN_SAP
                                leave_scheduler_logs(scheduler_name, status,description,leave_request_details,
                                                    sap_leave_post_type = constants.POSTED, 
                                                    status_code = sap_status_code, 
                                                    status_number = sap_msg_number, 
                                                    status_message = sap_message)
                            else:
                                print("Unable to update request in SAP")

                                # This is to make leave status as error
                                current_date = datetime.now().date()
                                if leave_request_details.applied_date < (datetime.now().date() - timedelta(days=3)):
                                    if leave_request_details.leave_status == "1":
                                        leave_request_details.leave_status = "8"

                                        # This is to insert leave requst timestamp
                                        sap_posting_details = SAPPostingDetails.objects.filter(
                                            leave_request_id=data['leave_request_id']).first()
                                        if sap_posting_details:
                                            sap_posting_details.leave_request_posting_datetime = datetime.now()
                                            sap_posting_details.created_by = "SYSTEM"
                                            sap_posting_details.modified_by = "SYSTEM"
                                            sap_posting_details.save()

                                        status = constants.FAILURE
                                        description = message.ERROR_IN_POSTING
                                        leave_scheduler_logs(scheduler_name, status, description, leave_request_details,
                                                    sap_leave_post_type = constants.NOT_POSTED,
                                                    status_code = sap_status_code,
                                                    status_number = sap_msg_number,
                                                    status_message = sap_message)
                                    else:
                                        leave_request_details.leave_status = "9"
                                        status = constants.FAILURE
                                        description = message.ERROR_IN_DELETION
                                        leave_scheduler_logs(scheduler_name, status, description,leave_request_details,
                                                    sap_leave_post_type = constants.NOT_POSTED,
                                                    status_code = sap_status_code,
                                                    status_number = sap_msg_number,
                                                    status_message = sap_message)
                                    leave_request_details.modified_date_time = datetime.now()
                                    leave_request_details.save()

                                    # This is to delete the record from approved leave request table
                                    approved_leave_request = ApprovedLeaveRequests.objects.filter(
                                        leave_request_id=data['leave_request_id']).delete()
                        else:
                            print("SAP webservice failed.")
                            status = constants.FAILURE
                            description = message.WEBSERVICE_FAILED
                            leave_scheduler_logs(scheduler_name, status, description, leave_request_details,
                                                    sap_leave_post_type = constants.NOT_POSTED)
                    else:
                        print("leave request is not present in leave deatils table ")
                        status = constants.FAILURE
                        description = message. NO_DATA_EDP
                        leave_scheduler_logs(scheduler_name, status, description)
                except Exception as error:
                    print("SAP Posting error",error)
                    status = constants.FAILURE
                    description = error
                    leave_scheduler_logs(scheduler_name, status, description)
                    continue

            # This is insert data in logs table
            leave_services_logs = LeaveServicesLogs(
                log_id=str(uuid.uuid4()),
                log_type="LEAVE POSTING SCHEDULAR",
                result="SUCCESS",
                created_date_time=datetime.now(),
                modified_date_time=datetime.now(),
                created_by="SYSTEM",
                modified_by="SYSTEM"
            )
            leave_services_logs.save()

            status = constants.SUCCESS
            description = message.LEAVE_POSTING_SUCCESSFUL
            leave_scheduler_logs(scheduler_name,status,description)
        else:
            print("No data found to update in SAP")
            status = constants.FAILURE
            description = message.NO_DATA_TO_UPDATE
            leave_scheduler_logs(scheduler_name,status,description)
        return JsonResponse(message.SUCCESSFULLY_WORKING,safe=False)
    except (Exception) as error:
        print_error_v1("update_leave_request_sap_v1",error)
        # This is insert data in logs table
        leave_services_logs = LeaveServicesLogs(
            log_id=str(uuid.uuid4()),
            log_type="LEAVE POSTING SCHEDULAR",
            result="FAIL",
            created_date_time=datetime.now(),
            modified_date_time=datetime.now(),
            created_by="SYSTEM",
            modified_by="SYSTEM"
        )
        leave_services_logs.save()

        status = constants.FAILURE
        description = error
        leave_scheduler_logs(scheduler_name,status,description)
        return JsonResponse(message.SERVER_ERROR_MESSAGE,safe=False)

# METHOD: force_error_in_posting_sap_update_v1
# DESCRIPTION: This function is to create leave request/update in sap for Error in Posting - New
# AUTHOR: Smeet Yelve
# Date: 26/08/2023
@csrf_exempt
def force_error_in_posting_sap_update_v1(leave_schedule_file_name):
    try:
        scheduler_name = constants.FORCE_ERROR_IN_POSTING_SAP_UPDATE_V1
        approved_leave_requests_details = ApprovedLeaveRequests.objects.all()
        if approved_leave_requests_details:
            approved_leave_requests_details_json = get_serialize_data(
                approved_leave_requests_details)

            file_name = leave_schedule_file_name
            file = open(file_name, "w")

            for data in approved_leave_requests_details_json:
                try:
                    # hit sap web service to update leave request in SAP
                    leave_request_details = LeaveRequestsEDP.objects.filter(
                        leave_request_id=data['leave_request_id']).first()
                    if leave_request_details:
                        emp_id = leave_request_details.requestor_emp_id
                        from_date = leave_request_details.from_date
                        to_date = leave_request_details.to_date
                        # This is to stop leave updation in case of LWOP
                        leave_against_lwop_details = LeaveAgainstLWOP.objects.filter(
                            leave_request_id=data['leave_request_id']).first()
                        if leave_against_lwop_details and leave_against_lwop_details.is_deleted == False:
                            lwop_delete_sap_response = delete_lwop_leave_request_sap_request(
                                leave_request_details)

                            if lwop_delete_sap_response != None and lwop_delete_sap_response.status_code == 200:
                                lwop_delete_leave_details_sap = json.dumps(xmltodict.parse(
                                    lwop_delete_sap_response.content))  # to convert xml response into dictionary
                                lwop_delete_leave_details_sap_json = json.loads(
                                    lwop_delete_leave_details_sap)

                                lwop_sap_msg_code = lwop_delete_leave_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['TYPE']
                                print("Delete LWOP SAP Request MSG Code -->>",lwop_sap_msg_code)
                                lwop_sap_msg_number = lwop_delete_leave_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['NUMBER']
                                print("Delete LWOP SAP Request MSG Number -->>",lwop_sap_msg_number)
                                lwop_sap_message = lwop_delete_leave_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['MESSAGE']
                                print("Delete LWOP SAP Request Message -->>",lwop_sap_message)
                                if lwop_sap_msg_code == "S":
                                    leave_against_lwop_details.is_deleted = True
                                    leave_against_lwop_details.save()

                                    status = constants.SUCCESS
                                    description = message.UPDATE_STOPPED_DUE_TO_LWOP
                                    leave_scheduler_logs(scheduler_name, description, status, leave_request_details,
                                                     sap_leave_post_type = constants.DEL_LEAVE_REQ,
                                                     status_code = lwop_sap_msg_code,
                                                     status_number = lwop_sap_msg_number,
                                                     status_message = lwop_sap_message)
                                else:
                                    if leave_request_details.applied_date < (datetime.now().date() - timedelta(days=3)):
                                        if leave_request_details.leave_status == "1":
                                            leave_request_details.leave_status = "8"
                                            status = constants.FAILURE
                                            description = message.ERROR_IN_POSTING_LWOP
                                            leave_scheduler_logs(scheduler_name, status, description, leave_request_details,
                                                            sap_leave_post_type = constants.ERROR_IN_POSTING,
                                                            status_code = lwop_sap_msg_code,
                                                            status_number = lwop_sap_msg_number,
                                                            status_message = lwop_sap_message)
                                    continue
                            else:
                                status = constants.FAILURE
                                description = message.INTERNAL_SERVER_ERROR
                                leave_scheduler_logs(scheduler_name, status, description,leave_request_details, 
                                                    sap_leave_post_type = constants.DEL_LEAVE_REQ)
                                continue

                        if leave_against_lwop_details and leave_against_lwop_details.is_posted == True:
                            status = constants.FAILURE
                            description = message.LEAVE_ALREADY_POSTED
                            leave_scheduler_logs(scheduler_name, status, description,leave_request_details, 
                                                sap_leave_post_type = constants.DEL_LEAVE_REQ)
                            continue

                        # This is to update leave in SAP
                        sap_response = update_leave_request_sap_request(
                            leave_request_details)

                        # This is to check wheather th response is in string
                        is_string = isinstance(sap_response, str)
                        if is_string == True:
                            print("SAP webservice failed")
                            status = constants.FAILURE
                            description = message.WEBSERVICE_FAILED
                            leave_scheduler_logs(scheduler_name, status, description, leave_request_details, 
                                                sap_leave_post_type = constants.POSTING)

                        if sap_response != None and sap_response.status_code == 200:

                            # to convert xml response into dictionary
                            leave_update_details_sap = json.dumps(
                                xmltodict.parse(sap_response.content))
                            leave_update_sap_json = json.loads(
                                leave_update_details_sap)

                            sap_message =leave_update_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['MESSAGE']
                            if sap_message !=None:
                                file.write(data['leave_request_id'] + "\n")
                                file.write(sap_message + "\n")

                            # This is to allow leave against LWOP
                            sap_status_code = leave_update_sap_json[
                                'soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['TYPE']
                            sap_msg_number = leave_update_sap_json[
                                'soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['NUMBER']
                            print("Requestor Employee ID -->>",leave_request_details.requestor_emp_id)
                            print("Sap Message Type -->>",sap_status_code)
                            print("Sap Message Number",sap_msg_number)
                            print("Sap Message -->>",sap_message)

                            #This is used to sync all the leave data.
                            # req_emp_id = {
                            #     "emp_id": emp_id
                            # }
                            # get_leave_history_sap(req_emp_id)
                            # print("Employees Leaves are Synced")

                            sap_leave_request = LeaveRequestsSAP.objects.filter(
                                Q(requestor_emp_id=emp_id, from_date=from_date, to_date=to_date, \
                                  leave_category__in=constants.sap_leave_category_status, is_deleted=False) 
                                # Q(requestor_emp_id=emp_id, from_date=from_date, to_date=to_date, leave_category="Z0P", is_deleted=False) |
                                # Q(requestor_emp_id=emp_id, from_date=from_date, to_date=to_date, leave_category="X0", is_deleted=False) |
                                # Q(requestor_emp_id=emp_id, from_date=from_date, to_date=to_date, leave_category="X0P", is_deleted=False) 
                            )

                            if(sap_status_code == "E" and sap_msg_number == "080" and sap_leave_request):
                                leave_against_lwop_details = LeaveAgainstLWOP(
                                    leave_request_id=data['leave_request_id'],
                                    is_deleted=False,
                                    is_posted=False,
                                    created_date_time=datetime.now()
                                )
                                print("Adding LWOP Leave")
                                leave_against_lwop_details.save()
                                
                                status = constants.FAILURE
                                description = message.ADD_LWOP_LEAVE
                                leave_scheduler_logs(scheduler_name, status, description, leave_request_details,
                                                    sap_leave_post_type = constants.LWOP_LEAVE,
                                                    status_code = sap_status_code,
                                                    status_number = sap_msg_number,
                                                    status_message = sap_message)

                            if sap_status_code == "S":

                                if leave_against_lwop_details and leave_against_lwop_details.is_posted == False:
                                    leave_against_lwop_details.is_posted = True
                                    leave_against_lwop_details.save()

                                # This is to update the status after successfully udpated in SAP
                                leave_request_details = LeaveRequestsEDP.objects.filter(
                                    leave_request_id=data['leave_request_id']).first()
                                if leave_request_details:
                                    if leave_request_details.leave_status == "1":
                                        leave_request_details.leave_status = "2"

                                        # This is to insert leave requst timestamp
                                        sap_posting_details = SAPPostingDetails.objects.filter(
                                            leave_request_id=data['leave_request_id']).first()
                                        if sap_posting_details:
                                            sap_posting_details.leave_request_posting_datetime = datetime.now()
                                            sap_posting_details.created_by = "SYSTEM"
                                            sap_posting_details.modified_by = "SYSTEM"
                                            sap_posting_details.save()

                                    else:
                                        if leave_request_details.leave_status == "6":
                                            leave_request_details.leave_status = "7"
                                            leave_request_details.is_deleted = True

                                        # This is to insert leave requst timestamp
                                        sap_posting_details = SAPPostingDetails.objects.filter(
                                            leave_request_id=data['leave_request_id']).first()
                                        if sap_posting_details:
                                            sap_posting_details.delete_leave_posting_datetime = datetime.now()
                                            sap_posting_details.created_by = "SYSTEM"
                                            sap_posting_details.modified_by = "SYSTEM"
                                            sap_posting_details.save()

                                    leave_request_details.modified_date_time = datetime.now()
                                    leave_request_details.save()

                                # This is to delete the record from approved leave request table
                                approved_leave_request = ApprovedLeaveRequests.objects.filter(
                                    leave_request_id=data['leave_request_id']).delete()

                                if leave_request_details.requestor_email != "":
                                    leave_category_text = ""
                                    leave_type_text = ""

                                    # To create email subject
                                    leave_category_mail = ""
                                    current_datetime_ist = datetime.now() + timedelta(hours=5, minutes=30)
                                    if leave_request_details.leave_status == "2":
                                        leave_category_mail = constants.LEAVE_APPROVAL_NOTIFICATION
                                        email_subject = """Leave Approval Notification - """ + \
                                            str(current_datetime_ist.date())
                                        email_body = template.leave_approval_email_template
                                    else:
                                        leave_category_mail = constants.LEAVE_DELETE_APPROVE
                                        email_subject = """Delete Leave Approval Notification - """ + \
                                            str(current_datetime_ist.date())
                                        email_body = template.delete_leave_approval_email_template

                                    user = {
                                        "emp_id": leave_request_details.requestor_emp_id
                                    }
                                    response = session.post(
                                        config.get_edp_employee_details, data=json.dumps(user))
                                    user_details = response.content.decode("utf-8")
                                    user_details_json = json.loads(user_details)

                                    pa = user_details_json['user_details'][0]['PersArea']
                                    psa = user_details_json['user_details'][0]['PSubarea']
                                    emp_name = user_details_json['user_details'][0]['CompName']
                                    # This is to get leave category text
                                    current_date_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).date()
                                    ps_group_details = PAPSAGroupMapping.objects.filter(
                                        pa_code=pa, psa_code=psa).first()
                                    if ps_group_details:
                                        leave_category_details = PSGroupLeaveCategoryMapping.objects.filter(
                                            pa_psa_group=ps_group_details.pa_psa_group, leave_category_code=leave_request_details.leave_category, valid_from__lte=current_date_ist, valid_to__gte=current_date_ist).first()
                                        if leave_category_details:
                                            leave_category_text = leave_category_details.leave_category_text

                                    # This is to get leave type text
                                    leave_type_details = LeaveType.objects.filter(
                                        leave_type_code=leave_request_details.leave_type).first()
                                    if leave_type_details:
                                        leave_type_text = leave_type_details.leave_type_text

                                    #Request Body - To send leave application approval mail
                                    request_body_for_mail_template = {
                                        constants.LEAVE_CATEGORY_MAIL: leave_category_mail,
                                        constants.EMP_ID:leave_request_details.requestor_emp_id,
                                        constants.EMP_NAME:emp_name,
                                        constants.LEAVE_TYPE:leave_category_text,
                                        constants.ABSENCE_TYPE:leave_type_text,
                                        constants.START_DATE:str(leave_request_details.from_date),
                                        constants.END_DATE:str(leave_request_details.to_date),
                                        constants.LEAVE_REASON: leave_request_details.reason,
                                        constants.TO_MAIL_ADDRESS: leave_request_details.requestor_email,
                                        constants.CC_MAIL_ADDRESS:leave_request_details.approver_email,
                                        constants.LEAVE_REQUESTOR_ROLE : constants.EMPLOYEE_ROLE
                                        
                                    }
                                    mail_response = leave_application_mail(request_body_for_mail_template)
                                    print("approved mail response",mail_response)

                                print("Leave request sucuessfully updated in SAP")
                                status = constants.SUCCESS
                                description = message.LEAVE_POSTED_IN_SAP
                                leave_scheduler_logs(scheduler_name, status, description, leave_request_details,
                                                    sap_leave_post_type = constants.POSTED,
                                                    status_code = sap_status_code,
                                                    status_number = sap_msg_number,
                                                    status_message = sap_message)
                            else:
                                print("Unable to update request in SAP")

                                # This is to make leave status as error
                                current_date = datetime.now().date()
                                if leave_request_details.applied_date < (datetime.now().date() - timedelta(days=3)):
                                    if leave_request_details.leave_status == "1":
                                        leave_request_details.leave_status = "8"

                                        # This is to insert leave requst timestamp
                                        sap_posting_details = SAPPostingDetails.objects.filter(
                                            leave_request_id=data['leave_request_id']).first()
                                        if sap_posting_details:
                                            sap_posting_details.leave_request_posting_datetime = datetime.now()
                                            sap_posting_details.created_by = "SYSTEM"
                                            sap_posting_details.modified_by = "SYSTEM"
                                            sap_posting_details.save()
                                        
                                        status = constants.FAILURE
                                        description = message.ERROR_IN_POSTING
                                        leave_scheduler_logs(scheduler_name, status, description, leave_request_details,
                                                    sap_leave_post_type = constants.NOT_POSTED,
                                                    status_code = sap_status_code,
                                                    status_number = sap_msg_number,
                                                    status_message = sap_message)
                                    else:
                                        leave_request_details.leave_status = "9"

                                        status = constants.FAILURE
                                        description = message.ERROR_IN_DELETION
                                        leave_scheduler_logs(scheduler_name, status, description,leave_request_details,
                                                    sap_leave_post_type = constants.NOT_POSTED,
                                                    status_code = sap_status_code,
                                                    status_number = sap_msg_number,
                                                    status_message = sap_message)
                                    leave_request_details.modified_date_time = datetime.now()
                                    leave_request_details.save()

                                    # This is to delete the record from approved leave request table
                                    approved_leave_request = ApprovedLeaveRequests.objects.filter(
                                        leave_request_id=data['leave_request_id']).delete()
                        else:
                            print("SAP webservice failed.")
                            description = message.WEBSERVICE_FAILED
                            status = constants.FAILURE
                            leave_scheduler_logs(scheduler_name, status, description, leave_request_details,
                                                 sap_leave_post_type = constants.NOT_POSTED)
                    else:
                        print("leave request is not present in leave deatils table ")
                        status = constants.FAILURE
                        description = message. NO_DATA_EDP
                        leave_scheduler_logs(scheduler_name, status, description)
                except Exception as error:
                    print("SAP posting error",error)
                    status = constants.FAILURE
                    description = error
                    leave_scheduler_logs(scheduler_name, status, description)
                    return JsonResponse(message.SERVER_ERROR_MESSAGE,safe=False)

            # This is insert data in logs table
            leave_services_logs = LeaveServicesLogs(
                log_id=str(uuid.uuid4()),
                log_type="FORCE LEAVE POSTING SCHEDULAR",
                result="SUCCESS",
                created_date_time=datetime.now(),
                modified_date_time=datetime.now(),
                created_by="SYSTEM",
                modified_by="SYSTEM"
            )
            leave_services_logs.save()
            file.close()
            print("SUCESSSSSSSSSSSSSSSSSSS")
            status = constants.SUCCESS
            description = message.LEAVE_POSTING_SUCCESSFUL
            leave_scheduler_logs(scheduler_name,status,description)
        else:
            print("No data found to update in SAP")
            status = constants.FAILURE
            description = message.NO_DATA_TO_UPDATE
            leave_scheduler_logs(scheduler_name,status,description)
        return JsonResponse(message.SERVER_ERROR_MESSAGE,safe=False)
    except (Exception) as error:
        print_error_v1("force_error_in_posting_sap_update_v1",error)

        # This is insert data in logs table
        leave_services_logs = LeaveServicesLogs(
            log_id=str(uuid.uuid4()),
            log_type="FORCE LEAVE POSTING SCHEDULAR",
            result="FAIL",
            created_date_time=datetime.now(),
            modified_date_time=datetime.now(),
            created_by="SYSTEM",
            modified_by="SYSTEM"
        )
        leave_services_logs.save()

        status = constants.FAILURE
        description = error
        leave_scheduler_logs(scheduler_name,status,description)

# METHOD: export_to_excel_error_in_posting_v1
# DESCRIPTION: This is the Export to excel leave scheduler
# AUTHOR: Smeet Yelve
# Date: 05/09/2023
@csrf_exempt
def export_to_excel_error_in_posting_v1():
    try:
        scheduler_name = constants.EXPORT_TO_EXCEL_ERROR_IN_POSTING_V1
        start_scheduler = LeaveSchedulerConfig.objects.filter(scheduler_name = scheduler_name).first()
        if not start_scheduler or (start_scheduler.is_active == False):
            print("Export to Excel Scheduler has been stopped.")
            status = constants.STOPPED
            description = message.ERROR_SCHEDULER_STOPPED
            leave_scheduler_logs(scheduler_name,status,description)
            return return_response_func(request, return_object_func(constants.HTTP_400_BAD_REQUEST, message.ERROR_SCHEDULER_STOPPED, {}))
        print("Export to Excel Scheduler Start...")
        edp_error_posting_column=[]
        sap_error_posting_column=[]
        for data in range(2):
            leave_schedule_file_name = "leave_update_schedular_0.txt" if data==0 else "leave_update_schedular_1.txt"
            error_in_positing_response = error_in_posting_force_run_v1(leave_schedule_file_name)
        
        #To Get the Error in posting leave case from leave_request_edp table
        remaining_error_in_posting_case = LeaveRequestsEDP.objects.filter(leave_status='8').values_list()
        print("before create file",format(os.getcwd()))
        print(f"File location using __file__ variable: {os.path.realpath(os.path.dirname(__file__))}")
        # os.chdir('/home/sankey/TMLBusinessLogic/i_TML_EDP/EDP-backend/leave_services/')
        # print("new path",os.getcwd())
        edp_error_in_posting = open('remainingErrorInPosting.csv','w') #r'/home/sankey/TMLBusinessLogic/i_TML_EDP/EDP-backend/leave_services/
        print("file created on path --------------->>>",os.getcwd())
        leave_error_csv_writer = csv.writer(edp_error_in_posting)

        print("testing comment #1")
        #To insert the leave error case
        column_meta_data = LeaveRequestsEDP._meta.get_fields()
        for column in column_meta_data:
            edp_error_posting_column.append(column)
        leave_error_csv_writer.writerow(edp_error_posting_column)

        #To insert the leave error case
        for leave_data in remaining_error_in_posting_case:
            leave_error_csv_writer.writerow(leave_data)
        edp_error_in_posting.close()

        print("testing comment #2")
        #Take the dump of SAP Error in posting leave case distinct employee ID.
        emp_id_error_case = LeaveRequestsEDP.objects.filter(leave_status='8').distinct('requestor_emp_id').values_list('requestor_emp_id',flat=True)
        sap_error_case = LeaveRequestsSAP.objects.filter(requestor_emp_id__in = list(emp_id_error_case)).values_list()
        sap_hr_leave_case_file = open('SAP_HR_Leave_Case.csv','w')#/home/sankey/TMLBusinessLogic/i_TML_EDP/EDP-backend/leave_services/
        sap_hr_csv_writer = csv.writer(sap_hr_leave_case_file)

        print("testing comment #2")
        #To insert the leave error case
        sap_column_meta_data = LeaveRequestsSAP._meta.get_fields()
        for column in sap_column_meta_data:
            sap_error_posting_column.append(column)
        sap_hr_csv_writer.writerow(sap_error_posting_column)

        #To insert the leave error case
        for sap_leave_data in sap_error_case:
            sap_hr_csv_writer.writerow(sap_leave_data)
        sap_hr_leave_case_file.close()

        print("Table entry generated successfully")

        #Mail sending configuration
        email = EmailMessage()
        email.subject = constants.SUBJECT_OF_ERROR_POSTING_LEAVE_MAIL
        text_file_1 = os.path.exists('leave_update_schedular_0.txt')
        text_file_2 = os.path.exists('leave_update_schedular_1.txt')
        edp_error_case_file = os.path.exists('remainingErrorInPosting.csv')
        sap_hr_file = os.path.exists('SAP_HR_Leave_Case.csv')
        email.content_subtype = "html"
        email.body =template.BODY_OF_ERROR_POSTING_LEAVE_TEMPLATE
        email.from_email = constants.system_approver_email
        email.to =config.TML_EDP_MAIL_RECIVER
        if text_file_1:
            email.attach_file('leave_update_schedular_0.txt')
        if text_file_2:
            email.attach_file('leave_update_schedular_1.txt')
        if sap_hr_file:
            email.attach_file('SAP_HR_Leave_Case.csv')
        if edp_error_case_file:
            email.attach_file('remainingErrorInPosting.csv')#/home/sankey/TMLBusinessLogic/i_TML_EDP/EDP-backend/leave_services/
        email.send()
        leave_services_logs = LeaveServicesLogs(
            log_id=str(uuid.uuid4()),
            log_type="EXPORT TO EXCEL FORCE LEAVE POSTING SCHEDULAR",
            result="SUCCESS",
            created_date_time=datetime.now(),
            modified_date_time=datetime.now(),
            created_by="SYSTEM",
            modified_by="SYSTEM"
        )
        leave_services_logs.save()
        status = constants.SUCCESS
        description = message.DATA_UPDATED
        leave_scheduler_logs(scheduler_name,status,description)
        return JsonResponse(message.SUCCESS, safe=False)
    except Exception as error:
        print("error",error)
        leave_services_logs = LeaveServicesLogs(
            log_id=str(uuid.uuid4()),
            log_type="EXPORT TO EXCEL FORCE LEAVE POSTING SCHEDULAR",
            result="FAIL",
            created_date_time=datetime.now(),
            modified_date_time=datetime.now(),
            created_by="SYSTEM",
            modified_by="SYSTEM"
        )
        leave_services_logs.save()
        status = constants.FAILURE
        description = error
        leave_scheduler_logs(scheduler_name,status,description)
        return JsonResponse(message.SERVER_ERROR_MESSAGE, safe=False)
