from django.http import JsonResponse
from ..models import *
from ..views import *
import json
from django.views.decorators.csrf import csrf_exempt
from django.core import serializers
from datetime import datetime, date, timedelta
from pytz import timezone
from datetime import time
import uuid
import xmltodict
import requests
import calendar
from django.db.models import Q
from django.core.mail import EmailMultiAlternatives,EmailMessage
from django.core import mail
from ..views import leave_application
from django.core.paginator import Paginator
from django.db import connection
from configuration import config
from configuration import common_request_body
from configuration import constants
from configuration import message
from configuration import template
from common_functions import *
import os,csv
session = requests.Session()


# METHOD: export_to_excel_error_in_posting
# DESCRIPTION: #This is used to resolved automated error in posting case..
# AUTHOR: Vikas Tomar
# Date: 28/10/2022
# @csrf_exempt
# def export_to_excel_error_in_posting(request):
#     try:
#         edp_error_posting_column=[]
#         sap_error_posting_column=[]
#         for data in range(2):
#             leave_schedule_file_name = "leave_update_schedular_0.txt" if data==0 else "leave_update_schedular_1.txt"
#             error_in_positing_response = error_in_posting_force_run(leave_schedule_file_name)
        
#         #To Get the Error in posting leave case from leave_request_edp table
#         remaining_error_in_posting_case = LeaveRequestsEDP.objects.filter(leave_status='8').values_list()
#         print("before create file",format(os.getcwd()))
#         print(f"File location using __file__ variable: {os.path.realpath(os.path.dirname(__file__))}")
#         # os.chdir('/home/sankey/TMLBusinessLogic/i_TML_EDP/EDP-backend/leave_services/')
#         # print("new path",os.getcwd())
#         edp_error_in_posting = open('remainingErrorInPosting.csv','w') #r'/home/sankey/TMLBusinessLogic/i_TML_EDP/EDP-backend/leave_services/
#         print("file created on path --------------->>>",os.getcwd())
#         leave_error_csv_writer = csv.writer(edp_error_in_posting)

#         print("testing comment #1")
#         #To insert the leave error case
#         column_meta_data = LeaveRequestsEDP._meta.get_fields()
#         for column in column_meta_data:
#             edp_error_posting_column.append(column)
#         leave_error_csv_writer.writerow(edp_error_posting_column)

#         #To insert the leave error case
#         for leave_data in remaining_error_in_posting_case:
#             leave_error_csv_writer.writerow(leave_data)
#         edp_error_in_posting.close()

#         print("testing comment #2")
#         #Take the dump of SAP Error in posting leave case distinct employee ID.
#         emp_id_error_case = LeaveRequestsEDP.objects.filter(leave_status='8').distinct('requestor_emp_id').values_list('requestor_emp_id',flat=True)
#         sap_error_case = LeaveRequestsSAP.objects.filter(requestor_emp_id__in = list(emp_id_error_case)).values_list()
#         sap_hr_leave_case_file = open('SAP_HR_Leave_Case.csv','w')#/home/sankey/TMLBusinessLogic/i_TML_EDP/EDP-backend/leave_services/
#         sap_hr_csv_writer = csv.writer(sap_hr_leave_case_file)

#         print("testing comment #2")
#         #To insert the leave error case
#         sap_column_meta_data = LeaveRequestsSAP._meta.get_fields()
#         for column in sap_column_meta_data:
#             sap_error_posting_column.append(column)
#         sap_hr_csv_writer.writerow(sap_error_posting_column)

#         #To insert the leave error case
#         for sap_leave_data in sap_error_case:
#             sap_hr_csv_writer.writerow(sap_leave_data)
#         sap_hr_leave_case_file.close()

#         print("Table entry generated successfully")

#         #Mail sending configuration
#         email = EmailMessage()
#         email.subject = constants.SUBJECT_OF_ERROR_POSTING_LEAVE_MAIL
#         text_file_1 = os.path.exists('leave_update_schedular_0.txt')
#         text_file_2 = os.path.exists('leave_update_schedular_1.txt')
#         edp_error_case_file = os.path.exists('remainingErrorInPosting.csv')
#         sap_hr_file = os.path.exists('SAP_HR_Leave_Case.csv')
#         email.content_subtype = "html"
#         email.body =template.BODY_OF_ERROR_POSTING_LEAVE_TEMPLATE
#         email.from_email = constants.SYSTEM_APPROVER_MAIL
#         email.to =constants.TML_EDP_MAIL_RECIVER
#         if text_file_1:
#             email.attach_file('leave_update_schedular_0.txt')
#         if text_file_2:
#             email.attach_file('leave_update_schedular_1.txt')
#         if sap_hr_file:
#             email.attach_file('SAP_HR_Leave_Case.csv')
#         if edp_error_case_file:
#             email.attach_file('remainingErrorInPosting.csv')#/home/sankey/TMLBusinessLogic/i_TML_EDP/EDP-backend/leave_services/
#         email.send()
#         return JsonResponse(message.SUCCESS, safe=False)
#     except Exception as error:
#         print("error",error)
#         return JsonResponse(message.SERVER_ERROR_MESSAGE, safe=False)

# METHOD: export_to_excel_error_in_posting
# DESCRIPTION: This is used to update leave status 8 to 2 forcefully
# AUTHOR: Vikas Tomar
# Date: 28/10/2022
# @csrf_exempt
# def error_in_posting_force_run(leave_schedule_file_name):
#     try:
#         error_in_posting_leave = get_serialize_data(LeaveRequestsEDP.objects.filter(leave_status='8'))
#         for data in error_in_posting_leave:
#             leave_request_details = LeaveRequestsEDP.objects.filter(
#                 leave_request_id=data['leave_request_id']).first()

#             if leave_request_details:
#                 if leave_request_details.leave_status == "8":
#                     leave_request_details.leave_status = "1"
#                     leave_request_details.save()

#                     is_present = ApprovedLeaveRequests.objects.filter(leave_request_id = data['leave_request_id']).first()
#                     if not is_present:
#                         approved_leave_requests_details = ApprovedLeaveRequests(
#                             leave_request_id =  data['leave_request_id'],
#                             created_date_time = datetime.now()
#                         )
#                         approved_leave_requests_details.save()
#         force_error_in_posting_sap_update(leave_schedule_file_name)
#         result = {
#             "statusCode": "200",
#             "message": "Your request has been done"
#         }
#         return JsonResponse(result, safe=False)

#     except Exception as error:
#         print(error)
#         result = {
#             "statusCode": "500",
#             "message": "fail"
#         }
#         return JsonResponse(result, safe=False)

# METHOD: export_to_excel_error_in_posting
# DESCRIPTION: This is used to approved the leave from sap side..
# AUTHOR: Vikas Tomar
# Date: 28/10/2022
# @csrf_exempt
# def force_error_in_posting_sap_update(leave_schedule_file_name):
#     try:
#         print('update start')
#         approved_leave_requests_details = ApprovedLeaveRequests.objects.all()
#         if approved_leave_requests_details:
#             approved_leave_requests_details_json = get_serialize_data(
#                 approved_leave_requests_details)

#             file_name = leave_schedule_file_name
#             file = open(file_name, "w")

#             for data in approved_leave_requests_details_json:
#                 # hit sap web service to update leave request in SAP
#                 leave_request_details = LeaveRequestsEDP.objects.filter(
#                     leave_request_id=data['leave_request_id']).first()
#                 if leave_request_details:
#                     # This is to stop leave updation in case of LWOP
#                     leave_against_lwop_details = LeaveAgainstLWOP.objects.filter(
#                         leave_request_id=data['leave_request_id']).first()
#                     if leave_against_lwop_details and leave_against_lwop_details.is_deleted == False:
#                         lwop_delete_sap_response = delete_lwop_leave_request_sap_request(leave_request_details)

#                         if lwop_delete_sap_response != None and lwop_delete_sap_response.status_code == 200:
#                             lwop_delete_leave_details_sap = json.dumps(xmltodict.parse(
#                                 lwop_delete_sap_response.content))  # to convert xml response into dictionary
#                             lwop_delete_leave_details_sap_json = json.loads(
#                                 lwop_delete_leave_details_sap)

#                             if lwop_delete_leave_details_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['TYPE'] == "S":
#                                 leave_against_lwop_details.is_deleted = True
#                                 leave_against_lwop_details.save()
#                             else:
#                                 if leave_request_details.applied_date < (datetime.now().date() - timedelta(days=3)):
#                                     if leave_request_details.leave_status == "1":
#                                         leave_request_details.leave_status = "8"
#                                 continue
#                         else:
#                             continue

#                     if leave_against_lwop_details and leave_against_lwop_details.is_posted == True:
#                         continue

#                     # This is to update leave in SAP
#                     sap_response = update_leave_request_sap_request(
#                         leave_request_details)
#                     print('sap_response', sap_response)
#                     # This is to check wheather th response is in string
#                     is_string = isinstance(sap_response, str)
#                     if is_string == True:
#                         print("SAP webservice failed")

#                     if sap_response != None and sap_response.status_code == 200:
                        
#                         # to convert xml response into dictionary
#                         leave_update_details_sap = json.dumps(
#                             xmltodict.parse(sap_response.content))
#                         leave_update_sap_json = json.loads(
#                             leave_update_details_sap)

#                         if leave_update_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['MESSAGE'] !=None:
#                             file.write(data['leave_request_id'] + "\n")
#                             file.write(leave_update_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['MESSAGE']+ "\n")

#                         # This is to allow leave against LWOP
#                         sap_status_code = leave_update_sap_json[
#                             'soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['TYPE']
#                         sap_msg_number = leave_update_sap_json[
#                             'soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['NUMBER']
#                         print(leave_update_sap_json['soap-env:Envelope']
#                               ['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['MESSAGE'])
#                         print(leave_update_sap_json['soap-env:Envelope']
#                               ['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['TYPE'])
#                         print(leave_update_sap_json['soap-env:Envelope']
#                               ['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['NUMBER'])
#                         emp_id = leave_request_details.requestor_emp_id
#                         from_date = leave_request_details.from_date
#                         to_date = leave_request_details.to_date

#                         sap_leave_request = LeaveRequestsSAP.objects.filter(
#                             Q(requestor_emp_id=emp_id, from_date=from_date, to_date=to_date, leave_category="Z0", is_deleted=False) |
#                             Q(requestor_emp_id=emp_id, from_date=from_date,
#                               to_date=to_date, leave_category="Z0P", is_deleted=False)
#                         )

#                         if(sap_status_code == "E" and sap_msg_number == "080" and sap_leave_request):
#                             leave_against_lwop_details = LeaveAgainstLWOP(
#                                 leave_request_id=data['leave_request_id'],
#                                 is_deleted=False,
#                                 is_posted=False,
#                                 created_date_time=datetime.now()
#                             )
#                             print("Adding LWOP Leave")
#                             leave_against_lwop_details.save()

#                         if leave_update_sap_json['soap-env:Envelope']['soap-env:Body']['n0:ZFTM0015Response']['RETURN1']['TYPE'] == "S":

#                             if leave_against_lwop_details and leave_against_lwop_details.is_posted == False:
#                                 leave_against_lwop_details.is_posted = True
#                                 leave_against_lwop_details.save()

#                             # This is to update the status after successfully udpated in SAP
#                             leave_request_details = LeaveRequestsEDP.objects.filter(
#                                 leave_request_id=data['leave_request_id']).first()
#                             if leave_request_details:
#                                 if leave_request_details.leave_status == "1":
#                                     leave_request_details.leave_status = "2"

#                                     # This is to insert leave requst timestamp
#                                     sap_posting_details = SAPPostingDetails.objects.filter(
#                                         leave_request_id=data['leave_request_id']).first()
#                                     if sap_posting_details:
#                                         sap_posting_details.leave_request_posting_datetime = datetime.now()
#                                         sap_posting_details.created_by = "SYSTEM"
#                                         sap_posting_details.modified_by = "SYSTEM"
#                                         sap_posting_details.save()

#                                 else:
#                                     leave_request_details.leave_status = "7"
#                                     leave_request_details.is_deleted = True

#                                     # This is to insert leave requst timestamp
#                                     sap_posting_details = SAPPostingDetails.objects.filter(
#                                         leave_request_id=data['leave_request_id']).first()
#                                     if sap_posting_details:
#                                         sap_posting_details.delete_leave_posting_datetime = datetime.now()
#                                         sap_posting_details.created_by = "SYSTEM"
#                                         sap_posting_details.modified_by = "SYSTEM"
#                                         sap_posting_details.save()

#                                 leave_request_details.modified_date_time = datetime.now()
#                                 leave_request_details.save()

#                             # This is to delete the record from approved leave request table
#                             approved_leave_request = ApprovedLeaveRequests.objects.filter(
#                                 leave_request_id=data['leave_request_id']).delete()

#                             if leave_request_details.requestor_email != "":
#                                 leave_category_text = ""
#                                 leave_type_text = ""

#                                 # To create email subject
#                                 leave_categpory_mail = ""
#                                 current_datetime_ist = datetime.now() + timedelta(hours=5, minutes=30)
#                                 if leave_request_details.leave_status == "2":
#                                     leave_categpory_mail = constants.LEAVE_APPROVAL_NOTIFICATION
#                                     email_subject = """Leave Approval Notification - """ + \
#                                         str(current_datetime_ist.date())
#                                     email_body = template.leave_approval_email_template
#                                 else:
#                                     leave_categpory_mail = constants.LEAVE_DELETE_APPROVE
#                                     email_subject = """Delete Leave Approval Notification - """ + \
#                                         str(current_datetime_ist.date())
#                                     email_body = template.delete_leave_approval_email_template

#                                 user = {
#                                     "emp_id": leave_request_details.requestor_emp_id
#                                 }
#                                 response = session.post(config.get_edp_employee_details, data=json.dumps(user))
#                                 user_details = response.content.decode("utf-8")
#                                 user_details_json = json.loads(user_details)

#                                 pa = user_details_json['user_details'][0]['PersArea']
#                                 psa = user_details_json['user_details'][0]['PSubarea']
#                                 emp_name = user_details_json['user_details'][0]['CompName']
#                                 # This is to get leave category text
#                                 current_date_ist = datetime.now().astimezone(timezone('Asia/Kolkata')).date()
#                                 ps_group_details = PAPSAGroupMapping.objects.filter(
#                                     pa_code=pa, psa_code=psa).first()
#                                 if ps_group_details:
#                                     leave_category_details = PSGroupLeaveCategoryMapping.objects.filter(
#                                         pa_psa_group=ps_group_details.pa_psa_group, leave_category_code=leave_request_details.leave_category, valid_from__lte=current_date_ist, valid_to__gte=current_date_ist).first()
#                                     if leave_category_details:
#                                         leave_category_text = leave_category_details.leave_category_text

#                                 # This is to get leave type text
#                                 leave_type_details = LeaveType.objects.filter(
#                                     leave_type_code=leave_request_details.leave_type).first()
#                                 if leave_type_details:
#                                     leave_type_text = leave_type_details.leave_type_text

#                                 #Request Body - To send leave application approval mail
#                                 request_body_for_mail_template = {
#                                     constants.LEAVE_CATEGORY_MAIL: leave_categpory_mail,
#                                     constants.EMP_ID:leave_request_details.requestor_emp_id,
#                                     constants.EMP_NAME:emp_name,
#                                     constants.LEAVE_TYPE:leave_category_text,
#                                     constants.ABSENCE_TYPE:leave_type_text,
#                                     constants.START_DATE:str(leave_request_details.from_date),
#                                     constants.END_DATE:str(leave_request_details.to_date),
#                                     constants.LEAVE_REASON: leave_request_details.reason,
#                                     constants.TO_MAIL_ADDRESS: leave_request_details.requestor_email,
#                                     constants.CC_MAIL_ADDRESS:leave_request_details.approver_email,
#                                     constants.LEAVE_REQUESTOR_ROLE : constants.EMPLOYEE_ROLE
                                    
#                                 }
#                                 mail_response = leave_application_mail(request_body_for_mail_template)
#                                 print("approved mail response",mail_response)

#                                 # to create a email body
#                                 email_body = email_body.replace(
#                                     'emp_id', leave_request_details.requestor_emp_id)
#                                 email_body = email_body.replace(
#                                     'leave_type', leave_category_text)
#                                 email_body = email_body.replace(
#                                     'absence_type', leave_type_text)
#                                 email_body = email_body.replace(
#                                     'start_date', str(leave_request_details.from_date))
#                                 email_body = email_body.replace(
#                                     'end_date', str(leave_request_details.to_date))
#                                 email_body = email_body.replace(
#                                     'leave_reason', leave_request_details.reason)

#                                 # To send attendance email to manager
#                                 send_email_notification(
#                                     leave_request_details.requestor_email, leave_request_details.approver_email, email_body, email_subject)

#                             print("Leave request sucuessfully updated in SAP")
#                         else:
#                             print("Unable to update request in SAP")

#                             # This is to make leave status as error
#                             current_date = datetime.now().date()
#                             if leave_request_details.applied_date < (datetime.now().date() - timedelta(days=3)):
#                                 if leave_request_details.leave_status == "1":
#                                     leave_request_details.leave_status = "8"

#                                     # This is to insert leave requst timestamp
#                                     sap_posting_details = SAPPostingDetails.objects.filter(
#                                         leave_request_id=data['leave_request_id']).first()
#                                     if sap_posting_details:
#                                         sap_posting_details.leave_request_posting_datetime = datetime.now()
#                                         sap_posting_details.created_by = "SYSTEM"
#                                         sap_posting_details.modified_by = "SYSTEM"
#                                         sap_posting_details.save()
#                                 else:
#                                     leave_request_details.leave_status = "9"

#                                 leave_request_details.modified_date_time = datetime.now()
#                                 leave_request_details.save()
                                
#                                 # This is to delete the record from approved leave request table
#                                 approved_leave_request = ApprovedLeaveRequests.objects.filter(
#                                     leave_request_id=data['leave_request_id']).delete()
#                     else:
#                         print("SAP webservice failed.")
#                 else:
#                     print("leave request is not present in leave deatils table ")

#             # This is insert data in logs table
#             leave_services_logs = LeaveServicesLogs(
#                 log_id=str(uuid.uuid4()),
#                 log_type="LEAVE POSTING SCHEDULAR",
#                 result="SUCCESS",
#                 created_date_time=datetime.now(),
#                 modified_date_time=datetime.now(),
#                 created_by="SYSTEM",
#                 modified_by="SYSTEM"
#             )
#             leave_services_logs.save()
#             file.close()
#             print("SUCESSSSSSSSSSSSSSSSSSS")
#         else:
#             print("No data found to update in SAP")
#     except (Exception) as error:
#         print(error)
#         # This is insert data in logs table
#         leave_services_logs = LeaveServicesLogs(
#             log_id=str(uuid.uuid4()),
#             log_type="LEAVE POSTING SCHEDULAR",
#             result="FAIL",
#             created_date_time=datetime.now(),
#             modified_date_time=datetime.now(),
#             created_by="SYSTEM",
#             modified_by="SYSTEM"
#         )
#         leave_services_logs.save()

# METHOD: set_to_approved_status
# DESCRIPTION: This is used to set the leave in approved status.
# AUTHOR: Vikas Tomar
# Date: 31/10/2022
@csrf_exempt
def set_to_approved_status(request):
    try:
        leave_data = json.loads(request.body)
        count = 0
        for data in leave_data:
            leave_request_details = LeaveRequestsEDP.objects.filter(
                leave_request_id=data['leave_request_id']).first()
            if leave_request_details:
                if leave_request_details.leave_status == "8":
                    leave_request_details.leave_status = "2"
                    leave_request_details.modified_date_time = datetime.now()
                    leave_request_details.save()
                    leave_againest_lwop_details = LeaveAgainstLWOP.objects.filter(
                        leave_request_id=data['leave_request_id']).first()
                    if leave_againest_lwop_details:
                        leave_againest_lwop_details.delete()
                    approved_leave_requests_details = ApprovedLeaveRequests.objects.filter(
                        leave_request_id=data['leave_request_id']).first()
                    if approved_leave_requests_details:
                        approved_leave_requests_details.delete()
                    count += 1
                    print("coSUCCESSunt")
        return JsonResponse(message.SUCCESS, safe=False)
    except Exception as error:
        print(error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE,safe=False)

# METHOD: set_to_deleted_status
# DESCRIPTION: This is used to set the leave in deleted status.
# AUTHOR: Vikas Tomar
# Date: 31/10/2022
@csrf_exempt
def set_to_deleted_status(request):
    try:
        leave_data = json.loads(request.body)
        count = 0
        for data in leave_data:
            leave_request_details = LeaveRequestsEDP.objects.filter(
                leave_request_id=data['leave_request_id']).first()
            if leave_request_details:
                print("is in leave request details", leave_request_details)
                if leave_request_details.leave_status == "8":
                    leave_request_details.leave_status = "7"
                    leave_request_details.modified_date_time = datetime.now()
                    leave_request_details.is_deleted = True
                    leave_request_details.save()

                    leave_againest_lwop_details = LeaveAgainstLWOP.objects.filter(
                        leave_request_id=data['leave_request_id']).first()
                    if leave_againest_lwop_details:
                        leave_againest_lwop_details.delete()
                    approved_leave_requests_details = ApprovedLeaveRequests.objects.filter(
                        leave_request_id=data['leave_request_id']).first()
                    if approved_leave_requests_details:
                        approved_leave_requests_details.delete()
                    count += 1
                    print(count)
        return JsonResponse(message.SUCCESS, safe=False)
    except Exception as error:
        print_error_v1('set_to_deleted_status', error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE, safe=False)

# METHOD: set_to_post_pending_status
# DESCRIPTION: This is used to set the leave in posting pending status
# AUTHOR: Vikas Tomar
# Date: 31/10/2022
@csrf_exempt
def set_to_post_pending_status(request):
    try:
        leave_data = json.loads(request.body)
        count = 0
        for data in leave_data:
            leave_request_details = LeaveRequestsEDP.objects.filter(
                leave_request_id=data['leave_request_id']).first()
            if leave_request_details:
                if leave_request_details.leave_status == "8":
                    leave_request_details.leave_status = "1"
                    leave_request_details.modified_date_time = datetime.now()
                    leave_request_details.save()

                    leave_againest_lwop_details = LeaveAgainstLWOP.objects.filter(
                        leave_request_id=data['leave_request_id']).first()
                    if leave_againest_lwop_details:
                        leave_againest_lwop_details.delete()
                    is_present = ApprovedLeaveRequests.objects.filter(leave_request_id = data['leave_request_id']).first()
                    if not is_present:
                        approved_leave_requests_details = ApprovedLeaveRequests(
                            leave_request_id =  data['leave_request_id'],
                            created_date_time = datetime.now()
                        )
                        approved_leave_requests_details.save()

                    count += 1
                    print(count)
        return JsonResponse(message.SUCCESS, safe=False)
    except Exception as error:
        print(error)
        return JsonResponse(message.SERVER_ERROR_MESSAGE, safe=False)
